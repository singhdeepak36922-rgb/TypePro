# TypePro — Master Your Typing Skills

A full-stack typing tutor and assessment platform for English and Hindi (Devanagari Unicode), built with
Next.js (App Router), TypeScript, Tailwind CSS v4, Drizzle ORM and PostgreSQL. No fabricated statistics: every
metric in the product is derived from saved sessions.

## Feature map

| Area | Status | Notes |
| --- | --- | --- |
| App shell / navigation | ✅ | 11 working sections, active highlighting, responsive drawer, dark/light/system themes (dark default) |
| Dashboard | ✅ | Real totals, goal ring, streak, weekly activity, WPM trend, recent history, empty states |
| Typing test engine | ✅ | 1/2/3/5/10/15 min, 6 categories, live WPM/accuracy/errors, completion & timer stop, restart |
| Scoring engine | ✅ | Grapheme-aware (`Intl.Segmenter`), standard/gross/net WPM, final-text accuracy + keystroke errors, unit tested |
| English lessons | ✅ | 20 seeded lessons across beginner/intermediate/advanced with progress persistence |
| Hindi typing | ✅ | InScript practice with clickable layout, roman→Devanagari phonetic buffer, 4 seeded Hindi passages, reference grid |
| Free practice | ✅ | Random passage or custom text, English/Hindi detection, untimed, saved results |
| Virtual keyboard | ✅ | EN + InScript layouts, next-key highlight, finger colours, click-to-type, drill studio |
| Games | ✅ | Speed Challenge, Word Challenge, Accuracy Challenge, Time Attack, Typing Race with saved best scores |
| Reports | ✅ | Daily/weekly/monthly charts, WPM/accuracy trends, weak keys, mode/range filters, CSV export |
| Achievements | ✅ | 12 milestones evaluated only from saved data, persisted in `achievements` for accounts |
| Settings | ✅ | Theme, language, sound, cursor style, layout, defaults, daily goal, strict mode, keyboard visibility |
| Auth | ✅ | Register, login, logout, password reset tokens, profile updates, guest mode with local progress + import |
| Data model | ✅ | users, sessions, password reset, settings, courses, lessons, passages, typing results, lesson progress, achievements, key stats |

## Architecture

```
src/
  app/
    (app)/            authenticated + guest application pages (shared shell)
    (auth)/           login / register / reset-password
    api/              auth, results, settings, profile, health route handlers
  components/         shell, providers, typing surface, virtual keyboard, charts, feature views
  db/                 Drizzle schema + pooled client
  lib/
    typing-engine.ts  pure scoring engine (unit tested)
    transliterate.ts  roman → Devanagari phonetic engine
    keyboard.ts       EN QWERTY + Hindi InScript layouts & finger map
    stats.ts          summaries, streaks, daily series (pure)
    achievements.ts   declarative achievement rules (pure)
    data.ts           server data access + idempotent seeding
    auth.ts           scrypt passwords, HTTP-only sessions
    local-store.ts    guest persistence (browser localStorage)
```

The scoring engine and transliteration engine have no React/DOM dependencies, so they can be reused by a Tauri
desktop shell later.

## Scoring definitions

- Graphemes are segmented with `Intl.Segmenter` (combining marks/matras stay attached).
- `Standard WPM = correct graphemes / 5 / elapsed minutes`
- `Gross WPM = typed graphemes / 5 / elapsed minutes`
- `Net WPM = Gross WPM − uncorrected errors per minute` (never negative)
- `Accuracy = correct final-position graphemes / typed graphemes × 100`
- Backspace is allowed (unless strict mode); corrected mistakes raise final-text accuracy but remain visible in
  `keystrokeErrors` and the weak-key statistics.
- Elapsed time is floored at one second to avoid division-by-zero. Empty input always yields 0 metrics.
- Phonetic Hindi scores only committed words; the in-progress composition is previewed but never scored.

## Local development

```bash
npm install
cp .env .env.local            # DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
npx drizzle-kit push --config=drizzle.config.json --force   # apply schema
npm run dev                   # content is seeded lazily on first request
npx vitest run                # typing engine unit tests (16 tests)
npm run build && npm run start
```

Health check: `GET /api/health` verifies the database connection.

## Testing performed

- `npx vitest run` — 16 engine tests: correct/incorrect typing, backspace, empty input, timer math, WPM
  formulas, accuracy, Hindi graphemes/conjuncts, completion, next-grapheme helper, normalization. All pass.
- `npx next typegen`, `npm exec tsc --noEmit`, `npm run build` — all pass.
- HTTP smoke tests: every page returns 200; guest API access is 401; registration, session cookie, result
  persistence, achievement unlocking, key-stat aggregation and reset-token issuance verified against PostgreSQL.
- Database verified: 20 lessons, 14 passages, 3 courses seeded; results, achievements and key stats rows created
  through the API.

## Deployment

1. Provision PostgreSQL and set `DATABASE_URL`.
2. Run `npx drizzle-kit push --config=drizzle.config.json` against the target database (or generate SQL
   migrations with `drizzle-kit generate` for controlled environments).
3. `npm run build` then `npm run start` (or deploy to any Node platform). Health endpoint: `/api/health`.
4. Serve over HTTPS so session cookies keep their `Secure` flag.

Password reset has no mail provider in this environment: the reset token is returned once to the UI. Wire an
email provider before production if tokens must be delivered by mail.

## Mobile app support (installable PWA)

TypePro ships as an **installable Progressive Web App**, which is the fastest route to a real mobile app for
Android and iOS without a store review cycle:

- `public/manifest.webmanifest` — standalone display, theme/background colours, app shortcuts (test, Hindi,
  lessons, reports) and a full PNG icon set including a maskable/adaptive icon.
- `public/icons/*` — generated by `node scripts/generate-icons.mjs` (sharp) from the master logo SVG, so app
  icons always match the product brand.
- `public/sw.js` — offline app shell: network-first for navigations with cached fallback, stale-while-revalidate
  for static assets, and no caching for `/api/*` so session and result data always stay fresh.
- `src/components/pwa.tsx` — service-worker registration, `beforeinstallprompt` handling, standalone detection
  and per-platform install instructions (Chrome/Edge direct install, Safari Add to Home Screen).
- Mobile CSS: `viewport-fit=cover` + safe-area insets for notched devices, 16px inputs to stop iOS zoom-on-focus
  and `touch-action: manipulation` to remove tap delays.

Installing: open the site in Chrome/Edge on Android → “Install app”, or in iOS Safari → Share → Add to Home
Screen. In a desktop Chromium browser the same prompt installs a desktop app window.

### Store-ready native wrappers (next phase)

| Option | Effort | Notes |
| --- | --- | --- |
| Tauri 2 (iOS + Android) | Medium | Reuses this exact web build in a native webview; Rust core for offline SQLite and system IME access. Same codebase also targets Windows 10/11. |
| Capacitor 6 | Low | Wraps the web build for App Store / Play Store with native plugins (haptics, share, keyboard resize). |
| React Native / Expo | High | Rewrites the UI layer; only the `src/lib` engine, stats, achievements and content modules are reusable. |

Recommended order: keep the PWA as the universally installable app, then add Capacitor for store presence, then
Tauri 2 for the Windows desktop installer.

## Next phase (Tauri 2 desktop)

- Wrap the Next.js build in a Tauri 2 shell (`src-tauri`), point the webview at the bundled server or export a
  static shell plus API sidecar.
- Add offline mode: local SQLite via `tauri-plugin-sql`, with the same engine/analytics modules, and sync to the
  cloud when online.
- Bundle Windows 10/11 installers (MSI/NSIS) and sign them.
- Remaining polish for desktop: global keyboard layout detection, OS InScript driver validation, and native
  sound assets.
