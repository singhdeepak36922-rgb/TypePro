/**
 * Generates the TypePro mobile / PWA icon set from the master logo SVG.
 * Run with: node scripts/generate-icons.mjs
 */
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

const ROOT = process.cwd();
const OUT = path.join(ROOT, "public", "icons");

const masterSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#3b82f6"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="116" fill="url(#g)"/>
  <rect x="46" y="46" width="420" height="420" rx="96" fill="#050b1a" opacity="0.9"/>
  <path d="M170 178h172" stroke="#e8eefc" stroke-width="30" stroke-linecap="round"/>
  <path d="M256 178v188" stroke="#e8eefc" stroke-width="30" stroke-linecap="round"/>
  <circle cx="330" cy="332" r="34" fill="#22d3ee"/>
  <path d="M138 270h82M138 324h82" stroke="#3b82f6" stroke-width="26" stroke-linecap="round"/>
</svg>`;

/**
 * Maskable icons are cropped to a circle/squircle by Android, so the artwork
 * must sit inside the middle 80% safe zone. Full-bleed gradient background.
 */
const maskableSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#3b82f6"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="512" height="512" fill="#050b1a"/>
  <g transform="translate(256 256) scale(0.72) translate(-256 -256)">
    <rect x="10" y="10" width="492" height="492" rx="116" fill="url(#g)"/>
    <rect x="46" y="46" width="420" height="420" rx="96" fill="#050b1a" opacity="0.9"/>
    <path d="M170 178h172" stroke="#e8eefc" stroke-width="30" stroke-linecap="round"/>
    <path d="M256 178v188" stroke="#e8eefc" stroke-width="30" stroke-linecap="round"/>
    <circle cx="330" cy="332" r="34" fill="#22d3ee"/>
    <path d="M138 270h82M138 324h82" stroke="#3b82f6" stroke-width="26" stroke-linecap="round"/>
  </g>
</svg>`;

const faviconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="48" height="48">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#3b82f6"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="48" height="48" rx="13" fill="url(#g)"/>
  <rect x="7" y="7" width="34" height="34" rx="10" fill="#050b1a" opacity="0.9"/>
  <path d="M16 17h16" stroke="#e8eefc" stroke-width="2.6" stroke-linecap="round"/>
  <path d="M24 17v15" stroke="#e8eefc" stroke-width="2.6" stroke-linecap="round"/>
  <circle cx="31.5" cy="29" r="3.2" fill="#22d3ee"/>
  <path d="M14 26h5.5M14 30h5.5" stroke="#3b82f6" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

async function main() {
  await mkdir(OUT, { recursive: true });

  const sizes = [192, 256, 384, 512];
  for (const size of sizes) {
    await sharp(Buffer.from(masterSvg))
      .resize(size, size)
      .png({ compressionLevel: 9 })
      .toFile(path.join(OUT, `icon-${size}.png`));
  }

  // Maskable (Android adaptive) + Apple touch icon (opaque, no alpha).
  await sharp(Buffer.from(maskableSvg)).resize(512, 512).png({ compressionLevel: 9 }).toFile(path.join(OUT, "icon-maskable-512.png"));
  await sharp(Buffer.from(masterSvg)).resize(180, 180).flatten({ background: "#050b1a" }).png({ compressionLevel: 9 }).toFile(path.join(OUT, "apple-touch-icon.png"));
  await sharp(Buffer.from(masterSvg)).resize(32, 32).png({ compressionLevel: 9 }).toFile(path.join(OUT, "favicon-32.png"));

  await writeFile(path.join(ROOT, "src", "app", "icon.svg"), faviconSvg, "utf8");

  console.log("Generated PWA icons in public/icons");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
