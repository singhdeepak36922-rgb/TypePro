export function Logo({ size = 36, withWordmark = true }: { size?: number; withWordmark?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        role="img"
        aria-label="TypePro logo"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="typepro-mark" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
        <rect x="2" y="2" width="44" height="44" rx="13" fill="url(#typepro-mark)" />
        <rect x="7" y="7" width="34" height="34" rx="10" fill="#050b1a" opacity="0.88" />
        <path d="M16 17h16" stroke="#e8eefc" strokeWidth="2.6" strokeLinecap="round" />
        <path d="M24 17v15" stroke="#e8eefc" strokeWidth="2.6" strokeLinecap="round" />
        <circle cx="31.5" cy="29" r="3.2" fill="#22d3ee" />
        <path d="M14 26h5.5M14 30h5.5" stroke="#3b82f6" strokeWidth="2.2" strokeLinecap="round" />
      </svg>
      {withWordmark ? (
        <span className="flex flex-col leading-none">
          <span className="text-[1.06rem] font-extrabold tracking-tight text-ink">
            Type<span className="text-brand">Pro</span>
          </span>
          <span className="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-muted">
            Typing Lab
          </span>
        </span>
      ) : null}
    </span>
  );
}
