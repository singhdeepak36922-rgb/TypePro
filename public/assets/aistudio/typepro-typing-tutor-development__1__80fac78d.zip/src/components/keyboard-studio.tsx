"use client";

import { useMemo, useRef, useState } from "react";
import { Hand, Info, Keyboard as KeyboardIcon, RefreshCw, Target } from "lucide-react";
import { VirtualKeyboard } from "@/components/virtual-keyboard";
import { Badge, PageHeader, SectionCard } from "@/components/ui";
import { HOME_ROW, FINGER_COLORS, FINGER_LABELS } from "@/lib/keyboard";
import { compareGraphemes, toGraphemes } from "@/lib/typing-engine";

const DRILLS: { label: string; text: string }[] = [
  { label: "Home row", text: "asdf jkl; asdf jkl; ff jj dd kk ss ll aa ;; fj dk sl a;" },
  { label: "Left hand", text: "add gas fast safe caves sea great draft waste serve staff brave" },
  { label: "Right hand", text: "kill hill milk noon moon pool join loop lion mink pink jolly" },
  { label: "Upper row", text: "we type quite well when quiet words appear. reply to every uptown query." },
  { label: "Bottom row", text: "zoom into five cabins. max can box every zany video before noon." },
  { label: "Capitals & numbers", text: "TypePro 2026 has 12 lessons, 6 tests and 5 games. Press Shift for Delhi." },
];

const HINDI_DRILLS: { label: string; text: string }[] = [
  { label: "स्वर", text: "अ आ इ ई उ ऊ ए ऐ ओ औ" },
  { label: "व्यंजन", text: "क ख ग घ च छ ज झ ट ठ ड ढ त थ द ध न प फ ब भ म" },
  { label: "मात्राएँ", text: "का कि की कु कू के कै को कौ" },
  { label: "शब्द", text: "हिंदी टाइपिंग अभ्यास रोज करें" },
];

export function KeyboardStudio() {
  const [layout, setLayout] = useState<"en" | "hi">("en");
  const [drill, setDrill] = useState(0);
  const [typed, setTyped] = useState("");
  const [activeFinger, setActiveFinger] = useState<string>("left-index");
  const inputRef = useRef<HTMLInputElement | null>(null);

  const drills = layout === "en" ? DRILLS : HINDI_DRILLS;
  const drillText = drills[Math.min(drill, drills.length - 1)].text;
  const targetGraphemes = useMemo(() => toGraphemes(drillText), [drillText]);
  const typedGraphemes = toGraphemes(typed);
  const expected = targetGraphemes[typedGraphemes.length] ?? null;
  const comparison = compareGraphemes(drillText, typed);
  const accuracy = comparison.typedLength ? (comparison.correctChars / comparison.typedLength) * 100 : 100;
  const done = typedGraphemes.length >= targetGraphemes.length && targetGraphemes.length > 0;

  const append = (char: string, isBackspace: boolean) => {
    setTyped((current) => {
      const graphemes = toGraphemes(current);
      if (isBackspace) return graphemes.slice(0, -1).join("");
      return [...graphemes, char].slice(0, targetGraphemes.length).join("");
    });
    inputRef.current?.focus();
  };

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Layout trainer"
        title="Virtual keyboard"
        description="An interactive layout reference that responds to your real typing. The next required key is highlighted, and every key is colour coded by the finger that should press it."
        action={
          <a
            className="btn btn-ghost"
            href="https://en.wikipedia.org/wiki/InScript_keyboard"
            target="_blank"
            rel="noreferrer noopener"
          >
            <Info size={15} /> InScript notes
          </a>
        }
      />

      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-lg border border-line p-0.5">
            <button
              type="button"
              onClick={() => {
                setLayout("en");
                setDrill(0);
                setTyped("");
              }}
              className={`inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-semibold ${
                layout === "en" ? "bg-brand text-white" : "text-muted"
              }`}
            >
              <KeyboardIcon size={12} /> English QWERTY
            </button>
            <button
              type="button"
              onClick={() => {
                setLayout("hi");
                setDrill(0);
                setTyped("");
              }}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold ${
                layout === "hi" ? "bg-brand text-white" : "text-muted"
              }`}
            >
              हिन्दी InScript
            </button>
          </div>

          <select
            value={drill}
            onChange={(event) => {
              setDrill(Number(event.target.value));
              setTyped("");
            }}
            className="input !w-auto !py-1.5 !text-xs"
            aria-label="Drill"
          >
            {drills.map((item, index) => (
              <option key={item.label} value={index}>
                {item.label}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setTyped("")}
            className="btn btn-ghost !py-1.5 !text-xs ml-auto"
          >
            <RefreshCw size={13} /> Reset drill
          </button>
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <div className="card-flat p-3">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Next key</p>
            <p className="mt-0.5 text-2xl font-bold text-brand">{expected ?? "—"}</p>
            <p className="text-[0.66rem] text-muted">{done ? "Drill complete" : `${typedGraphemes.length}/${targetGraphemes.length} typed`}</p>
          </div>
          <div className="card-flat p-3">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Accuracy</p>
            <p className="mt-0.5 text-2xl font-bold text-success">{accuracy.toFixed(0)}%</p>
            <p className="text-[0.66rem] text-muted">{comparison.incorrectChars} mistakes in drill</p>
          </div>
          <div className="card-flat p-3">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Finger to use</p>
            <p className="mt-0.5 flex items-center gap-2 text-sm font-bold text-ink">
              <span
                className="inline-block h-3 w-3 rounded-full"
                style={{ background: FINGER_COLORS[activeFinger as keyof typeof FINGER_COLORS] ?? "#3b82f6" }}
              />
              {FINGER_LABELS[activeFinger as keyof typeof FINGER_LABELS] ?? "Either hand"}
            </p>
            <p className="text-[0.66rem] text-muted">Home anchors: F and J</p>
          </div>
        </div>

        <div className="mt-3">
          <label className="label" htmlFor="keyboard-drill-input">
            Drill text — type it here (or click the on-screen keys)
          </label>
          <p className={`mb-2 ${layout === "hi" ? "passage passage-hi !text-base" : "font-mono text-sm"} text-muted`}>
            {targetGraphemes.map((grapheme, index) => {
              const typedGrapheme = typedGraphemes[index];
              if (typedGrapheme === undefined) {
                return (
                  <span key={index} className={index === typedGraphemes.length ? "char-current" : "char-pending"}>
                    {grapheme}
                  </span>
                );
              }
              return (
                <span key={index} className={typedGrapheme === grapheme ? "char-correct" : "char-incorrect"}>
                  {grapheme}
                </span>
              );
            })}
          </p>
          <input
            id="keyboard-drill-input"
            ref={inputRef}
            value={typed}
            onChange={(event) => setTyped(event.target.value)}
            placeholder="Click the passage or on-screen keys and start typing…"
            autoComplete="off"
            spellCheck={false}
            className="input"
          />
          {done ? (
            <p className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-success">
              <Target size={13} /> Drill complete — press Reset to repeat.
            </p>
          ) : null}
        </div>
      </div>

      <div className="card p-3 sm:p-4">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-[0.7rem] font-bold uppercase tracking-[0.12em] text-muted">
            {layout === "en" ? "English keyboard" : "Hindi InScript mapping"}
          </p>
          <Badge tone="brand">Interactive</Badge>
        </div>
        <VirtualKeyboard
          layout={layout}
          expected={expected}
          lastTyped={typedGraphemes[typedGraphemes.length - 1] ?? null}
          interactive
          onKey={(char, isBackspace) => append(char, isBackspace)}
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <SectionCard title="Finger placement" description="Colour guide for both hands">
          <div className="grid gap-1.5">
            {(Object.keys(FINGER_LABELS) as (keyof typeof FINGER_LABELS)[]).map((finger) => (
              <button
                key={finger}
                type="button"
                onClick={() => setActiveFinger(finger)}
                className={`flex items-center justify-between rounded-lg border px-3 py-2 text-xs ${
                  activeFinger === finger ? "border-brand bg-brand-soft text-ink" : "border-line text-muted"
                }`}
              >
                <span className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: FINGER_COLORS[finger] }} />
                  {FINGER_LABELS[finger]}
                </span>
                <span className="font-mono text-[0.68rem]">
                  {finger.startsWith("left") ? "Left hand" : finger.startsWith("right") ? "Right hand" : "Either"}
                </span>
              </button>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Home row guidance" description="The base position for every drill">
          <div className="rounded-xl border border-line bg-panel/50 p-3">
            <div className="flex flex-wrap gap-1.5">
              {HOME_ROW.map((key) => (
                <span
                  key={key}
                  className={`grid h-10 w-10 place-items-center rounded-md border border-line bg-surface font-mono font-bold ${
                    key === "f" || key === "j" ? "text-brand" : "text-ink"
                  }`}
                >
                  {key === ";" ? ";" : key.toUpperCase()}
                </span>
              ))}
            </div>
            <p className="mt-2 flex items-center gap-1.5 text-[0.7rem] text-muted">
              <Hand size={13} className="text-brand" /> Rest your index fingers on F and J — the raised bumps confirm
              your position without looking.
            </p>
          </div>
          <ul className="mt-3 space-y-1.5 text-[0.72rem] leading-relaxed text-muted">
            <li>· Keep wrists neutral and elbows close to your body.</li>
            <li>· Strike keys with the fingertip, then return to the home row.</li>
            <li>· Never look down — the highlighted next key guides you.</li>
            <li>· Speed comes from accuracy; slow down when errors rise.</li>
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
