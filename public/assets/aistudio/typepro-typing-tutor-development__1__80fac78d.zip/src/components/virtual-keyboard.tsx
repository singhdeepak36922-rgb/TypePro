"use client";

import { useMemo, useState } from "react";
import {
  EN_ROWS,
  FINGER_COLORS,
  FINGER_LABELS,
  HINDI_ROWS,
  HOME_ROW,
  type Finger,
} from "@/lib/keyboard";
import { toGraphemes } from "@/lib/typing-engine";

type Layout = "en" | "hi";

interface KeyShape {
  id: string;
  base: string;
  shift: string;
  finger: Finger;
  width: number;
  label?: string;
}

function buildRows(layout: Layout): KeyShape[][] {
  if (layout === "hi") {
    return HINDI_ROWS.map((row, rowIndex) =>
      row.map((key, keyIndex) => ({
        id: `${rowIndex}-${keyIndex}-${key.code}`,
        base: key.base,
        shift: key.shift,
        finger: key.finger,
        width: key.width ?? 1,
        label: key.code === "Backspace" ? "⌫" : undefined,
      })),
    );
  }
  return EN_ROWS.map((row, rowIndex) =>
    row.map((key, keyIndex) => ({
      id: `${rowIndex}-${keyIndex}-${key.code}`,
      base: key.base,
      shift: key.shift ?? "",
      finger: key.finger,
      width: key.width ?? 1,
      label: key.label,
    })),
  );
}

export function VirtualKeyboard({
  layout = "en",
  expected = null,
  lastTyped = null,
  interactive = false,
  onKey,
  showLegend = true,
  compact = false,
}: {
  layout?: Layout;
  expected?: string | null;
  lastTyped?: string | null;
  interactive?: boolean;
  onKey?: (char: string, isBackspace: boolean) => void;
  showLegend?: boolean;
  compact?: boolean;
}) {
  const [shift, setShift] = useState(false);
  const rows = useMemo(() => buildRows(layout), [layout]);

  const expectedGrapheme = expected ? toGraphemes(expected)[0] ?? expected : null;
  const typedGrapheme = lastTyped ? toGraphemes(lastTyped)[0] ?? lastTyped : null;

  return (
    <div className="select-none">
      <div className="overflow-x-auto pb-1">
        <div className="mx-auto min-w-[560px] max-w-[820px]">
          {rows.map((row, rowIndex) => (
            <div key={rowIndex} className="mb-1 flex justify-center gap-1">
              {row.map((key) => {
                const isExpected = expectedGrapheme
                  ? key.base === expectedGrapheme || key.shift === expectedGrapheme
                  : false;
                const isTyped = typedGrapheme
                  ? key.base === typedGrapheme || key.shift === typedGrapheme
                  : false;
                const isHome = layout === "en" && HOME_ROW.includes(key.base);
                const isShiftKey = key.label === "Shift";
                const display = shift && key.shift ? key.shift : key.label ?? key.base;
                const clickable = interactive && Boolean(onKey);
                return (
                  <button
                    key={key.id}
                    type="button"
                    tabIndex={clickable ? 0 : -1}
                    disabled={!clickable}
                    onClick={() => {
                      if (!clickable || !onKey) return;
                      if (isShiftKey) {
                        setShift((value) => !value);
                        return;
                      }
                      if (key.label === "⌫") {
                        onKey("", true);
                        return;
                      }
                      if (key.base === "Tab" || key.base === "Caps" || key.base === "Ctrl" || key.base === "Alt") {
                        return;
                      }
                      const char = layout === "hi" ? (shift ? key.shift : key.base) : shift && key.shift ? key.shift : key.base;
                      if (char) onKey(char, false);
                      if (shift) setShift(false);
                    }}
                    style={{
                      width: `${key.width * (compact ? 34 : 43)}px`,
                      borderBottomColor: FINGER_COLORS[key.finger],
                      borderBottomWidth: 3,
                    }}
                    className={`relative grid h-9 place-items-center rounded-md border border-line text-[0.72rem] font-semibold transition ${
                      isExpected
                        ? "bg-brand text-white shadow-[0_0_0_2px_var(--brand)]"
                        : isTyped
                          ? "bg-success/20 text-ink"
                          : isHome
                            ? "bg-panel text-ink"
                            : "bg-surface text-muted"
                    } ${clickable ? "hover:brightness-110 active:translate-y-px" : "cursor-default"}`}
                    title={`${key.base}${key.shift ? ` / ${key.shift}` : ""} · ${FINGER_LABELS[key.finger]}`}
                  >
                    {display}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {showLegend ? (
        <div className="mt-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 text-[0.62rem] text-muted">
          {(Object.keys(FINGER_COLORS) as Finger[]).map((finger) => (
            <span key={finger} className="inline-flex items-center gap-1">
              <span
                className="inline-block h-2 w-2 rounded-full"
                style={{ background: FINGER_COLORS[finger] }}
              />
              {FINGER_LABELS[finger]}
            </span>
          ))}
          <span className="inline-flex items-center gap-1">
            <span className="inline-block h-2 w-2 rounded-full bg-brand" /> Next key
          </span>
        </div>
      ) : null}
    </div>
  );
}
