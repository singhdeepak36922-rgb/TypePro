"use client";

import Link from "next/link";
import {
  Activity,
  ArrowRight,
  BarChart3,
  CalendarCheck,
  Flame,
  Gauge,
  GraduationCap,
  Keyboard,
  PlayCircle,
  Sparkles,
  Target,
  Timer,
  Trophy,
  Wand2,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { ActivityChart, WpmChart } from "@/components/charts";
import { Badge, EmptyState, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { formatDuration, formatRelative } from "@/lib/stats";
import type { LessonDTO } from "@/lib/types";

const MODE_LABEL: Record<string, string> = {
  test: "Typing test",
  practice: "Free practice",
  lesson: "Lesson",
  game: "Game",
  hindi: "Hindi typing",
  drill: "Drill",
};

export function DashboardView({ lessons }: { lessons: LessonDTO[] }) {
  const { user, summary, achievements, ready, results, settings } = useProgress();
  const completedSlugs = new Set(
    results.filter((result) => result.mode === "lesson" && result.refId).map((result) => result.refId),
  );
  const nextLesson = lessons.find((lesson) => !completedSlugs.has(lesson.slug)) ?? lessons[0];
  const unlocked = achievements.filter((achievement) => achievement.unlocked);
  const hasData = results.length > 0;

  return (
    <div className="space-y-5">
      <div className="card relative overflow-hidden p-5 sm:p-6">
        <div
          className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle,var(--brand),transparent 70%)" }}
        />
        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-2.5 py-1 text-[0.68rem] font-bold uppercase tracking-[0.14em] text-brand">
              <Sparkles size={12} /> {user ? "Welcome back" : "Guest workspace"}
            </p>
            <h1 className="mt-2.5 text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
              {user ? `Hello, ${user.name.split(" ")[0]}.` : "Master your typing skills."}
            </h1>
            <p className="mt-1.5 max-w-xl text-sm text-muted">
              {hasData
                ? `You have saved ${results.length} session${results.length === 1 ? "" : "s"} and typed for ${formatDuration(
                    summary.totalPracticeSeconds,
                  )}. Keep the streak alive with a focused session today.`
                : "Start with a 1-minute typing test to create your baseline, then follow the structured lessons. English and Hindi (Devanagari) are both supported."}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Link href="/test" className="btn btn-primary">
                <PlayCircle size={16} /> Quick start typing test
              </Link>
              <Link href="/learn" className="btn btn-ghost">
                <GraduationCap size={16} /> Continue learning
              </Link>
              <Link href="/hindi" className="btn btn-ghost">
                <Wand2 size={16} /> Hindi typing
              </Link>
            </div>
          </div>
          <div className="w-full max-w-xs rounded-xl border border-line bg-panel/60 p-4">
            <div className="flex items-center justify-between">
              <p className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
                Daily practice goal
              </p>
              <Badge tone={summary.goalPercent >= 100 ? "success" : "brand"}>
                {summary.todayMinutes.toFixed(0)}/{settings.dailyGoalMinutes} min
              </Badge>
            </div>
            <div className="mt-2">
              <ProgressBar value={summary.goalPercent} height={10} />
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <MiniStat label="Streak" value={`${summary.streak}d`} />
              <MiniStat label="This week" value={`${summary.weekMinutes.toFixed(0)}m`} />
              <MiniStat label="Tests" value={`${summary.totalTests}`} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard
          label="Practice time"
          value={formatDuration(summary.totalPracticeSeconds)}
          icon={Timer}
          hint={`${summary.totalMinutes.toFixed(0)} minutes total`}
        />
        <StatCard
          label="Typing tests"
          value={summary.totalTests}
          icon={CalendarCheck}
          tone="cyan"
          hint={`${results.length} saved sessions`}
        />
        <StatCard
          label="Average WPM"
          value={summary.avgWpm.toFixed(0)}
          icon={Gauge}
          tone="brand"
          hint="Net WPM across sessions"
        />
        <StatCard
          label="Best WPM"
          value={summary.bestWpm.toFixed(0)}
          icon={Trophy}
          tone="warn"
          hint="Personal record"
        />
        <StatCard
          label="Avg accuracy"
          value={`${summary.avgAccuracy.toFixed(1)}%`}
          icon={Target}
          tone="success"
          hint={`Best ${summary.bestAccuracy.toFixed(1)}%`}
        />
        <StatCard
          label="Streak"
          value={`${summary.streak}d`}
          icon={Flame}
          tone="danger"
          hint={`${unlocked.length} achievements`}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <SectionCard
          title="Weekly activity"
          description="Minutes practised over the last 7 days"
          className="xl:col-span-2"
          action={
            <Link href="/reports" className="btn btn-ghost !py-1.5 !text-xs">
              <BarChart3 size={13} /> Reports
            </Link>
          }
        >
          <ActivityChart data={summary.weekly} height={210} />
        </SectionCard>

        <SectionCard title="Continue learning" description="Your next structured lesson">
          {nextLesson ? (
            <div className="space-y-3">
              <div className="card-flat p-3">
                <div className="flex items-center justify-between">
                  <Badge tone="brand">{nextLesson.level}</Badge>
                  <span className="text-[0.68rem] text-muted">{nextLesson.estMinutes} min</span>
                </div>
                <p className="mt-2 text-sm font-bold text-ink">{nextLesson.title}</p>
                <p className="mt-1 text-xs text-muted">{nextLesson.courseTitle}</p>
                <p className="mt-2 text-[0.7rem] text-muted">Focus: {nextLesson.focus}</p>
                <Link
                  href={`/learn/${nextLesson.slug}`}
                  className="btn btn-primary mt-3 w-full !py-2 !text-xs"
                >
                  Start lesson <ArrowRight size={13} />
                </Link>
              </div>
              <div className="card-flat p-3">
                <p className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
                  Lesson completion
                </p>
                <p className="mt-1 text-lg font-bold text-ink">
                  {completedSlugs.size}
                  <span className="text-xs font-semibold text-muted"> / {lessons.length} lessons</span>
                </p>
                <div className="mt-2">
                  <ProgressBar
                    value={lessons.length ? (completedSlugs.size / lessons.length) * 100 : 0}
                  />
                </div>
                <Link href="/learn" className="mt-3 inline-flex text-xs font-semibold text-brand">
                  Browse all lessons →
                </Link>
              </div>
            </div>
          ) : (
            <EmptyState
              icon={GraduationCap}
              title="Lesson library loading"
              description="Lessons are served from the TypePro course database. Refresh in a moment if they do not appear."
            />
          )}
        </SectionCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <SectionCard
          title="WPM improvement"
          description="Net WPM and accuracy by day"
          className="xl:col-span-2"
        >
          {hasData ? (
            <WpmChart data={summary.monthly} />
          ) : (
            <EmptyState
              icon={Activity}
              title="No performance data yet"
              description="Complete a typing test, lesson or practice session and your real WPM trend will appear here. Nothing is ever simulated."
              action={
                <Link href="/test" className="btn btn-primary !py-2 !text-xs">
                  Take your first test
                </Link>
              }
            />
          )}
        </SectionCard>

        <SectionCard title="Recent history" description="Latest saved sessions">
          {summary.recent.length === 0 ? (
            <EmptyState
              icon={Keyboard}
              title="Your history is empty"
              description="Saved tests, lessons, practices and games appear here. Guest results are stored in this browser; sign in to sync them to an account."
            />
          ) : (
            <ul className="space-y-2">
              {summary.recent.slice(0, 6).map((result) => (
                <li
                  key={result.id}
                  className="flex items-center justify-between gap-2 rounded-lg border border-line bg-panel/40 px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-xs font-semibold text-ink">
                      {result.refTitle || MODE_LABEL[result.mode] || "Session"}
                    </p>
                    <p className="text-[0.66rem] text-muted">
                      {MODE_LABEL[result.mode] ?? result.mode} ·{" "}
                      {formatRelative(result.createdAt)} · {result.language.toUpperCase()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-brand">{result.netWpm.toFixed(0)} WPM</p>
                    <p className="text-[0.66rem] text-muted">{result.accuracy.toFixed(0)}% acc</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </SectionCard>
      </div>

      {!hasData && ready ? (
        <div className="card p-5">
          <h2 className="text-sm font-bold text-ink">How to start</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            {[
              {
                icon: Timer,
                title: "1. Take a baseline test",
                body: "Choose a duration and category. The timer starts on your first keystroke.",
                href: "/test",
                cta: "Go to test",
              },
              {
                icon: GraduationCap,
                title: "2. Follow the lessons",
                body: "Beginner to advanced drills with saved progress and mistake analysis.",
                href: "/learn",
                cta: "Open lessons",
              },
              {
                icon: Target,
                title: "3. Track real progress",
                body: "Reports and achievements unlock from your actual saved sessions only.",
                href: "/reports",
                cta: "View reports",
              },
            ].map((step) => (
              <div key={step.title} className="card-flat p-3">
                <step.icon size={18} className="text-brand" />
                <p className="mt-2 text-xs font-bold text-ink">{step.title}</p>
                <p className="mt-1 text-[0.7rem] leading-relaxed text-muted">{step.body}</p>
                <Link href={step.href} className="mt-2 inline-flex text-[0.7rem] font-semibold text-brand">
                  {step.cta} →
                </Link>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface px-2 py-1.5">
      <p className="text-[0.6rem] font-bold uppercase tracking-[0.08em] text-muted">{label}</p>
      <p className="text-sm font-bold text-ink">{value}</p>
    </div>
  );
}
