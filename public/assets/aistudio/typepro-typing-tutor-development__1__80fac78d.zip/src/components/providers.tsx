"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  addGuestKeyErrors,
  addGuestResult,
  clearGuestData,
  readGuestKeyStats,
  readGuestResults,
  readGuestSettings,
  replaceGuestResults,
  writeGuestSettings,
} from "@/lib/local-store";
import { evaluateAchievements, type AchievementState } from "@/lib/achievements";
import { summarize, type Summary } from "@/lib/stats";
import {
  DEFAULT_SETTINGS,
  type KeyStat,
  type ResultInput,
  type SessionUser,
  type StoredResult,
  type UserSettings,
} from "@/lib/types";

interface ProgressContextValue {
  ready: boolean;
  user: SessionUser | null;
  results: StoredResult[];
  keyStats: KeyStat[];
  settings: UserSettings;
  summary: Summary;
  achievements: AchievementState[];
  newAchievements: AchievementState[];
  guestResultCount: number;
  dismissNewAchievements: () => void;
  saveResult: (input: ResultInput) => Promise<{ unlocked: string[] }>;
  updateSettings: (patch: Partial<UserSettings>) => Promise<void>;
  updateProfile: (patch: { name?: string; currentPassword?: string; newPassword?: string }) => Promise<{
    ok: boolean;
    error?: string;
  }>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
  importGuestHistory: () => Promise<{ imported: number }>;
}

const ProgressContext = createContext<ProgressContextValue | null>(null);

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [results, setResults] = useState<StoredResult[]>([]);
  const [keyStats, setKeyStats] = useState<KeyStat[]>([]);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [newAchievements, setNewAchievements] = useState<AchievementState[]>([]);
  const [guestResultCount, setGuestResultCount] = useState(0);

  const loadGuest = useCallback(() => {
    setResults(readGuestResults());
    setKeyStats(readGuestKeyStats());
    setSettings(readGuestSettings());
  }, []);

  const refresh = useCallback(async () => {
    try {
      const sessionResponse = await fetch("/api/auth/me", { cache: "no-store" });
      const session = (await sessionResponse.json()) as {
        user: SessionUser | null;
        settings: UserSettings;
      };
      if (session.user) {
        setUser(session.user);
        setSettings({ ...DEFAULT_SETTINGS, ...session.settings });
        const resultResponse = await fetch("/api/results", { cache: "no-store" });
        if (resultResponse.ok) {
          const payload = (await resultResponse.json()) as {
            results: StoredResult[];
            keyStats?: KeyStat[];
            summary: Summary;
          };
          setResults(payload.results ?? []);
          if (payload.keyStats) setKeyStats(payload.keyStats);
        }
        const settingsResponse = await fetch("/api/settings", { cache: "no-store" });
        if (settingsResponse.ok) {
          const payload = (await settingsResponse.json()) as { settings: UserSettings };
          setSettings({ ...DEFAULT_SETTINGS, ...payload.settings });
        }
        setGuestResultCount(readGuestResults().length);
      } else {
        setUser(null);
        loadGuest();
        setGuestResultCount(readGuestResults().length);
      }
    } catch {
      setUser(null);
      loadGuest();
    } finally {
      setReady(true);
    }
  }, [loadGuest]);

  useEffect(() => {
    // Initial session hydration from the API / local storage.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void refresh();
  }, [refresh]);

  // Theme application (dark is the default, system honours the OS).
  useEffect(() => {
    const root = document.documentElement;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const dark = settings.theme === "dark" || (settings.theme === "system" && media.matches);
      root.classList.toggle("dark", dark);
      root.dataset.theme = dark ? "dark" : "light";
      root.style.colorScheme = dark ? "dark" : "light";
    };
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [settings.theme]);

  const summary = useMemo(
    () => summarize(results, { keyStats, dailyGoalMinutes: settings.dailyGoalMinutes }),
    [results, keyStats, settings.dailyGoalMinutes],
  );

  const achievements = useMemo(() => evaluateAchievements(summary), [summary]);

  const saveResult = useCallback(
    async (input: ResultInput) => {
      if (user) {
        const response = await fetch("/api/results", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        if (!response.ok) {
          throw new Error("Unable to save your result. Please retry.");
        }
        const payload = (await response.json()) as {
          results: StoredResult[];
          keyStats?: KeyStat[];
          unlocked: string[];
        };
        setResults(payload.results ?? []);
        if (payload.keyStats) {
          setKeyStats(payload.keyStats);
        } else {
          setKeyStats((current) => {
            const map = new Map(current.map((stat) => [stat.key, { ...stat }]));
            for (const error of input.keyErrors ?? []) {
              const key = (error.expected || error.actual || "?").toLowerCase();
              const stat = map.get(key) ?? { key, correct: 0, incorrect: 0 };
              stat.incorrect += 1;
              map.set(key, stat);
            }
            return Array.from(map.values());
          });
        }
        return { unlocked: payload.unlocked ?? [] };
      }

      const previous = summarize(readGuestResults(), {
        keyStats: readGuestKeyStats(),
        dailyGoalMinutes: settings.dailyGoalMinutes,
      });
      addGuestResult(input);
      addGuestKeyErrors(input.keyErrors ?? []);
      const nextResults = readGuestResults();
      const nextStats = readGuestKeyStats();
      setResults(nextResults);
      setKeyStats(nextStats);
      setGuestResultCount(nextResults.length);
      const nextSummary = summarize(nextResults, {
        keyStats: nextStats,
        dailyGoalMinutes: settings.dailyGoalMinutes,
      });
      const before = new Set(evaluateAchievements(previous).filter((a) => a.unlocked).map((a) => a.key));
      const unlocked = evaluateAchievements(nextSummary)
        .filter((achievement) => achievement.unlocked && !before.has(achievement.key))
        .map((achievement) => achievement.key);
      return { unlocked };
    },
    [settings.dailyGoalMinutes, user],
  );

  const updateSettings = useCallback(
    async (patch: Partial<UserSettings>) => {
      setSettings((current) => {
        const next = { ...current, ...patch };
        if (!user) writeGuestSettings(next);
        return next;
      });
      if (user) {
        await fetch("/api/settings", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patch),
        });
      }
    },
    [user],
  );

  const updateProfile = useCallback(
    async (patch: { name?: string; currentPassword?: string; newPassword?: string }) => {
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const payload = (await response.json()) as { user?: SessionUser; error?: string };
      if (!response.ok) return { ok: false, error: payload.error ?? "Update failed." };
      if (payload.user) setUser(payload.user);
      return { ok: true };
    },
    [],
  );

  const signOut = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    loadGuest();
  }, [loadGuest]);

  const importGuestHistory = useCallback(async () => {
    const local = readGuestResults();
    if (!user || local.length === 0) return { imported: 0 };
    const response = await fetch("/api/results", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ results: local }),
    });
    if (!response.ok) throw new Error("Import failed");
    const payload = (await response.json()) as { imported: number; results: StoredResult[] };
    clearGuestData();
    setGuestResultCount(0);
    setResults(payload.results ?? []);
    return { imported: payload.imported ?? 0 };
  }, [user]);

  const dismissNewAchievements = useCallback(() => setNewAchievements([]), []);

  useEffect(() => {
    if (!ready || newAchievements.length > 0) return;
    const unlocked = achievements.filter((achievement) => achievement.unlocked);
    if (unlocked.length === 0) return;
    const storageKey = `typepro.seen.${user?.id ?? "guest"}`;
    try {
      const raw = window.localStorage.getItem(storageKey);
      const seen = raw ? (JSON.parse(raw) as { keys: string[] }) : { keys: [] };
      const fresh = unlocked.filter((achievement) => !seen.keys.includes(achievement.key));
      if (fresh.length > 0) {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setNewAchievements(fresh);
        window.localStorage.setItem(
          storageKey,
          JSON.stringify({ keys: [...seen.keys, ...fresh.map((item) => item.key)] }),
        );
      } else if (raw === null) {
        window.localStorage.setItem(storageKey, JSON.stringify({ keys: [] }));
      }
    } catch {
      // ignore storage errors
    }
  }, [achievements, newAchievements.length, ready, user?.id]);

  const value = useMemo<ProgressContextValue>(
    () => ({
      ready,
      user,
      results,
      keyStats,
      settings,
      summary,
      achievements,
      newAchievements,
      guestResultCount,
      dismissNewAchievements,
      saveResult,
      updateSettings,
      updateProfile,
      signOut,
      refresh,
      importGuestHistory,
    }),
    [
      ready,
      user,
      results,
      keyStats,
      settings,
      summary,
      achievements,
      newAchievements,
      guestResultCount,
      dismissNewAchievements,
      saveResult,
      updateSettings,
      updateProfile,
      signOut,
      refresh,
      importGuestHistory,
    ],
  );

  return <ProgressContext.Provider value={value}>{children}</ProgressContext.Provider>;
}

export function useProgress(): ProgressContextValue {
  const context = useContext(ProgressContext);
  if (!context) throw new Error("useProgress must be used inside ProgressProvider");
  return context;
}

export { replaceGuestResults };
