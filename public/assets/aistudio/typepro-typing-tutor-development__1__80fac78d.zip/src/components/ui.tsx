import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";

export function PageHeader({
  title,
  description,
  action,
  eyebrow,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  eyebrow?: string;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <p className="mb-1 text-[0.68rem] font-bold uppercase tracking-[0.2em] text-brand">{eyebrow}</p>
        ) : null}
        <h1 className="text-2xl font-bold tracking-tight text-ink sm:text-[1.7rem]">{title}</h1>
        {description ? <p className="mt-1 max-w-2xl text-sm text-muted">{description}</p> : null}
      </div>
      {action ? <div className="flex flex-wrap items-center gap-2">{action}</div> : null}
    </div>
  );
}

export function StatCard({
  label,
  value,
  suffix,
  hint,
  icon: Icon,
  tone = "brand",
}: {
  label: string;
  value: string | number;
  suffix?: string;
  hint?: string;
  icon: LucideIcon;
  tone?: "brand" | "cyan" | "success" | "warn" | "danger";
}) {
  const tones: Record<string, string> = {
    brand: "bg-brand-soft text-brand",
    cyan: "bg-[color-mix(in_srgb,var(--cyan)_14%,transparent)] text-cyan",
    success: "bg-[color-mix(in_srgb,var(--success)_14%,transparent)] text-success",
    warn: "bg-[color-mix(in_srgb,var(--warn)_16%,transparent)] text-warn",
    danger: "bg-[color-mix(in_srgb,var(--danger)_14%,transparent)] text-danger",
  };
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-[0.11em] text-muted">{label}</p>
        <span className={`grid h-8 w-8 place-items-center rounded-lg ${tones[tone]}`}>
          <Icon size={16} strokeWidth={2.2} />
        </span>
      </div>
      <p className="mt-2.5 flex items-baseline gap-1 text-[1.7rem] font-bold leading-none text-ink">
        {value}
        {suffix ? <span className="text-xs font-semibold text-muted">{suffix}</span> : null}
      </p>
      {hint ? <p className="mt-1.5 text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

export function ProgressBar({
  value,
  tone = "brand",
  height = 8,
}: {
  value: number;
  tone?: "brand" | "success" | "cyan" | "warn";
  height?: number;
}) {
  const tones: Record<string, string> = {
    brand: "bg-gradient-to-r from-brand to-cyan",
    success: "bg-success",
    cyan: "bg-cyan",
    warn: "bg-warn",
  };
  return (
    <div
      className="w-full overflow-hidden rounded-full bg-panel"
      style={{ height }}
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={`h-full rounded-full transition-all duration-500 ${tones[tone]}`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-line px-6 py-10 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-soft text-brand">
        <Icon size={22} />
      </span>
      <h3 className="mt-3 text-sm font-bold text-ink">{title}</h3>
      <p className="mt-1 max-w-md text-xs leading-relaxed text-muted">{description}</p>
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "brand" | "success" | "warn" | "danger";
}) {
  const tones: Record<string, string> = {
    neutral: "border-line text-muted",
    brand: "border-transparent bg-brand-soft text-brand",
    success:
      "border-transparent bg-[color-mix(in_srgb,var(--success)_14%,transparent)] text-success",
    warn: "border-transparent bg-[color-mix(in_srgb,var(--warn)_16%,transparent)] text-warn",
    danger: "border-transparent bg-[color-mix(in_srgb,var(--danger)_14%,transparent)] text-danger",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[0.68rem] font-semibold ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function SectionCard({
  title,
  description,
  action,
  children,
  className = "",
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`card p-4 sm:p-5 ${className}`}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-ink">{title}</h2>
          {description ? <p className="mt-0.5 text-xs text-muted">{description}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}
