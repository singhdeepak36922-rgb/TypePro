"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowRight, BarChart3, FileText, RefreshCw, Timer } from "lucide-react";
import { useProgress } from "@/components/providers";
import { TypingSurface } from "@/components/typing-surface";
import { Badge, PageHeader, SectionCard } from "@/components/ui";
import { CATEGORIES, DURATIONS, type PassageDTO } from "@/lib/types";

const DURATION_LABEL: Record<number, string> = {
  60: "1 min",
  120: "2 min",
  180: "3 min",
  300: "5 min",
  600: "10 min",
  900: "15 min",
};

function matchesCategory(passage: PassageDTO, category: string): boolean {
  if (!category) return true;
  if (category === "general-english") {
    return passage.language === "en" && ["general-english", "intermediate", "advanced"].includes(passage.category);
  }
  if (category === "general-hindi") {
    return passage.language === "hi";
  }
  return passage.category === category || passage.difficulty === category;
}

export function TestRunner({ passages }: { passages: PassageDTO[] }) {
  const { settings, updateSettings } = useProgress();
  const [duration, setDuration] = useState<number>(settings.defaultDuration || 60);
  const [category, setCategory] = useState<string>(
    CATEGORIES.some((item) => item.value === settings.defaultCategory)
      ? settings.defaultCategory
      : "beginner",
  );
  const [index, setIndex] = useState(0);
  const [sessionKey, setSessionKey] = useState(0);

  const filtered = useMemo(() => {
    const list = passages.filter((passage) => matchesCategory(passage, category));
    return list.length > 0 ? list : passages;
  }, [category, passages]);

  const passage = filtered[index % Math.max(1, filtered.length)];

  const nextPassage = () => {
    setIndex((current) => (current + 1) % Math.max(1, filtered.length));
    setSessionKey((current) => current + 1);
  };

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Timed assessment"
        title="Typing test"
        description="Choose a duration and category, then start typing. The timer begins on your first keystroke, stops at the selected duration, and your result is saved automatically."
        action={
          <Link href="/reports" className="btn btn-ghost">
            <BarChart3 size={15} /> View reports
          </Link>
        }
      />

      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
            <Timer size={12} className="mr-1 inline" /> Duration
          </span>
          {DURATIONS.map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => {
                setDuration(value);
                setSessionKey((current) => current + 1);
                void updateSettings({ defaultDuration: value });
              }}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                duration === value
                  ? "bg-brand text-white"
                  : "border border-line bg-surface text-muted hover:text-ink"
              }`}
            >
              {DURATION_LABEL[value]}
            </button>
          ))}
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((item) => (
            <button
              key={item.value}
              type="button"
              onClick={() => {
                setCategory(item.value);
                setIndex(0);
                setSessionKey((current) => current + 1);
                void updateSettings({ defaultCategory: item.value });
              }}
              className={`rounded-xl border p-3 text-left transition ${
                category === item.value
                  ? "border-brand bg-brand-soft"
                  : "border-line bg-surface hover:bg-panel"
              }`}
            >
              <p className={`text-xs font-bold ${category === item.value ? "text-brand" : "text-ink"}`}>
                {item.label}
              </p>
              <p className="mt-0.5 text-[0.68rem] text-muted">{item.description}</p>
            </button>
          ))}
        </div>
      </div>

      {passage ? (
        <SectionCard
          title={passage.title}
          description={`${passage.language === "hi" ? "Hindi" : "English"} · ${passage.difficulty} · ${
            passage.wordCount
          } words`}
          action={
            <div className="flex items-center gap-2">
              <Badge tone={duration <= 60 ? "brand" : "neutral"}>{DURATION_LABEL[duration] ?? `${duration}s`}</Badge>
              <button type="button" onClick={nextPassage} className="btn btn-ghost !py-1.5 !text-xs">
                <RefreshCw size={13} /> New passage
              </button>
            </div>
          }
        >
          <TypingSurface
            key={`${duration}-${category}-${passage.slug}-${sessionKey}`}
            target={passage.content}
            language={passage.language}
            durationSeconds={duration}
            mode="test"
            refId={passage.slug}
            refTitle={passage.title}
            allowVirtualInput={passage.language === "hi"}
            restartLabel="Restart test"
            resultActions={
              <>
                <button type="button" onClick={nextPassage} className="btn btn-ghost">
                  <FileText size={15} /> Next passage
                </button>
                <Link href="/reports" className="btn btn-ghost">
                  <ArrowRight size={15} /> Performance reports
                </Link>
              </>
            }
          />
          <p className="mt-3 text-[0.7rem] leading-relaxed text-muted">
            Scoring: WPM = correct characters ÷ 5 ÷ elapsed minutes. Net WPM subtracts uncorrected errors per
            minute. Accuracy is measured on your final text, while keystroke errors are tracked separately so
            corrected mistakes are still visible in your reports.
          </p>
        </SectionCard>
      ) : (
        <div className="card p-6 text-center text-sm text-muted">
          No passages available for this category. The passage library is seeded automatically on first load.
        </div>
      )}
    </div>
  );
}
