"use client";

import Link from "next/link";
import {
  BookOpen,
  Calendar,
  Flag,
  Flame,
  Gauge,
  Gem,
  Languages,
  Layers,
  Lock,
  Rocket,
  Target,
  Trophy,
  Zap,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { Badge, PageHeader, ProgressBar, SectionCard } from "@/components/ui";

const ICONS = {
  flag: Flag,
  gauge: Gauge,
  zap: Zap,
  rocket: Rocket,
  trophy: Trophy,
  target: Target,
  gem: Gem,
  flame: Flame,
  calendar: Calendar,
  book: BookOpen,
  layers: Layers,
  languages: Languages,
} as const;

const TIER_TONE: Record<string, "neutral" | "brand" | "success" | "warn" | "danger"> = {
  bronze: "warn",
  silver: "neutral",
  gold: "warn",
  platinum: "brand",
};

export function AchievementsView() {
  const { achievements, summary } = useProgress();
  const unlocked = achievements.filter((achievement) => achievement.unlocked);

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Milestones"
        title="Achievements"
        description="Achievements unlock only from your saved performance. Progress bars show exactly how far you are from each milestone."
        action={
          <Badge tone="brand">
            {unlocked.length} of {achievements.length} unlocked
          </Badge>
        }
      />

      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <p className="text-sm font-bold text-ink">Collection progress</p>
            <p className="text-xs text-muted">
              Best WPM {summary.bestWpm.toFixed(0)} · best accuracy {summary.bestAccuracy.toFixed(1)}% · streak{" "}
              {summary.streak} days
            </p>
          </div>
          <span className="text-lg font-bold text-brand">
            {achievements.length ? Math.round((unlocked.length / achievements.length) * 100) : 0}%
          </span>
        </div>
        <div className="mt-3">
          <ProgressBar
            value={achievements.length ? (unlocked.length / achievements.length) * 100 : 0}
            height={10}
          />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {achievements.map((achievement) => {
          const Icon = ICONS[achievement.icon as keyof typeof ICONS] ?? Trophy;
          return (
            <div
              key={achievement.key}
              className={`card p-4 transition ${
                achievement.unlocked ? "border-success/40" : "opacity-90"
              }`}
            >
              <div className="flex items-start justify-between">
                <span
                  className={`grid h-11 w-11 place-items-center rounded-xl ${
                    achievement.unlocked ? "bg-brand-soft text-brand" : "bg-panel text-muted"
                  }`}
                >
                  <Icon size={20} />
                </span>
                {achievement.unlocked ? (
                  <Badge tone="success">Unlocked</Badge>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[0.68rem] font-semibold text-muted">
                    <Lock size={11} /> Locked
                  </span>
                )}
              </div>
              <h3 className="mt-2.5 text-sm font-bold text-ink">{achievement.title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-muted">{achievement.description}</p>
              <div className="mt-3">
                <ProgressBar value={achievement.progress} tone={achievement.unlocked ? "success" : "brand"} />
                <div className="mt-1 flex items-center justify-between">
                  <span className="text-[0.65rem] uppercase tracking-[0.08em] text-muted">
                    {achievement.tier}
                  </span>
                  <span className="text-[0.65rem] font-semibold text-muted">
                    {achievement.unlocked ? "Complete" : `${achievement.progress}%`}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <SectionCard title="Need a new milestone?" description="Suggested next steps based on your activity">
        <div className="grid gap-2 sm:grid-cols-3">
          {[
            { title: "Push your WPM", body: "Take a 2-minute test after your accuracy is stable.", href: "/test", cta: "Typing test" },
            { title: "Practise a lesson", body: "Structured drills target the keys you miss most.", href: "/learn", cta: "Lessons" },
            { title: "Try Hindi", body: "Devanagari sessions unlock the bilingual achievement.", href: "/hindi", cta: "Hindi typing" },
          ].map((item) => (
            <div key={item.title} className="card-flat p-3">
              <p className="text-xs font-bold text-ink">{item.title}</p>
              <p className="mt-1 text-[0.7rem] text-muted">{item.body}</p>
              <Link href={item.href} className="mt-2 inline-flex text-[0.7rem] font-semibold text-brand">
                {item.cta} →
              </Link>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}
