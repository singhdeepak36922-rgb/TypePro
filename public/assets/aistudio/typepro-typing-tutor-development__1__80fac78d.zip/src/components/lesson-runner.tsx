"use client";

import Link from "next/link";
import { ArrowLeft, ArrowRight, BookOpen, Info } from "lucide-react";
import { useProgress } from "@/components/providers";
import { TypingSurface } from "@/components/typing-surface";
import { Badge, PageHeader, SectionCard } from "@/components/ui";
import type { LessonDTO } from "@/lib/types";

export function LessonRunner({
  lesson,
  nextLesson,
  previousLesson,
  total,
  position,
}: {
  lesson: LessonDTO;
  nextLesson: LessonDTO | null;
  previousLesson: LessonDTO | null;
  total: number;
  position: number;
}) {
  const { results } = useProgress();
  const attempts = results.filter((result) => result.mode === "lesson" && result.refId === lesson.slug);
  const best = attempts.reduce(
    (accumulator, result) => ({
      wpm: Math.max(accumulator.wpm, result.netWpm),
      accuracy: Math.max(accumulator.accuracy, result.accuracy),
    }),
    { wpm: 0, accuracy: 0 },
  );

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow={`${lesson.level} · lesson ${position} of ${total}`}
        title={lesson.title}
        description={lesson.instructions}
        action={
          <>
            {previousLesson ? (
              <Link href={`/learn/${previousLesson.slug}`} className="btn btn-ghost">
                <ArrowLeft size={15} /> Previous
              </Link>
            ) : null}
            {nextLesson ? (
              <Link href={`/learn/${nextLesson.slug}`} className="btn btn-ghost">
                Next <ArrowRight size={15} />
              </Link>
            ) : null}
            <Link href="/learn" className="btn btn-soft">
              <BookOpen size={15} /> All lessons
            </Link>
          </>
        }
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="card-flat px-3 py-2.5">
          <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Focus area</p>
          <p className="mt-0.5 text-sm font-semibold text-ink">{lesson.focus}</p>
        </div>
        <div className="card-flat px-3 py-2.5">
          <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Best WPM</p>
          <p className="mt-0.5 text-sm font-semibold text-brand">{best.wpm ? best.wpm.toFixed(0) : "—"}</p>
        </div>
        <div className="card-flat px-3 py-2.5">
          <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Best accuracy</p>
          <p className="mt-0.5 text-sm font-semibold text-success">
            {best.accuracy ? `${best.accuracy.toFixed(0)}%` : "—"}
          </p>
        </div>
      </div>

      <SectionCard
        title="Typing exercise"
        description="Complete the exercise exactly as written. Your result is saved to lesson progress."
        action={<Badge tone="brand">{lesson.estMinutes} min target</Badge>}
      >
        <TypingSurface
          target={lesson.content}
          language={lesson.language}
          durationSeconds={0}
          mode="lesson"
          refId={lesson.slug}
          refTitle={lesson.title}
          instructions={lesson.instructions}
          allowVirtualInput={lesson.language === "hi"}
          restartLabel="Retry lesson"
          resultActions={
            nextLesson ? (
              <Link href={`/learn/${nextLesson.slug}`} className="btn btn-primary">
                Next lesson <ArrowRight size={15} />
              </Link>
            ) : (
              <Link href="/test" className="btn btn-primary">
                Take a typing test <ArrowRight size={15} />
              </Link>
            )
          }
        />
      </SectionCard>

      <div className="card p-4">
        <div className="flex items-start gap-2">
          <Info size={16} className="mt-0.5 shrink-0 text-brand" />
          <div>
            <p className="text-xs font-bold text-ink">How this lesson is scored</p>
            <p className="mt-1 text-[0.72rem] leading-relaxed text-muted">
              A lesson is marked complete at 90% or higher final-text accuracy. Every attempt is stored, and
              your best WPM and accuracy are kept. Keystroke errors (including corrected ones) are recorded
              separately for mistake analysis, and the keys you miss feed the weak-key report.
            </p>
            {attempts.length > 0 ? (
              <p className="mt-2 text-[0.7rem] text-muted">
                Attempts saved: <span className="font-semibold text-ink">{attempts.length}</span>
              </p>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
