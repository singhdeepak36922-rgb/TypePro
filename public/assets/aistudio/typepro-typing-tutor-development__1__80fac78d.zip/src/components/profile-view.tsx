"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  Calendar,
  CloudUpload,
  KeyRound,
  LogIn,
  LogOut,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { Badge, PageHeader, ProgressBar, SectionCard } from "@/components/ui";
import { formatDuration } from "@/lib/stats";

export function ProfileView() {
  const router = useRouter();
  const {
    user,
    summary,
    achievements,
    signOut,
    updateProfile,
    importGuestHistory,
    guestResultCount,
    results,
  } = useProgress();
  const [name, setName] = useState(user?.name ?? "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const unlocked = achievements.filter((achievement) => achievement.unlocked).length;

  const handleSaveName = async () => {
    setBusy(true);
    setError(null);
    setMessage(null);
    const result = await updateProfile({ name });
    setBusy(false);
    if (!result.ok) setError(result.error ?? "Unable to update your name.");
    else setMessage("Profile name updated.");
  };

  const handlePassword = async () => {
    setBusy(true);
    setError(null);
    setMessage(null);
    const result = await updateProfile({ currentPassword, newPassword });
    setBusy(false);
    if (!result.ok) {
      setError(result.error ?? "Unable to change your password.");
    } else {
      setMessage("Password changed successfully.");
      setCurrentPassword("");
      setNewPassword("");
    }
  };

  const handleImport = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await importGuestHistory();
      setMessage(`${response.imported} guest session(s) imported into your account.`);
    } catch {
      setError("Import failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Account"
        title="Profile"
        description="Manage your identity, password and data. Guest sessions stay in this browser until you import them."
        action={
          user ? (
            <button
              type="button"
              onClick={async () => {
                await signOut();
                router.push("/");
              }}
              className="btn btn-ghost !text-danger"
            >
              <LogOut size={15} /> Sign out
            </button>
          ) : (
            <Link href="/login" className="btn btn-primary">
              <LogIn size={15} /> Sign in
            </Link>
          )
        }
      />

      <div className="card p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <span className="grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand to-cyan text-2xl font-bold text-white">
            {(user?.name ?? "G").slice(0, 1).toUpperCase()}
          </span>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-lg font-bold text-ink">{user?.name ?? "Guest typist"}</h2>
              <Badge tone={user ? "success" : "warn"}>{user ? "Account synced" : "Guest mode"}</Badge>
            </div>
            <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted">
              <Mail size={12} /> {user?.email ?? "Progress stored locally in this browser"}
            </p>
            {user ? (
              <p className="mt-1 flex items-center gap-1.5 text-[0.7rem] text-muted">
                <Calendar size={12} /> Member since{" "}
                {new Date(user.createdAt).toLocaleDateString("en-US", {
                  month: "long",
                  day: "numeric",
                  year: "numeric",
                })}
              </p>
            ) : (
              <p className="mt-1 text-[0.7rem] text-muted">
                Create a free account to keep history across devices — no typing data is lost, and you can import
                your guest sessions afterwards.
              </p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <ProfileStat label="Sessions" value={`${results.length}`} />
            <ProfileStat label="Best WPM" value={`${summary.bestWpm.toFixed(0)}`} />
            <ProfileStat label="Accuracy" value={`${summary.avgAccuracy.toFixed(0)}%`} />
            <ProfileStat label="Badges" value={`${unlocked}`} />
          </div>
        </div>
      </div>

      {!user ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <SectionCard title="Why create an account?" description="Guest mode is fully functional — an account adds sync">
            <ul className="space-y-2 text-xs text-muted">
              <li className="flex items-start gap-2">
                <ShieldCheck size={14} className="mt-0.5 text-brand" /> Progress stored in PostgreSQL with
                user-scoped access.
              </li>
              <li className="flex items-start gap-2">
                <Sparkles size={14} className="mt-0.5 text-brand" /> Achievements, lesson progress and weak-key
                stats persist across devices.
              </li>
              <li className="flex items-start gap-2">
                <KeyRound size={14} className="mt-0.5 text-brand" /> Password reset, profile management and session
                security included.
              </li>
            </ul>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/register" className="btn btn-primary !py-2 !text-xs">
                Create account
              </Link>
              <Link href="/login" className="btn btn-ghost !py-2 !text-xs">
                Sign in
              </Link>
            </div>
          </SectionCard>
          <SectionCard title="Guest progress" description="Saved in this browser only">
            <p className="text-xs text-muted">
              Sessions stored locally: <span className="font-bold text-ink">{guestResultCount}</span>
            </p>
            <p className="mt-1 text-xs text-muted">
              Total practice time: <span className="font-bold text-ink">{formatDuration(summary.totalPracticeSeconds)}</span>
            </p>
            <div className="mt-3">
              <div className="flex items-center justify-between text-[0.68rem] text-muted">
                <span>Today&apos;s goal</span>
                <span>{summary.goalPercent.toFixed(0)}%</span>
              </div>
              <div className="mt-1">
                <ProgressBar value={summary.goalPercent} />
              </div>
            </div>
          </SectionCard>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <SectionCard title="Profile details" description="Your display name">
            <label className="label" htmlFor="profile-name">
              Full name
            </label>
            <input
              id="profile-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="input"
            />
            <label className="label mt-3" htmlFor="profile-email">
              Email
            </label>
            <input id="profile-email" value={user.email} disabled className="input opacity-70" />
            <button
              type="button"
              onClick={() => void handleSaveName()}
              disabled={busy || name.trim().length < 2}
              className="btn btn-primary mt-3 !py-2 !text-xs"
            >
              <UserRound size={13} /> Save profile
            </button>
          </SectionCard>

          <SectionCard title="Change password" description="Passwords are hashed with salted scrypt">
            <label className="label" htmlFor="current-password">
              Current password
            </label>
            <input
              id="current-password"
              type="password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              className="input"
              autoComplete="current-password"
            />
            <label className="label mt-3" htmlFor="new-password">
              New password (min 8 characters)
            </label>
            <input
              id="new-password"
              type="password"
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              className="input"
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={() => void handlePassword()}
              disabled={busy || newPassword.length < 8 || currentPassword.length === 0}
              className="btn btn-primary mt-3 !py-2 !text-xs"
            >
              <KeyRound size={13} /> Update password
            </button>
            <p className="mt-2 text-[0.68rem] text-muted">
              Forgot your password?{" "}
              <Link href="/forgot-password" className="font-semibold text-brand">
                Reset with a token
              </Link>
            </p>
          </SectionCard>
        </div>
      )}

      {message ? <p className="text-xs font-semibold text-success">{message}</p> : null}
      {error ? <p className="text-xs font-semibold text-danger">{error}</p> : null}

      {user ? (
        <SectionCard title="Data" description="Cloud sync and imports">
          <div className="flex flex-wrap items-center gap-2">
            {guestResultCount > 0 ? (
              <button
                type="button"
                onClick={() => void handleImport()}
                disabled={busy}
                className="btn btn-primary !py-2 !text-xs"
              >
                <CloudUpload size={13} /> Import {guestResultCount} local session(s)
              </button>
            ) : (
              <Badge tone="success">
                <ShieldCheck size={12} /> All sessions synced
              </Badge>
            )}
            <Link href="/settings" className="btn btn-ghost !py-2 !text-xs">
              Manage preferences
            </Link>
            <Link href="/reports" className="btn btn-ghost !py-2 !text-xs">
              View reports
            </Link>
          </div>
          <p className="mt-2 text-[0.68rem] text-muted">
            Importing copies each local session into your account exactly once, then clears the browser copy.
          </p>
        </SectionCard>
      ) : null}
    </div>
  );
}

function ProfileStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card-flat px-2.5 py-2 text-center">
      <p className="text-[0.6rem] font-bold uppercase tracking-[0.08em] text-muted">{label}</p>
      <p className="text-sm font-bold text-ink">{value}</p>
    </div>
  );
}
