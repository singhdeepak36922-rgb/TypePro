"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Clock,
  Flag,
  Gamepad2,
  Play,
  RefreshCw,
  Target,
  Trophy,
  Zap,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { TypingSurface } from "@/components/typing-surface";
import { Badge, PageHeader, ProgressBar, SectionCard } from "@/components/ui";
import { computeMetrics, toGraphemes } from "@/lib/typing-engine";
import type { PassageDTO, ResultInput } from "@/lib/types";

const WORD_POOL = [
  "focus", "typing", "rhythm", "speed", "accuracy", "practice", "keyboard", "letters", "improve",
  "session", "master", "lesson", "report", "steady", "control", "screen", "fingers", "progress",
  "clean", "target", "result", "daily", "habit", "review", "record", "sprint", "challenge", "method",
];

interface GameMeta {
  slug: string;
  title: string;
  description: string;
  instructions: string;
  duration: number;
  icon: typeof Zap;
  tone: string;
}

const GAMES: GameMeta[] = [
  {
    slug: "speed-challenge",
    title: "Speed Challenge",
    description: "Type as many words as possible in 30 seconds.",
    instructions: "Type each word and press Space to submit. Correct words add 10 points plus a streak bonus.",
    duration: 30,
    icon: Zap,
    tone: "text-brand",
  },
  {
    slug: "word-challenge",
    title: "Word Challenge",
    description: "Precision round: 20 words, 45 seconds.",
    instructions: "Words get longer as you progress. One point per correct character, minus errors.",
    duration: 45,
    icon: Target,
    tone: "text-cyan",
  },
  {
    slug: "accuracy-challenge",
    title: "Accuracy Challenge",
    description: "Official passage, 45 seconds, accuracy weighted.",
    instructions: "Type the passage as precisely as possible. Score = accuracy ÷ 10 + net WPM × 2.",
    duration: 45,
    icon: Trophy,
    tone: "text-success",
  },
  {
    slug: "time-attack",
    title: "Time Attack",
    description: "15 seconds. Rapid fire words. No penalty.",
    instructions: "Every correct word is 5 points. Wrong entries reset your streak but do not subtract points.",
    duration: 15,
    icon: Clock,
    tone: "text-warn",
  },
  {
    slug: "typing-race",
    title: "Typing Race",
    description: "Race a bot over a full passage.",
    instructions: "The bot types at 32 WPM. Beat it to the finish line for double points.",
    duration: 90,
    icon: Flag,
    tone: "text-danger",
  },
];

export function GamesHub({ passages }: { passages: PassageDTO[] }) {
  const [active, setActive] = useState<string | null>(null);
  const { summary } = useProgress();
  const game = GAMES.find((item) => item.slug === active) ?? null;

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Practice through play"
        title="Typing games"
        description="Five playable drills with real scoring. Best scores are stored with your other sessions and appear in your reports."
        action={
          game ? (
            <button type="button" onClick={() => setActive(null)} className="btn btn-ghost">
              <ArrowLeft size={15} /> All games
            </button>
          ) : (
            <Badge tone="brand">
              <Gamepad2 size={12} /> {Object.keys(summary.bestGameScores).length}/5 games played
            </Badge>
          )
        }
      />

      {!game ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {GAMES.map((item) => {
              const best = summary.bestGameScores[item.slug] ?? 0;
              return (
                <div key={item.slug} className="card flex h-full flex-col p-4">
                  <div className="flex items-start justify-between">
                    <span className={`grid h-10 w-10 place-items-center rounded-xl bg-panel ${item.tone}`}>
                      <item.icon size={19} />
                    </span>
                    <Badge tone={best > 0 ? "success" : "neutral"}>
                      {best > 0 ? `Best ${best}` : "Not played"}
                    </Badge>
                  </div>
                  <h3 className="mt-2.5 text-sm font-bold text-ink">{item.title}</h3>
                  <p className="mt-1 flex-1 text-xs leading-relaxed text-muted">{item.description}</p>
                  <p className="mt-2 text-[0.68rem] text-muted">{item.instructions}</p>
                  <button
                    type="button"
                    onClick={() => setActive(item.slug)}
                    className="btn btn-primary mt-3 w-full !py-2 !text-xs"
                  >
                    <Play size={13} /> Play
                  </button>
                </div>
              );
            })}
          </div>
          <p className="text-center text-[0.7rem] text-muted">
            Games use the same Unicode-aware engine as typing tests, so Hindi grapheme clusters and accuracy are
            scored consistently.
          </p>
        </>
      ) : (
        <SectionCard
          title={game.title}
          description={game.instructions}
          action={<Badge tone="brand">{game.duration}s</Badge>}
        >
          {active === "accuracy-challenge" ? (
            <AccuracyGame passage={passages.find((item) => item.language === "en") ?? null} />
          ) : active === "typing-race" ? (
            <RaceGame passage={passages.find((item) => item.language === "en" && item.wordCount > 30) ?? passages[0] ?? null} />
          ) : (
            <WordGame game={game} />
          )}
        </SectionCard>
      )}
    </div>
  );
}

function useCountdown(seconds: number, running: boolean, onEnd: () => void) {
  const [remaining, setRemaining] = useState(seconds);
  const endedRef = useRef(false);
  const onEndRef = useRef(onEnd);

  useEffect(() => {
    onEndRef.current = onEnd;
  }, [onEnd]);

  useEffect(() => {
    if (!running) return;
    const deadline = Date.now() + seconds * 1000;
    // Reset the visible countdown when a fresh run starts.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setRemaining(seconds);
    endedRef.current = false;
    const interval = window.setInterval(() => {
      const left = Math.max(0, deadline - Date.now());
      setRemaining(Math.ceil(left / 1000));
      if (left <= 0 && !endedRef.current) {
        endedRef.current = true;
        window.clearInterval(interval);
        onEndRef.current();
      }
    }, 100);
    return () => window.clearInterval(interval);
  }, [running, seconds]);

  return remaining;
}

function WordGame({ game }: { game: GameMeta }) {
  const { saveResult, summary } = useProgress();
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);
  const [input, setInput] = useState("");
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [streak, setStreak] = useState(0);
  const [wordIndex, setWordIndex] = useState(0);
  const [saved, setSaved] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const pool = WORDS_BY_GAME[game.slug] ?? WORD_POOL;
  const currentWord = pool[wordIndex % pool.length];
  const best = summary.bestGameScores[game.slug] ?? 0;

  const endGame = useCallback(() => {
    setRunning(false);
    setFinished(true);
    setSaved(false);
    const elapsedSeconds = game.duration;
    const correctChars = correct * (game.slug === "word-challenge" ? 8 : 5);
    const metrics = computeMetrics({
      target: "x".repeat(Math.max(correctChars, 1)),
      typed: "x".repeat(Math.max(correctChars, 1)),
      elapsedMs: elapsedSeconds * 1000,
    });
    const payload: ResultInput = {
      mode: "game",
      refId: game.slug,
      refTitle: game.title,
      language: "en",
      durationSeconds: game.duration,
      elapsedSeconds,
      grossWpm: metrics.grossWpm,
      netWpm: metrics.netWpm,
      standardWpm: metrics.standardWpm,
      accuracy: correct + wrong > 0 ? Math.round((correct / (correct + wrong)) * 100) : 0,
      errors: wrong,
      totalTyped: correct + wrong,
      correctChars: correct,
      keystrokeErrors: wrong,
      backspaceCount: 0,
      score,
      keyErrors: [],
    };
    saveResult(payload)
      .then(() => setSaved(true))
      .catch(() => setSaved(false));
  }, [correct, game, saveResult, score, wrong]);

  const remaining = useCountdown(game.duration, running, endGame);

  const restart = () => {
    setRunning(true);
    setFinished(false);
    setInput("");
    setScore(0);
    setCorrect(0);
    setWrong(0);
    setStreak(0);
    setWordIndex(0);
    setSaved(false);
    window.setTimeout(() => inputRef.current?.focus(), 40);
  };

  const submit = () => {
    if (!running) return;
    const value = input.trim();
    if (!value) return;
    if (value === currentWord) {
      const bonus = game.slug === "speed-challenge" ? Math.min(streak, 5) * 2 : 0;
      const points = game.slug === "time-attack" ? 5 : game.slug === "word-challenge" ? currentWord.length : 10 + bonus;
      setScore((current) => current + points);
      setCorrect((current) => current + 1);
      setStreak((current) => current + 1);
    } else {
      setWrong((current) => current + 1);
      setStreak(0);
      if (game.slug === "word-challenge") setScore((current) => Math.max(0, current - 1));
    }
    setInput("");
    setWordIndex((current) => current + 1);
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <MiniBox label="Time" value={`${running ? remaining : game.duration}s`} tone="brand" />
        <MiniBox label="Score" value={`${score}`} tone="success" />
        <MiniBox label="Streak" value={`${streak}×`} tone="warn" />
        <MiniBox label="Best" value={`${best}`} />
      </div>

      <div className="card-flat p-4 text-center">
        <p className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
          {game.slug === "time-attack" ? "Quick word" : "Type this word"}
        </p>
        <p className="mt-1 font-mono text-2xl font-bold tracking-wide text-ink">{currentWord}</p>
        <div className="mx-auto mt-3 max-w-sm">
          <input
            ref={inputRef}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === " " || event.key === "Enter") {
                event.preventDefault();
                submit();
              }
            }}
            disabled={!running || finished}
            placeholder={running ? "type and press space…" : "press start to play"}
            className="input text-center font-mono"
            autoComplete="off"
            spellCheck={false}
            aria-label="Game input"
          />
        </div>
        <p className="mt-2 text-[0.68rem] text-muted">
          Correct: {correct} · Missed: {wrong} · Words attempted: {correct + wrong}
        </p>
      </div>

      {finished ? (
        <div className="card-flat border-brand/40 p-3 text-center">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-brand">Game over</p>
          <p className="mt-1 text-2xl font-bold text-ink">{score} points</p>
          <p className="text-xs text-muted">
            {correct} correct · {wrong} missed · best {Math.max(best, score)} ·{" "}
            {saved ? "score saved" : "saving score…"}
          </p>
          <button type="button" onClick={restart} className="btn btn-primary mt-3">
            <RefreshCw size={14} /> Play again
          </button>
        </div>
      ) : (
        <button type="button" onClick={running ? endGame : restart} className="btn btn-primary">
          {running ? <Flag size={14} /> : <Play size={14} />} {running ? "Finish now" : "Start game"}
        </button>
      )}
    </div>
  );
}

const WORDS_BY_GAME: Record<string, string[]> = {
  "speed-challenge": [
    "as", "the", "type", "fast", "home", "row", "keys", "word", "flow", "clean", "focus", "shift",
    "quick", "daily", "speed", "train", "score", "light", "press", "space", "rhythm", "typing",
  ],
  "word-challenge": [
    "manage", "keyboard", "accuracy", "practice", "progress", "challenge", "assessment", "achievement",
    "transcription", "synchronisation", "concentration", "documentation", "responsibility", "professional",
  ],
  "time-attack": [
    "go", "up", "fast", "run", "tap", "hit", "top", "win", "rush", "dash", "zoom", "bolt", "jump",
    "speed", "blast", "sprint", "rocket", "turbo",
  ],
};

function AccuracyGame({ passage }: { passage: PassageDTO | null }) {
  const { saveResult, summary } = useProgress();
  const [score, setScore] = useState<number | null>(null);
  const [saved, setSaved] = useState(false);
  const target = passage?.content ?? "Accuracy is the foundation of typing speed. Type this sentence exactly as it appears.";
  const best = summary.bestGameScores["accuracy-challenge"] ?? 0;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <MiniBox label="Best score" value={`${best}`} />
        <MiniBox label="Target" value="45 seconds" tone="brand" />
        <MiniBox label="Last score" value={score === null ? "—" : `${score}`} tone="success" />
      </div>
      <TypingSurface
        target={target}
        durationSeconds={45}
        mode="game"
        refId="accuracy-challenge"
        refTitle="Accuracy Challenge"
        language="en"
        save={false}
        restartLabel="Restart challenge"
        onFinished={(input) => {
          const gameScore = Math.round(input.accuracy / 10 + input.netWpm * 2);
          setScore(gameScore);
          setSaved(false);
          saveResult({ ...input, mode: "game", score: gameScore })
            .then(() => setSaved(true))
            .catch(() => setSaved(false));
        }}
      />
      {score !== null ? (
        <p className="text-xs text-muted">
          Challenge score: <span className="font-bold text-ink">{score}</span> ·{" "}
          {saved ? "saved" : "saving…"} · best {Math.max(best, score)}
        </p>
      ) : null}
    </div>
  );
}

function RaceGame({ passage }: { passage: PassageDTO | null }) {
  const { saveResult, summary } = useProgress();
  const [running, setRunning] = useState(false);
  const [input, setInput] = useState("");
  const [finished, setFinished] = useState<"player" | "bot" | "timeout" | null>(null);
  const [botChars, setBotChars] = useState(0);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [saved, setSaved] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const savedRef = useRef(false);

  const target = passage?.content ?? "Racing the bot is a great way to test your typing rhythm and accuracy.";
  const targetGraphemes = useMemo(() => toGraphemes(target), [target]);
  const typed = toGraphemes(input);
  const botWpm = 32;
  const best = summary.bestGameScores["typing-race"] ?? 0;

  const endRace = useCallback(
    (winner: "player" | "bot" | "timeout") => {
      if (savedRef.current) return;
      savedRef.current = true;
      setRunning(false);
      setFinished(winner);
      setSaved(false);
      const elapsedSeconds = Math.max(1, Math.round(elapsed / 1000));
      const metrics = computeMetrics({
        target,
        typed: input,
        elapsedMs: elapsed,
      });
      const payload: ResultInput = {
        mode: "game",
        refId: "typing-race",
        refTitle: "Typing Race",
        language: "en",
        durationSeconds: 90,
        elapsedSeconds,
        grossWpm: metrics.grossWpm,
        netWpm: metrics.netWpm,
        standardWpm: metrics.standardWpm,
        accuracy: metrics.accuracy,
        errors: metrics.incorrectChars,
        totalTyped: metrics.totalTyped,
        correctChars: metrics.correctChars,
        keystrokeErrors: metrics.incorrectChars,
        backspaceCount: 0,
        score: Math.round(metrics.correctChars * (winner === "player" ? 2 : 1)),
        keyErrors: metrics.keyErrors.map((error) => ({ expected: error.expected, actual: error.actual })),
      };
      saveResult(payload)
        .then(() => setSaved(true))
        .catch(() => setSaved(false));
    },
    [elapsed, input, saveResult, target],
  );

  useEffect(() => {
    if (!running || startedAt === null) return;
    const interval = window.setInterval(() => {
      const ms = Date.now() - startedAt;
      setElapsed(ms);
      const botProgress = Math.floor((ms / 60000) * botWpm * 5);
      setBotChars(botProgress);
      if (ms >= 90000) endRace("timeout");
    }, 100);
    return () => window.clearInterval(interval);
  }, [botWpm, endRace, running, startedAt]);

  useEffect(() => {
    if (!running) return;
    if (typed.length >= targetGraphemes.length) endRace("player");
    else if (botChars >= targetGraphemes.length) endRace("bot");
  }, [botChars, endRace, running, targetGraphemes.length, typed.length]);

  const restart = () => {
    savedRef.current = false;
    setInput("");
    setBotChars(0);
    setElapsed(0);
    setFinished(null);
    setSaved(false);
    setStartedAt(Date.now());
    setRunning(true);
    window.setTimeout(() => inputRef.current?.focus(), 40);
  };

  const playerProgress = targetGraphemes.length ? (typed.length / targetGraphemes.length) * 100 : 0;
  const botProgress = targetGraphemes.length
    ? Math.min(100, (botChars / targetGraphemes.length) * 100)
    : 0;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <MiniBox label="Time" value={`${(elapsed / 1000).toFixed(1)}s`} tone="brand" />
        <MiniBox label="You" value={`${playerProgress.toFixed(0)}%`} tone="success" />
        <MiniBox label="Bot" value={`${botProgress.toFixed(0)}%`} tone="warn" />
        <MiniBox label="Best" value={`${best}`} />
      </div>

      <div className="card-flat space-y-2 p-3">
        <RaceBar label="You" value={playerProgress} tone="brand" />
        <RaceBar label={`Bot (${botWpm} WPM)`} value={botProgress} tone="warn" />
      </div>

      <div className="card-flat max-h-[180px] overflow-y-auto p-3">
        <p className="passage !text-base">
          {targetGraphemes.map((grapheme, index) => {
            const typedGrapheme = typed[index];
            if (typedGrapheme === undefined) {
              return (
                <span key={index} className={index === typed.length ? "char-current" : "char-pending"}>
                  {grapheme}
                </span>
              );
            }
            return (
              <span key={index} className={typedGrapheme === grapheme ? "char-correct" : "char-incorrect"}>
                {grapheme}
              </span>
            );
          })}
        </p>
      </div>

      <textarea
        ref={inputRef}
        value={input}
        onChange={(event) => setInput(event.target.value)}
        disabled={!running || finished !== null}
        rows={3}
        placeholder={running ? "Type the passage here…" : "Press start race to begin"}
        className="input resize-none font-mono !text-xs"
        aria-label="Race input"
        spellCheck={false}
        autoCapitalize="off"
      />

      {finished ? (
        <div className="card-flat border-brand/40 p-3 text-center">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-brand">
            {finished === "player" ? "You won the race 🏆" : finished === "bot" ? "Bot finished first" : "Time up"}
          </p>
          <p className="mt-1 text-2xl font-bold text-ink">{typed.length} characters</p>
          <p className="text-xs text-muted">
            Score saved: {saved ? "yes" : "saving…"} · best {best}
          </p>
          <button type="button" onClick={restart} className="btn btn-primary mt-3">
            <RefreshCw size={14} /> Race again
          </button>
        </div>
      ) : (
        <button type="button" onClick={running ? () => endRace("timeout") : restart} className="btn btn-primary">
          {running ? <Flag size={14} /> : <Play size={14} />} {running ? "Forfeit race" : "Start race"}
        </button>
      )}
    </div>
  );
}

function RaceBar({ label, value, tone }: { label: string; value: number; tone: "brand" | "warn" }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[0.68rem] font-semibold text-muted">
        <span>{label}</span>
        <span>{value.toFixed(0)}%</span>
      </div>
      <ProgressBar value={value} tone={tone} />
    </div>
  );
}

function MiniBox({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "brand" | "success" | "warn";
}) {
  const tones: Record<string, string> = {
    neutral: "text-ink",
    brand: "text-brand",
    success: "text-success",
    warn: "text-warn",
  };
  return (
    <div className="card-flat px-3 py-2">
      <p className="text-[0.6rem] font-bold uppercase tracking-[0.1em] text-muted">{label}</p>
      <p className={`mt-0.5 text-lg font-bold ${tones[tone]}`}>{value}</p>
    </div>
  );
}
