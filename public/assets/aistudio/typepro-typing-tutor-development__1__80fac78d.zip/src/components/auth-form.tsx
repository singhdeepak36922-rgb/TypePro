"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { AlertCircle, ArrowRight, CheckCircle2, KeyRound, Loader2, LogIn, UserPlus } from "lucide-react";
import { useProgress } from "@/components/providers";

type Mode = "login" | "register" | "reset";

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const { refresh } = useProgress();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [resetToken, setResetToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      if (mode === "login") {
        const response = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        });
        const payload = (await response.json()) as { error?: string };
        if (!response.ok) throw new Error(payload.error ?? "Unable to sign in.");
        await refresh();
        router.push("/");
        router.refresh();
        return;
      }

      if (mode === "register") {
        const response = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, password }),
        });
        const payload = (await response.json()) as { error?: string };
        if (!response.ok) throw new Error(payload.error ?? "Unable to create your account.");
        await refresh();
        router.push("/");
        router.refresh();
        return;
      }

      // reset flow
      if (!resetToken) {
        const response = await fetch("/api/auth/reset-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
        const payload = (await response.json()) as { error?: string; message?: string; token?: string };
        if (!response.ok) throw new Error(payload.error ?? "Unable to start the reset.");
        setMessage(payload.message ?? "Reset token created.");
        if (payload.token) {
          setResetToken(payload.token);
          setToken(payload.token);
        }
        return;
      }

      const response = await fetch("/api/auth/reset-password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password: newPassword }),
      });
      const payload = (await response.json()) as { error?: string; message?: string };
      if (!response.ok) throw new Error(payload.error ?? "Unable to reset the password.");
      setMessage(payload.message ?? "Password updated. You can sign in now.");
      setResetToken(null);
      setPassword("");
      setNewPassword("");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  const titles: Record<Mode, { title: string; description: string; cta: string; icon: typeof LogIn }> = {
    login: {
      title: "Sign in to TypePro",
      description: "Pick up where you left off — your tests, lessons and achievements are synced.",
      cta: "Sign in",
      icon: LogIn,
    },
    register: {
      title: "Create your account",
      description: "Save every session to PostgreSQL and sync your progress across devices.",
      cta: "Create account",
      icon: UserPlus,
    },
    reset: {
      title: "Reset your password",
      description: "Request a reset token, then set a new password. Tokens expire after 60 minutes.",
      cta: "Send reset token",
      icon: KeyRound,
    },
  };

  const meta = titles[mode];
  const Icon = meta.icon;

  return (
    <div className="card p-5 sm:p-6">
      <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-soft text-brand">
        <Icon size={20} />
      </span>
      <h2 className="mt-3 text-xl font-bold text-ink">{meta.title}</h2>
      <p className="mt-1 text-sm text-muted">{meta.description}</p>

      <form onSubmit={submit} className="mt-5 space-y-3">
        {mode === "register" ? (
          <div>
            <label className="label" htmlFor="auth-name">
              Full name
            </label>
            <input
              id="auth-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              required
              minLength={2}
              className="input"
              placeholder="Aarav Sharma"
              autoComplete="name"
            />
          </div>
        ) : null}

        {mode !== "reset" || !resetToken ? (
          <div>
            <label className="label" htmlFor="auth-email">
              Email address
            </label>
            <input
              id="auth-email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
              className="input"
              placeholder="you@example.com"
              autoComplete="email"
            />
          </div>
        ) : null}

        {mode === "login" || mode === "register" ? (
          <div>
            <label className="label" htmlFor="auth-password">
              Password {mode === "register" ? "(min 8 characters)" : ""}
            </label>
            <input
              id="auth-password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
              minLength={mode === "register" ? 8 : 1}
              className="input"
              placeholder="••••••••"
              autoComplete={mode === "register" ? "new-password" : "current-password"}
            />
          </div>
        ) : null}

        {mode === "reset" && resetToken ? (
          <>
            <div>
              <label className="label" htmlFor="auth-token">
                Reset token
              </label>
              <input
                id="auth-token"
                value={token}
                onChange={(event) => setToken(event.target.value)}
                required
                className="input font-mono !text-xs"
              />
            </div>
            <div>
              <label className="label" htmlFor="auth-new-password">
                New password (min 8 characters)
              </label>
              <input
                id="auth-new-password"
                type="password"
                value={newPassword}
                onChange={(event) => setNewPassword(event.target.value)}
                required
                minLength={8}
                className="input"
                autoComplete="new-password"
              />
            </div>
          </>
        ) : null}

        {error ? (
          <p className="flex items-start gap-1.5 rounded-lg bg-[color-mix(in_srgb,var(--danger)_12%,transparent)] px-2.5 py-2 text-xs font-semibold text-danger">
            <AlertCircle size={14} className="mt-0.5 shrink-0" /> {error}
          </p>
        ) : null}
        {message ? (
          <p className="flex items-start gap-1.5 rounded-lg bg-[color-mix(in_srgb,var(--success)_12%,transparent)] px-2.5 py-2 text-xs font-semibold text-success">
            <CheckCircle2 size={14} className="mt-0.5 shrink-0" /> {message}
          </p>
        ) : null}

        <button type="submit" disabled={busy} className="btn btn-primary w-full">
          {busy ? <Loader2 size={15} className="animate-spin" /> : <ArrowRight size={15} />}
          {mode === "reset" && resetToken ? "Update password" : meta.cta}
        </button>
      </form>

      {mode === "login" ? (
        <div className="mt-4 space-y-2 text-center text-xs text-muted">
          <p>
            New to TypePro?{" "}
            <Link href="/register" className="font-semibold text-brand">
              Create an account
            </Link>
          </p>
          <p>
            <Link href="/forgot-password" className="font-semibold text-brand">
              Forgot password?
            </Link>{" "}
            ·{" "}
            <Link href="/" className="font-semibold text-brand">
              Continue as guest
            </Link>
          </p>
        </div>
      ) : mode === "register" ? (
        <p className="mt-4 text-center text-xs text-muted">
          Already registered?{" "}
          <Link href="/login" className="font-semibold text-brand">
            Sign in
          </Link>
        </p>
      ) : (
        <p className="mt-4 text-center text-xs text-muted">
          Remembered it?{" "}
          <Link href="/login" className="font-semibold text-brand">
            Back to sign in
          </Link>
        </p>
      )}
    </div>
  );
}
