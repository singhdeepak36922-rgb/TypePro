"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Gauge,
  RefreshCw,
  Save,
  Target,
  Zap,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { VirtualKeyboard } from "@/components/virtual-keyboard";
import { playTone } from "@/lib/sound";
import { computeMetrics, toGraphemes } from "@/lib/typing-engine";
import type { Language, ResultInput, TypingMode } from "@/lib/types";

export interface TypingSurfaceProps {
  target: string;
  language?: Language;
  durationSeconds?: number;
  mode: TypingMode;
  refId?: string;
  refTitle?: string;
  showKeyboard?: boolean;
  allowVirtualInput?: boolean;
  save?: boolean;
  restartLabel?: string;
  onFinished?: (input: ResultInput) => void;
  onRestart?: () => void;
  resultActions?: ReactNode;
  compact?: boolean;
  instructions?: string;
}

type Status = "idle" | "running" | "finished";

export function TypingSurface({
  target,
  language = "en",
  durationSeconds = 0,
  mode,
  refId,
  refTitle,
  showKeyboard,
  allowVirtualInput = false,
  save = true,
  restartLabel = "Restart",
  onFinished,
  onRestart,
  resultActions,
  compact = false,
  instructions,
}: TypingSurfaceProps) {
  const { settings, saveResult } = useProgress();
  const targetGraphemes = useMemo(() => toGraphemes(target), [target]);
  const keyboardEnabled = showKeyboard ?? settings.showKeyboard;

  const [typed, setTyped] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [now, setNow] = useState(() => Date.now());
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [keystrokeErrors, setKeystrokeErrors] = useState(0);
  const [backspaceCount, setBackspaceCount] = useState(0);
  const [finishedElapsed, setFinishedElapsed] = useState<number | null>(null);
  const [saved, setSaved] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [saveError, setSaveError] = useState<string | null>(null);
  const [lastKeyOk, setLastKeyOk] = useState<boolean | null>(null);

  const typedRef = useRef("");
  const startedAtRef = useRef<number | null>(null);
  const keystrokeRef = useRef(0);
  const backspaceRef = useRef(0);
  const scoredRef = useRef(0);
  const finishedRef = useRef(false);
  const savedRef = useRef(false);
  const composingRef = useRef(false);
  const keyErrorsRef = useRef<{ expected: string; actual: string }[]>([]);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const currentRef = useRef<HTMLSpanElement | null>(null);

  const elapsedMs = useMemo(() => {
    if (finishedElapsed !== null) return finishedElapsed;
    if (startedAt === null) return 0;
    const raw = now - startedAt;
    return durationSeconds > 0 ? Math.min(raw, durationSeconds * 1000) : Math.max(0, raw);
  }, [durationSeconds, finishedElapsed, now, startedAt]);

  const metrics = useMemo(
    () =>
      computeMetrics({
        target,
        typed,
        elapsedMs,
        keystrokeErrors,
        backspaceCount,
      }),
    [backspaceCount, elapsedMs, keystrokeErrors, target, typed],
  );

  const typedGraphemes = useMemo(() => toGraphemes(typed), [typed]);
  const remainingSeconds =
    durationSeconds > 0 ? Math.max(0, Math.ceil(durationSeconds - elapsedMs / 1000)) : null;

  const finish = useCallback(
    (typedOverride?: string) => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      const finalTyped = typedOverride ?? typedRef.current;
      const start = startedAtRef.current;
      const rawElapsed = start ? Date.now() - start : 0;
      const finalElapsed =
        durationSeconds > 0 ? Math.min(rawElapsed, durationSeconds * 1000) : Math.max(0, rawElapsed);
      setFinishedElapsed(finalElapsed);
      setStatus("finished");
      const finalMetrics = computeMetrics({
        target,
        typed: finalTyped,
        elapsedMs: finalElapsed,
        keystrokeErrors: keystrokeRef.current,
        backspaceCount: backspaceRef.current,
      });
      const payload: ResultInput = {
        mode,
        refId: refId ?? null,
        refTitle: refTitle ?? "",
        language,
        durationSeconds,
        elapsedSeconds: Math.round(finalElapsed / 1000),
        grossWpm: finalMetrics.grossWpm,
        netWpm: finalMetrics.netWpm,
        standardWpm: finalMetrics.standardWpm,
        accuracy: finalMetrics.accuracy,
        errors: finalMetrics.incorrectChars,
        totalTyped: finalMetrics.totalTyped,
        correctChars: finalMetrics.correctChars,
        keystrokeErrors: keystrokeRef.current,
        backspaceCount: backspaceRef.current,
        score: Math.round(finalMetrics.netWpm * (finalMetrics.accuracy / 100)),
        keyErrors: keyErrorsRef.current.slice(0, 200),
      };
      playTone("finish", settings.soundEnabled);
      onFinished?.(payload);
      if (save && !savedRef.current) {
        savedRef.current = true;
        setSaved("saving");
        saveResult(payload)
          .then(() => {
            setSaved("saved");
          })
          .catch((error: unknown) => {
            setSaved("error");
            setSaveError(error instanceof Error ? error.message : "Unable to save your result.");
          });
      }
    },
    [durationSeconds, language, mode, onFinished, refId, refTitle, save, saveResult, settings.soundEnabled, target],
  );

  // Single owned interval – cleaned up on unmount/status change.
  useEffect(() => {
    if (status !== "running") return;
    const interval = window.setInterval(() => setNow(Date.now()), 100);
    return () => window.clearInterval(interval);
  }, [status]);

  // Automatic stop when the selected duration ends.
  useEffect(() => {
    if (status !== "running" || durationSeconds <= 0) return;
    if (startedAtRef.current === null) return;
    if (Date.now() - startedAtRef.current >= durationSeconds * 1000) {
      finish();
    }
  }, [durationSeconds, finish, now, status]);

  // Keep the active character visible inside the passage viewport.
  useEffect(() => {
    const element = currentRef.current;
    const container = containerRef.current;
    if (!element || !container) return;
    const top = element.offsetTop;
    if (top < container.scrollTop || top > container.scrollTop + container.clientHeight - 48) {
      container.scrollTop = Math.max(0, top - container.clientHeight / 2);
    }
  }, [typed]);

  const applyValue = useCallback(
    (raw: string) => {
      if (finishedRef.current) return;
      const nextGraphemes = toGraphemes(raw).slice(0, targetGraphemes.length);
      const next = nextGraphemes.join("");
      const previous = toGraphemes(typedRef.current);

      if (nextGraphemes.length < previous.length) {
        const removed = previous.length - nextGraphemes.length;
        backspaceRef.current += removed;
        scoredRef.current = Math.max(0, scoredRef.current - removed);
        setBackspaceCount(backspaceRef.current);
        setLastKeyOk(null);
        playTone("key", settings.soundEnabled);
      } else if (nextGraphemes.length > scoredRef.current) {
        let newErrors = 0;
        for (let index = scoredRef.current; index < nextGraphemes.length; index += 1) {
          const expected = targetGraphemes[index] ?? "";
          if (nextGraphemes[index] !== expected) {
            newErrors += 1;
            keyErrorsRef.current.push({ expected, actual: nextGraphemes[index] });
          }
        }
        scoredRef.current = nextGraphemes.length;
        if (newErrors > 0) {
          keystrokeRef.current += newErrors;
          setKeystrokeErrors(keystrokeRef.current);
          setLastKeyOk(false);
          playTone("error", settings.soundEnabled);
        } else {
          setLastKeyOk(true);
          playTone("key", settings.soundEnabled);
        }
      }

      typedRef.current = next;
      setTyped(next);

      if (startedAtRef.current === null && nextGraphemes.length > 0) {
        const start = Date.now();
        startedAtRef.current = start;
        setStartedAt(start);
        setNow(start);
        setStatus("running");
      }

      if (nextGraphemes.length >= targetGraphemes.length && targetGraphemes.length > 0) {
        finish(next);
      }
    },
    [finish, settings.soundEnabled, targetGraphemes],
  );

  const restart = useCallback(() => {
    finishedRef.current = false;
    savedRef.current = false;
    typedRef.current = "";
    startedAtRef.current = null;
    keystrokeRef.current = 0;
    backspaceRef.current = 0;
    scoredRef.current = 0;
    keyErrorsRef.current = [];
    composingRef.current = false;
    setTyped("");
    setStartedAt(null);
    setKeystrokeErrors(0);
    setBackspaceCount(0);
    setFinishedElapsed(null);
    setSaved("idle");
    setSaveError(null);
    setLastKeyOk(null);
    setStatus("idle");
    setNow(Date.now());
    onRestart?.();
    window.setTimeout(() => inputRef.current?.focus(), 30);
  }, [onRestart]);

  const handleVirtualKey = (char: string, isBackspace: boolean) => {
    if (finishedRef.current) return;
    if (isBackspace) {
      applyValue(toGraphemes(typedRef.current).slice(0, -1).join(""));
      return;
    }
    applyValue(typedRef.current + char);
    inputRef.current?.focus();
  };

  const caretClass =
    settings.cursorStyle === "block"
      ? "caret-block"
      : settings.cursorStyle === "underline"
        ? "caret-underline"
        : "caret-line";

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm font-bold ${
            remainingSeconds !== null && remainingSeconds <= 10 && status === "running"
              ? "bg-[color-mix(in_srgb,var(--danger)_16%,transparent)] text-danger"
              : "bg-panel text-ink"
          }`}
        >
          <Clock size={14} />
          {remainingSeconds !== null
            ? `${String(Math.floor(remainingSeconds / 60)).padStart(2, "0")}:${String(
                remainingSeconds % 60,
              ).padStart(2, "0")}`
            : `${(elapsedMs / 1000).toFixed(1)}s`}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-panel px-2.5 py-1.5 text-sm font-semibold text-ink">
          <Gauge size={14} className="text-brand" />
          {metrics.netWpm.toFixed(0)} <span className="text-[0.68rem] font-medium text-muted">WPM</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-panel px-2.5 py-1.5 text-sm font-semibold text-ink">
          <Target size={14} className="text-cyan" />
          {metrics.accuracy.toFixed(1)}
          <span className="text-[0.68rem] font-medium text-muted">%</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg bg-panel px-2.5 py-1.5 text-sm font-semibold text-ink">
          <AlertTriangle size={14} className={metrics.incorrectChars > 0 ? "text-danger" : "text-muted"} />
          {metrics.incorrectChars}
          <span className="text-[0.68rem] font-medium text-muted">errors</span>
        </span>
        <span className="ml-auto hidden text-[0.7rem] text-muted sm:inline">
          {metrics.completion.toFixed(0)}% of passage · {metrics.correctChars}/{metrics.targetLength} chars
        </span>
      </div>

      {instructions ? (
        <p className="rounded-lg border border-line bg-panel/50 px-3 py-2 text-xs leading-relaxed text-muted">
          {instructions}
        </p>
      ) : null}

      {status === "finished" ? (
        <ResultView
          metrics={metrics}
          saved={saved}
          saveError={saveError}
          remainingSeconds={durationSeconds}
          restart={restart}
          restartLabel={restartLabel}
          resultActions={resultActions}
          showKeyboard={keyboardEnabled}
          allowVirtualInput={allowVirtualInput}
          language={language}
          typed={typedGraphemes}
          target={targetGraphemes}
        />
      ) : (
        <div className="card overflow-hidden">
          <div
            ref={containerRef}
            className={`relative max-h-[280px] overflow-y-auto px-4 py-4 sm:px-6 ${
              compact ? "sm:max-h-[220px]" : ""
            }`}
            onClick={() => inputRef.current?.focus()}
          >
            <p
              className={`passage ${language === "hi" ? "passage-hi" : ""} ${caretClass} ${
                lastKeyOk === false ? "border-l-2 border-danger pl-1" : ""
              }`}
              aria-label="Typing passage"
            >
              {targetGraphemes.map((grapheme, index) => {
                const typedGrapheme = typedGraphemes[index];
                if (typedGrapheme === undefined) {
                  if (index === typedGraphemes.length) {
                    return (
                      <span key={index} ref={currentRef} className="char-current">
                        {grapheme}
                      </span>
                    );
                  }
                  return (
                    <span key={index} className="char-pending">
                      {grapheme}
                    </span>
                  );
                }
                return (
                  <span
                    key={index}
                    className={typedGrapheme === grapheme ? "char-correct" : "char-incorrect"}
                  >
                    {grapheme}
                  </span>
                );
              })}
            </p>
            <textarea
              ref={inputRef}
              value={typed}
              onChange={(event) => {
                if (composingRef.current) {
                  typedRef.current = event.target.value;
                  setTyped(event.target.value);
                  return;
                }
                applyValue(event.target.value);
              }}
              onCompositionStart={() => {
                composingRef.current = true;
              }}
              onCompositionEnd={(event) => {
                composingRef.current = false;
                applyValue(event.currentTarget.value);
              }}
              onKeyDown={(event) => {
                if (event.key === "Tab") event.preventDefault();
                if (event.key === "Enter") event.preventDefault();
                if (event.key === "Backspace" && settings.strictMode) event.preventDefault();
              }}
              onPaste={(event) => event.preventDefault()}
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              aria-label="Typing input"
              className="absolute inset-0 h-full w-full resize-none border-0 bg-transparent p-0 text-transparent opacity-0 outline-none"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2 border-t border-line px-4 py-2.5">
            <p className="text-[0.7rem] text-muted">
              {status === "idle"
                ? "Start typing – the timer begins with your first keystroke."
                : "Backspace corrections are allowed. Final text is scored, keystroke errors are tracked separately."}
            </p>
            <div className="ml-auto flex items-center gap-2">
              {settings.strictMode ? (
                <span className="chip !text-danger">Strict mode</span>
              ) : null}
              <button type="button" onClick={restart} className="btn btn-ghost !py-1.5 !text-xs">
                <RefreshCw size={13} /> {restartLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {keyboardEnabled && status !== "finished" ? (
        <div className="card p-3">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[0.7rem] font-bold uppercase tracking-[0.12em] text-muted">
              {language === "hi" ? "Hindi InScript keyboard" : "Virtual keyboard"}
            </p>
            <p className="text-[0.68rem] text-muted">
              Next key: <span className="font-bold text-brand">{targetGraphemes[typedGraphemes.length] ?? "—"}</span>
            </p>
          </div>
          <VirtualKeyboard
            layout={language === "hi" ? "hi" : "en"}
            expected={targetGraphemes[typedGraphemes.length] ?? null}
            lastTyped={typedGraphemes[typedGraphemes.length - 1] ?? null}
            interactive={allowVirtualInput}
            onKey={allowVirtualInput ? handleVirtualKey : undefined}
            compact={compact}
          />
        </div>
      ) : null}
    </div>
  );
}

function ResultView({
  metrics,
  saved,
  saveError,
  restart,
  restartLabel,
  resultActions,
  remainingSeconds,
  showKeyboard,
  allowVirtualInput,
  language,
  typed,
  target,
}: {
  metrics: ReturnType<typeof computeMetrics>;
  saved: "idle" | "saving" | "saved" | "error";
  saveError: string | null;
  remainingSeconds: number;
  restart: () => void;
  restartLabel: string;
  resultActions?: ReactNode;
  showKeyboard: boolean;
  allowVirtualInput: boolean;
  language: Language;
  typed: string[];
  target: string[];
}) {
  const wrong = metrics.keyErrors.slice(0, 10);
  return (
    <div className="space-y-3">
      <div className="card fade-up p-4 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-[0.68rem] font-bold uppercase tracking-[0.18em] text-brand">
              Session complete
            </p>
            <h3 className="mt-1 text-lg font-bold text-ink">
              {metrics.accuracy >= 98
                ? "Excellent precision"
                : metrics.accuracy >= 92
                  ? "Solid performance"
                  : "Good effort – focus on accuracy"}
            </h3>
          </div>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
              saved === "saved"
                ? "bg-[color-mix(in_srgb,var(--success)_14%,transparent)] text-success"
                : saved === "error"
                  ? "bg-[color-mix(in_srgb,var(--danger)_14%,transparent)] text-danger"
                  : "bg-panel text-muted"
            }`}
          >
            {saved === "saving" ? (
              <>
                <Save size={13} /> Saving…
              </>
            ) : saved === "error" ? (
              <>
                <AlertTriangle size={13} /> {saveError ?? "Save failed"}
              </>
            ) : (
              <>
                <CheckCircle2 size={13} /> {saved === "saved" ? "Result saved" : "Session finished"}
              </>
            )}
          </span>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <ResultStat label="Net WPM" value={metrics.netWpm.toFixed(0)} tone="brand" big />
          <ResultStat label="Gross WPM" value={metrics.grossWpm.toFixed(0)} />
          <ResultStat label="Standard WPM" value={metrics.standardWpm.toFixed(0)} />
          <ResultStat label="Accuracy" value={`${metrics.accuracy.toFixed(1)}%`} tone="success" big />
          <ResultStat label="Uncorrected errors" value={`${metrics.incorrectChars}`} tone="danger" />
          <ResultStat label="Keystroke errors" value={`${metrics.keystrokeErrors}`} />
          <ResultStat label="Backspaces" value={`${metrics.backspaceCount}`} />
          <ResultStat label="Time" value={`${(metrics.elapsedMs / 1000).toFixed(1)}s`} />
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          <div className="card-flat p-3">
            <p className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
              Correct / typed characters
            </p>
            <p className="mt-1 text-sm font-semibold text-ink">
              {metrics.correctChars} / {metrics.totalTyped} · passage {metrics.targetLength} chars
            </p>
          </div>
          <div className="card-flat p-3">
            <p className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
              Mistake analysis
            </p>
            {wrong.length === 0 ? (
              <p className="mt-1 text-sm font-semibold text-success">No incorrect characters 🎯</p>
            ) : (
              <p className="mt-1 text-xs text-ink">
                {wrong.map((error, index) => (
                  <span key={`${error.index}-${index}`} className="mr-1.5 inline-flex items-center gap-1">
                    <span className="rounded bg-[color-mix(in_srgb,var(--danger)_14%,transparent)] px-1 font-mono text-danger">
                      {error.actual || "␣"}
                    </span>
                    <span className="text-muted">→</span>
                    <span className="rounded bg-[color-mix(in_srgb,var(--success)_14%,transparent)] px-1 font-mono text-success">
                      {error.expected || "␣"}
                    </span>
                  </span>
                ))}
              </p>
            )}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button type="button" onClick={restart} className="btn btn-primary">
            <RefreshCw size={15} /> {restartLabel}
          </button>
          {resultActions}
        </div>
        <p className="mt-2 text-[0.68rem] text-muted">
          {remainingSeconds > 0
            ? `Timed test · ${remainingSeconds}s limit. Timer is stopped and no further input is accepted.`
            : "Untimed practice · completed when the passage ends."}
        </p>
      </div>

      <div className="card p-4">
        <p className="mb-2 text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">
          Your final text
        </p>
        <p className={`passage !text-base ${language === "hi" ? "passage-hi" : ""}`}>
          {target.map((grapheme, index) => {
            const typedGrapheme = typed[index];
            if (typedGrapheme === undefined) {
              return (
                <span key={index} className="char-pending">
                  {grapheme}
                </span>
              );
            }
            return (
              <span
                key={index}
                className={typedGrapheme === grapheme ? "char-correct" : "char-incorrect"}
                title={
                  typedGrapheme === grapheme ? undefined : `You typed “${typedGrapheme}” instead of “${grapheme}”`
                }
              >
                {grapheme}
              </span>
            );
          })}
        </p>
      </div>

      {showKeyboard && allowVirtualInput ? (
        <VirtualKeyboard layout={language === "hi" ? "hi" : "en"} expected={null} showLegend={false} />
      ) : null}
    </div>
  );
}

function ResultStat({
  label,
  value,
  tone = "neutral",
  big = false,
}: {
  label: string;
  value: string;
  tone?: "neutral" | "brand" | "success" | "danger";
  big?: boolean;
}) {
  const tones: Record<string, string> = {
    neutral: "text-ink",
    brand: "text-brand",
    success: "text-success",
    danger: "text-danger",
  };
  return (
    <div className="card-flat px-3 py-2.5">
      <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">{label}</p>
      <p className={`mt-0.5 font-bold ${big ? "text-2xl" : "text-lg"} ${tones[tone]}`}>{value}</p>
    </div>
  );
}

export function LiveWpmBadge({ wpm }: { wpm: number }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-lg bg-brand-soft px-2 py-1 text-xs font-bold text-brand">
      <Zap size={12} /> {wpm.toFixed(0)} WPM
    </span>
  );
}
