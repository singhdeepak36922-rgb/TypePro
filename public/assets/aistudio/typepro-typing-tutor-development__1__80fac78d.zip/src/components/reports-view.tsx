"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
  Activity,
  BarChart3,
  Download,
  Gauge,
  Keyboard,
  Target,
  Timer,
  TrendingUp,
  Trophy,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { AccuracyChart, ActivityChart, WeakKeyChart, WpmChart } from "@/components/charts";
import { Badge, EmptyState, PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import { formatDuration, formatRelative } from "@/lib/stats";

const MODE_LABEL: Record<string, string> = {
  test: "Test",
  practice: "Practice",
  lesson: "Lesson",
  game: "Game",
  hindi: "Hindi",
  drill: "Drill",
};

export function ReportsView() {
  const { summary, results, ready } = useProgress();
  const [range, setRange] = useState<7 | 30>(7);
  const [mode, setMode] = useState<string>("all");

  const filtered = useMemo(
    () => (mode === "all" ? results : results.filter((result) => result.mode === mode)),
    [mode, results],
  );

  const chartData = useMemo(() => {
    const days = range === 7 ? summary.weekly : summary.monthly;
    if (filtered.length === results.length) return days;
    // Filtered trend: recompute per-day averages from the filtered set only.
    const map = new Map(days.map((day) => [day.date, { ...day, minutes: 0, tests: 0, wpm: 0, accuracy: 0 }]));
    const wpmBuckets = new Map<string, number[]>();
    const accuracyBuckets = new Map<string, number[]>();
    for (const result of filtered) {
      const key = new Date(result.createdAt).toISOString().slice(0, 10);
      const localKey = `${new Date(result.createdAt).getFullYear()}-${String(
        new Date(result.createdAt).getMonth() + 1,
      ).padStart(2, "0")}-${String(new Date(result.createdAt).getDate()).padStart(2, "0")}`;
      const point = map.get(localKey) ?? map.get(key);
      if (point) {
        point.minutes = Math.round((point.minutes + result.elapsedSeconds / 60) * 10) / 10;
        point.tests += 1;
      }
      const list = wpmBuckets.get(localKey) ?? [];
      list.push(result.netWpm);
      wpmBuckets.set(localKey, list);
      const accList = accuracyBuckets.get(localKey) ?? [];
      accList.push(result.accuracy);
      accuracyBuckets.set(localKey, accList);
    }
    for (const point of days) {
      const wpms = wpmBuckets.get(point.date) ?? [];
      const accs = accuracyBuckets.get(point.date) ?? [];
      const target = map.get(point.date);
      if (target && wpms.length > 0) {
        target.wpm = Math.round((wpms.reduce((sum, value) => sum + value, 0) / wpms.length) * 10) / 10;
        target.accuracy =
          Math.round((accs.reduce((sum, value) => sum + value, 0) / Math.max(1, accs.length)) * 10) / 10;
      }
    }
    return Array.from(map.values());
  }, [filtered, range, results.length, summary.monthly, summary.weekly]);

  const exportCsv = () => {
    const header = [
      "date",
      "mode",
      "title",
      "language",
      "duration_seconds",
      "gross_wpm",
      "net_wpm",
      "standard_wpm",
      "accuracy",
      "errors",
      "typed",
      "correct",
      "keystroke_errors",
      "backspaces",
      "score",
    ];
    const lines = results.map((result) =>
      [
        result.createdAt,
        result.mode,
        `"${(result.refTitle || "").replace(/"/g, "'")}"`,
        result.language,
        result.durationSeconds,
        result.grossWpm,
        result.netWpm,
        result.standardWpm,
        result.accuracy,
        result.errors,
        result.totalTyped,
        result.correctChars,
        result.keystrokeErrors,
        result.backspaceCount,
        result.score,
      ].join(","),
    );
    const blob = new Blob([[header.join(","), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "typepro-history.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const lessons = useMemo(
    () => new Set(results.filter((result) => result.mode === "lesson").map((result) => result.refId)),
    [results],
  );

  if (ready && results.length === 0) {
    return (
      <div className="space-y-5">
        <PageHeader
          eyebrow="Analytics"
          title="Performance reports"
          description="Every chart on this page is built from your saved sessions — nothing is simulated."
        />
        <div className="card p-6">
          <EmptyState
            icon={BarChart3}
            title="No analytics yet"
            description="Complete a typing test, lesson, practice session or game. Your daily progress, WPM trend, accuracy and weak-key analysis will appear here."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <Link href="/test" className="btn btn-primary !py-2 !text-xs">
                  Take a typing test
                </Link>
                <Link href="/learn" className="btn btn-ghost !py-2 !text-xs">
                  Start a lesson
                </Link>
              </div>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Analytics"
        title="Performance reports"
        description="Real aggregates from your saved sessions. Switch ranges and modes to inspect your progress."
        action={
          <>
            <button type="button" onClick={exportCsv} className="btn btn-ghost" disabled={results.length === 0}>
              <Download size={15} /> Export CSV
            </button>
            <Link href="/test" className="btn btn-primary">
              <Timer size={15} /> New test
            </Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total time" value={formatDuration(summary.totalPracticeSeconds)} icon={Timer} />
        <StatCard label="Sessions" value={results.length} icon={Activity} tone="cyan" />
        <StatCard label="Avg net WPM" value={summary.avgWpm.toFixed(0)} icon={Gauge} tone="brand" />
        <StatCard label="Best WPM" value={summary.bestWpm.toFixed(0)} icon={TrendingUp} tone="warn" />
        <StatCard label="Avg accuracy" value={`${summary.avgAccuracy.toFixed(1)}%`} icon={Target} tone="success" />
        <StatCard label="Lessons done" value={lessons.size} icon={Trophy} tone="danger" />
      </div>

      <div className="card flex flex-wrap items-center gap-2 p-3">
        <span className="text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">Range</span>
        <div className="flex rounded-lg border border-line p-0.5">
          {([7, 30] as const).map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setRange(value)}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold ${
                range === value ? "bg-brand text-white" : "text-muted"
              }`}
            >
              {value} days
            </button>
          ))}
        </div>
        <span className="ml-3 text-[0.68rem] font-bold uppercase tracking-[0.12em] text-muted">Mode</span>
        <select
          value={mode}
          onChange={(event) => setMode(event.target.value)}
          className="input !w-auto !py-1.5 !text-xs"
          aria-label="Session mode"
        >
          <option value="all">All sessions</option>
          <option value="test">Typing tests</option>
          <option value="lesson">Lessons</option>
          <option value="practice">Free practice</option>
          <option value="hindi">Hindi typing</option>
          <option value="game">Games</option>
        </select>
        <Badge tone="brand">{filtered.length} sessions shown</Badge>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <SectionCard title="Daily typing progress" description={`Minutes practised · last ${range} days`}>
          <ActivityChart data={chartData} height={230} />
        </SectionCard>
        <SectionCard title="WPM improvement" description="Net WPM and accuracy trend">
          <WpmChart data={chartData} height={230} />
        </SectionCard>
        <SectionCard title="Accuracy trend" description="Daily average accuracy">
          <AccuracyChart data={chartData} height={230} />
        </SectionCard>
        <SectionCard title="Weak-key analysis" description="Keys with the lowest final-text accuracy">
          {summary.weakKeys.length === 0 ? (
            <EmptyState
              icon={Keyboard}
              title="Key statistics need more data"
              description="At least three evaluated key presses are required before a key appears here. Complete another session to build your key profile."
            />
          ) : (
            <WeakKeyChart data={summary.weakKeys} height={230} />
          )}
        </SectionCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <SectionCard
          title="Recent sessions"
          description="Saved results, newest first"
          className="xl:col-span-2"
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-xs">
              <thead>
                <tr className="text-[0.62rem] uppercase tracking-[0.1em] text-muted">
                  <th className="pb-2 font-bold">Session</th>
                  <th className="pb-2 font-bold">Mode</th>
                  <th className="pb-2 font-bold">WPM</th>
                  <th className="pb-2 font-bold">Acc.</th>
                  <th className="pb-2 font-bold">Errors</th>
                  <th className="pb-2 font-bold">When</th>
                </tr>
              </thead>
              <tbody>
                {summary.recent.map((result) => (
                  <tr key={result.id} className="border-t border-line">
                    <td className="max-w-[190px] truncate py-2 pr-2 font-semibold text-ink">
                      {result.refTitle || "Session"}
                      <span className="ml-1 text-[0.6rem] uppercase text-muted">{result.language}</span>
                    </td>
                    <td className="py-2 pr-2 text-muted">{MODE_LABEL[result.mode] ?? result.mode}</td>
                    <td className="py-2 pr-2 font-bold text-brand">{result.netWpm.toFixed(0)}</td>
                    <td className="py-2 pr-2 text-success">{result.accuracy.toFixed(0)}%</td>
                    <td className="py-2 pr-2 text-danger">{result.errors}</td>
                    <td className="py-2 text-muted">{formatRelative(result.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="Goals and games" description="Completion snapshot">
          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-muted">
                <span>Today&apos;s goal</span>
                <span className="text-brand">{summary.goalPercent.toFixed(0)}%</span>
              </div>
              <div className="mt-1">
                <ProgressBar value={summary.goalPercent} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-muted">
                <span>Current streak</span>
                <span className="text-ink">{summary.streak} days</span>
              </div>
              <div className="mt-1">
                <ProgressBar value={Math.min(100, (summary.streak / 30) * 100)} tone="warn" />
              </div>
            </div>
            <div className="card-flat p-3">
              <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Best game scores</p>
              {Object.keys(summary.bestGameScores).length === 0 ? (
                <p className="mt-1 text-xs text-muted">No games played yet.</p>
              ) : (
                <ul className="mt-1.5 space-y-1 text-xs">
                  {Object.entries(summary.bestGameScores).map(([key, value]) => (
                    <li key={key} className="flex items-center justify-between">
                      <span className="capitalize text-muted">{key.replace(/-/g, " ")}</span>
                      <span className="font-bold text-ink">{value}</span>
                    </li>
                  ))}
                </ul>
              )}
              <Link href="/games" className="mt-2 inline-flex text-[0.7rem] font-semibold text-brand">
                Play a game →
              </Link>
            </div>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
