"use client";

import { useCallback, useEffect, useState } from "react";
import { Download, Share2, Smartphone } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

interface NavigatorWithStandalone extends Navigator {
  standalone?: boolean;
}

function isStandaloneDisplay(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.matchMedia("(display-mode: fullscreen)").matches ||
    (window.navigator as NavigatorWithStandalone).standalone === true
  );
}

function isIOSDevice(): boolean {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
}

/** Registers the offline service worker (production only). */
export function ServiceWorkerRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV !== "production") return;
    if (!("serviceWorker" in navigator)) return;
    const register = () => {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // offline support is a progressive enhancement
      });
    };
    if (document.readyState === "complete") {
      register();
      return;
    }
    window.addEventListener("load", register, { once: true });
    return () => window.removeEventListener("load", register);
  }, []);
  return null;
}

export function useInstallPrompt() {
  const [promptEvent, setPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setPromptEvent(null);
    };
    // Read browser install state once on mount (external system state).
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setInstalled(isStandaloneDisplay());
    setIos(isIOSDevice());
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const install = useCallback(async () => {
    if (!promptEvent) return false;
    await promptEvent.prompt();
    const choice = await promptEvent.userChoice;
    if (choice.outcome === "accepted") {
      setInstalled(true);
      setPromptEvent(null);
      return true;
    }
    return false;
  }, [promptEvent]);

  return { canInstall: promptEvent !== null, installed, isIos: ios, install };
}

/** Compact install button — renders nothing until the browser allows install. */
export function InstallButton({ className = "" }: { className?: string }) {
  const { canInstall, installed, install } = useInstallPrompt();
  if (installed || !canInstall) return null;
  return (
    <button type="button" onClick={() => void install()} className={`btn btn-soft !py-2 !text-xs ${className}`}>
      <Download size={14} />
      <span className="hidden sm:inline">Install app</span>
      <span className="sm:hidden">Install</span>
    </button>
  );
}

/** Settings card explaining install + offline behaviour per platform. */
export function MobileAppCard() {
  const { canInstall, installed, isIos, install } = useInstallPrompt();

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-2.5 py-1 text-[0.68rem] font-bold uppercase tracking-[0.12em] text-brand">
          <Smartphone size={12} /> {installed ? "Installed" : "Installable"}
        </span>
        {!installed && canInstall ? (
          <button type="button" onClick={() => void install()} className="btn btn-primary !py-2 !text-xs">
            <Download size={13} /> Install TypePro app
          </button>
        ) : null}
      </div>

      {installed ? (
        <p className="text-xs leading-relaxed text-muted">
          TypePro is running as an installed app: full-screen without browser bars, with an app icon in your
          launcher/home screen. Completed sessions are stored locally while offline and sync to your account when
          you reconnect.
        </p>
      ) : isIos ? (
        <ol className="space-y-1.5 text-xs text-muted">
          <li className="flex items-start gap-2">
            <Share2 size={14} className="mt-0.5 shrink-0 text-brand" /> Open the Share sheet in Safari.
          </li>
          <li className="flex items-start gap-2">
            <Smartphone size={14} className="mt-0.5 shrink-0 text-brand" /> Choose “Add to Home Screen”.
          </li>
          <li className="flex items-start gap-2">
            <Download size={14} className="mt-0.5 shrink-0 text-brand" /> Confirm — TypePro opens full screen with
            its own icon.
          </li>
        </ol>
      ) : (
        <ol className="space-y-1.5 text-xs text-muted">
          <li className="flex items-start gap-2">
            <Download size={14} className="mt-0.5 shrink-0 text-brand" /> Tap the Install button above, or the
            install icon in your browser&apos;s address bar.
          </li>
          <li className="flex items-start gap-2">
            <Smartphone size={14} className="mt-0.5 shrink-0 text-brand" /> Confirm the prompt — the app appears in
            your app drawer and home screen.
          </li>
          <li className="flex items-start gap-2">
            <Share2 size={14} className="mt-0.5 shrink-0 text-brand" /> Long-press the icon for shortcuts to the
            typing test, Hindi practice, lessons and reports.
          </li>
        </ol>
      )}

      <p className="text-[0.68rem] leading-relaxed text-muted">
        Android/Chrome, Edge and Samsung Internet install directly. iOS installs through Safari’s Share sheet.
        The same installable build is the base for the Windows/desktop and store packaging phase (Tauri 2 or
        Capacitor).
      </p>
    </div>
  );
}
