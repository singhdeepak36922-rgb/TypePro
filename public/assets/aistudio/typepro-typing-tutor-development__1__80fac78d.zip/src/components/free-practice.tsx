"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { BarChart3, Languages, PenLine, RefreshCw, Shuffle } from "lucide-react";
import { TypingSurface } from "@/components/typing-surface";
import { PageHeader, SectionCard } from "@/components/ui";
import type { PassageDTO } from "@/lib/types";

export function FreePractice({ passages }: { passages: PassageDTO[] }) {
  const [mode, setMode] = useState<"random" | "custom">("random");
  const [language, setLanguage] = useState<"en" | "hi">("en");
  const [difficulty, setDifficulty] = useState<string>("all");
  const [index, setIndex] = useState(0);
  const [customText, setCustomText] = useState("");
  const [activeCustom, setActiveCustom] = useState<string | null>(null);
  const [sessionKey, setSessionKey] = useState(0);

  const filtered = useMemo(() => {
    return passages.filter(
      (passage) =>
        passage.language === language && (difficulty === "all" || passage.difficulty === difficulty),
    );
  }, [difficulty, language, passages]);

  const passage = filtered[index % Math.max(1, filtered.length)];

  const target =
    mode === "custom" && activeCustom
      ? activeCustom
      : passage?.content ??
        "Free practice is ready. Choose a random passage or paste your own text to begin.";

  const customLanguage: "en" | "hi" = /[\u0900-\u097F]/.test(activeCustom ?? "") ? "hi" : "en";
  const activeLanguage = mode === "custom" && activeCustom ? customLanguage : language;

  const shuffle = () => {
    setIndex((current) => (current + 1) % Math.max(1, filtered.length));
    setSessionKey((current) => current + 1);
  };

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Untimed training"
        title="Free practice"
        description="Practise at your own pace with no clock. Live WPM and accuracy are still calculated, and each completed passage is saved to your history."
        action={
          <Link href="/reports" className="btn btn-ghost">
            <BarChart3 size={15} /> Reports
          </Link>
        }
      />

      <div className="card p-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-lg border border-line p-0.5">
            <button
              type="button"
              onClick={() => setMode("random")}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold ${
                mode === "random" ? "bg-brand text-white" : "text-muted"
              }`}
            >
              Random passage
            </button>
            <button
              type="button"
              onClick={() => setMode("custom")}
              className={`rounded-md px-3 py-1.5 text-xs font-semibold ${
                mode === "custom" ? "bg-brand text-white" : "text-muted"
              }`}
            >
              My own text
            </button>
          </div>

          <div className="flex rounded-lg border border-line p-0.5">
            <button
              type="button"
              onClick={() => {
                setLanguage("en");
                setIndex(0);
                setSessionKey((current) => current + 1);
              }}
              className={`inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-semibold ${
                language === "en" ? "bg-panel text-ink" : "text-muted"
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => {
                setLanguage("hi");
                setIndex(0);
                setSessionKey((current) => current + 1);
              }}
              className={`inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-semibold ${
                language === "hi" ? "bg-panel text-ink" : "text-muted"
              }`}
            >
              <Languages size={12} /> हिन्दी
            </button>
          </div>

          <select
            value={difficulty}
            onChange={(event) => {
              setDifficulty(event.target.value);
              setIndex(0);
              setSessionKey((current) => current + 1);
            }}
            className="input !w-auto !py-1.5 !text-xs"
            aria-label="Difficulty"
          >
            <option value="all">All difficulties</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
            <option value="competitive">Competitive</option>
          </select>

          {mode === "random" ? (
            <button type="button" onClick={shuffle} className="btn btn-ghost !py-1.5 !text-xs">
              <Shuffle size={13} /> Shuffle passage
            </button>
          ) : null}
        </div>

        {mode === "custom" ? (
          <div className="mt-3 space-y-2">
            <label className="label" htmlFor="custom-text">
              Your practice text
            </label>
            <textarea
              id="custom-text"
              value={customText}
              onChange={(event) => setCustomText(event.target.value)}
              rows={3}
              placeholder="Paste or type any English or Hindi text (Unicode supported)…"
              className="input resize-y"
            />
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={customText.trim().length < 10}
                onClick={() => {
                  setActiveCustom(customText.trim());
                  setSessionKey((current) => current + 1);
                }}
                className="btn btn-primary !py-2 !text-xs"
              >
                <PenLine size={13} /> Use this text
              </button>
              <button
                type="button"
                onClick={() => {
                  setCustomText("");
                  setActiveCustom(null);
                  setSessionKey((current) => current + 1);
                }}
                className="btn btn-ghost !py-2 !text-xs"
              >
                <RefreshCw size={13} /> Reset
              </button>
              <p className="text-[0.68rem] text-muted">Minimum 10 characters. Text stays in your browser.</p>
            </div>
          </div>
        ) : null}
      </div>

      <SectionCard
        title={
          mode === "custom" && activeCustom
            ? "Custom practice text"
            : passage?.title ?? "Free practice"
        }
        description={
          mode === "custom" && activeCustom
            ? "Your own text · untimed"
            : `${passage?.language === "hi" ? "Hindi" : "English"} · ${passage?.difficulty ?? "random"} · untimed`
        }
        action={
          mode === "random" ? (
            <button type="button" onClick={shuffle} className="btn btn-ghost !py-1.5 !text-xs">
              <Shuffle size={13} /> Next
            </button>
          ) : null
        }
      >
        <TypingSurface
          key={`${mode}-${language}-${difficulty}-${index}-${sessionKey}-${activeCustom?.length ?? 0}`}
          target={target}
          language={activeLanguage}
          durationSeconds={0}
          mode="practice"
          refId={mode === "custom" ? "custom" : passage?.slug ?? "practice"}
          refTitle={mode === "custom" ? "Custom practice" : passage?.title ?? "Free practice"}
          allowVirtualInput={activeLanguage === "hi"}
          restartLabel="Restart practice"
          resultActions={
            mode === "random" ? (
              <button type="button" onClick={shuffle} className="btn btn-ghost">
                <Shuffle size={15} /> Another passage
              </button>
            ) : (
              <button type="button" onClick={() => setActiveCustom(null)} className="btn btn-ghost">
                <RefreshCw size={15} /> Clear text
              </button>
            )
          }
        />
      </SectionCard>
    </div>
  );
}
