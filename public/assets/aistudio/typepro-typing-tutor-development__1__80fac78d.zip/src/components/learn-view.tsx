"use client";

import Link from "next/link";
import { useMemo } from "react";
import { ArrowRight, CheckCircle2, Circle, GraduationCap, Keyboard, Target } from "lucide-react";
import { useProgress } from "@/components/providers";
import { Badge, PageHeader, ProgressBar, SectionCard } from "@/components/ui";
import type { LessonDTO } from "@/lib/types";

const LEVELS: { key: string; label: string; description: string }[] = [
  {
    key: "beginner",
    label: "Beginner",
    description: "Keyboard introduction, finger positioning, home row, hand drills, upper and lower rows.",
  },
  {
    key: "intermediate",
    label: "Intermediate",
    description: "Common words, word combinations, sentences, paragraphs, punctuation and speed building.",
  },
  {
    key: "advanced",
    label: "Advanced",
    description: "Long passages, professional typing, difficult words, accuracy training and exam passages.",
  },
];

export function LearnView({ lessons }: { lessons: LessonDTO[] }) {
  const { results } = useProgress();

  const bestBySlug = useMemo(() => {
    const map = new Map<string, { wpm: number; accuracy: number; attempts: number }>();
    for (const result of results) {
      if (result.mode !== "lesson" || !result.refId) continue;
      const current = map.get(result.refId) ?? { wpm: 0, accuracy: 0, attempts: 0 };
      map.set(result.refId, {
        wpm: Math.max(current.wpm, result.netWpm),
        accuracy: Math.max(current.accuracy, result.accuracy),
        attempts: current.attempts + 1,
      });
    }
    return map;
  }, [results]);

  const completed = lessons.filter((lesson) => (bestBySlug.get(lesson.slug)?.accuracy ?? 0) >= 90).length;

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Structured course"
        title="Learn typing"
        description="A complete English typing curriculum from keyboard basics to competitive-exam passages. Every lesson stores your best speed and accuracy."
        action={
          <Link href="/keyboard" className="btn btn-ghost">
            <Keyboard size={15} /> Virtual keyboard
          </Link>
        }
      />

      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <GraduationCap size={18} className="text-brand" />
            <div>
              <p className="text-sm font-bold text-ink">Course progress</p>
              <p className="text-xs text-muted">
                {completed} of {lessons.length} lessons completed (90%+ accuracy)
              </p>
            </div>
          </div>
          <Badge tone={completed > 0 ? "success" : "neutral"}>
            {lessons.length ? Math.round((completed / lessons.length) * 100) : 0}% complete
          </Badge>
        </div>
        <div className="mt-3">
          <ProgressBar value={lessons.length ? (completed / lessons.length) * 100 : 0} height={10} />
        </div>
      </div>

      {LEVELS.map((level) => {
        const levelLessons = lessons.filter((lesson) => lesson.level === level.key);
        if (levelLessons.length === 0) return null;
        const done = levelLessons.filter((lesson) => (bestBySlug.get(lesson.slug)?.accuracy ?? 0) >= 90).length;
        return (
          <SectionCard
            key={level.key}
            title={`${level.label} course`}
            description={level.description}
            action={
              <Badge tone={done === levelLessons.length ? "success" : "brand"}>
                {done}/{levelLessons.length} done
              </Badge>
            }
          >
            <ol className="grid gap-2 sm:grid-cols-2">
              {levelLessons.map((lesson, index) => {
                const best = bestBySlug.get(lesson.slug);
                const isDone = (best?.accuracy ?? 0) >= 90;
                return (
                  <li key={lesson.slug}>
                    <Link
                      href={`/learn/${lesson.slug}`}
                      className="group flex h-full items-start gap-3 rounded-xl border border-line bg-panel/40 p-3 transition hover:border-brand/60 hover:bg-panel"
                    >
                      <span className="mt-0.5 text-muted">
                        {isDone ? (
                          <CheckCircle2 size={18} className="text-success" />
                        ) : (
                          <Circle size={18} />
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="text-[0.62rem] font-bold uppercase tracking-[0.12em] text-muted">
                            Lesson {index + 1}
                          </span>
                          <span className="text-[0.62rem] text-muted">· {lesson.estMinutes} min</span>
                        </span>
                        <span className="mt-0.5 block truncate text-sm font-semibold text-ink group-hover:text-brand">
                          {lesson.title}
                        </span>
                        <span className="mt-1 block text-[0.7rem] text-muted">Focus: {lesson.focus}</span>
                        {best ? (
                          <span className="mt-1.5 flex flex-wrap gap-2 text-[0.66rem] font-semibold">
                            <span className="text-brand">{best.wpm.toFixed(0)} WPM best</span>
                            <span className="text-success">{best.accuracy.toFixed(0)}% accuracy</span>
                            <span className="text-muted">{best.attempts} attempt(s)</span>
                          </span>
                        ) : (
                          <span className="mt-1.5 inline-flex items-center gap-1 text-[0.66rem] text-muted">
                            <Target size={11} /> Not attempted yet
                          </span>
                        )}
                      </span>
                      <ArrowRight size={15} className="mt-1 shrink-0 text-muted group-hover:text-brand" />
                    </Link>
                  </li>
                );
              })}
            </ol>
          </SectionCard>
        );
      })}
    </div>
  );
}
