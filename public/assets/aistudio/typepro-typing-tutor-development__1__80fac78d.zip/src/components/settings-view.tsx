"use client";

import { useState } from "react";
import Link from "next/link";
import {
  CheckCircle2,
  Cpu,
  Smartphone,
  Keyboard,
  Languages,
  Monitor,
  Moon,
  Sliders,
  Sun,
  Target,
  Volume2,
  VolumeX,
} from "lucide-react";
import { useProgress } from "@/components/providers";
import { MobileAppCard } from "@/components/pwa";
import { clearGuestData } from "@/lib/local-store";
import { Badge, PageHeader, SectionCard } from "@/components/ui";
import { CATEGORIES, DURATIONS, type ThemeMode } from "@/lib/types";
import { playTone } from "@/lib/sound";

const CURSORS = [
  { value: "line", label: "Line caret" },
  { value: "block", label: "Block caret" },
  { value: "underline", label: "Underline caret" },
] as const;

export function SettingsView() {
  const { settings, updateSettings, user, guestResultCount, refresh } = useProgress();
  const [notice, setNotice] = useState<string | null>(null);

  const save = async (patch: Parameters<typeof updateSettings>[0], label: string) => {
    await updateSettings(patch);
    setNotice(`${label} saved${user ? " to your account" : " in this browser"}.`);
    window.setTimeout(() => setNotice(null), 2400);
  };

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Preferences"
        title="Settings"
        description="All preferences are stored immediately — on your account when signed in, otherwise in this browser along with your guest progress."
        action={
          notice ? (
            <Badge tone="success">
              <CheckCircle2 size={12} /> {notice}
            </Badge>
          ) : null
        }
      />

      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard title="Appearance" description="Dark is the default TypePro theme">
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { value: "dark" as ThemeMode, label: "Dark", icon: Moon },
                { value: "light" as ThemeMode, label: "Light", icon: Sun },
                { value: "system" as ThemeMode, label: "System", icon: Monitor },
              ] as const
            ).map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => void save({ theme: option.value }, "Theme")}
                className={`flex flex-col items-center gap-1.5 rounded-xl border p-3 text-xs font-semibold transition ${
                  settings.theme === option.value
                    ? "border-brand bg-brand-soft text-brand"
                    : "border-line text-muted hover:text-ink"
                }`}
              >
                <option.icon size={18} />
                {option.label}
              </button>
            ))}
          </div>

          <div className="mt-4">
            <p className="label">Typing cursor</p>
            <div className="grid grid-cols-3 gap-2">
              {CURSORS.map((cursor) => (
                <button
                  key={cursor.value}
                  type="button"
                  onClick={() => void save({ cursorStyle: cursor.value }, "Cursor")}
                  className={`rounded-xl border p-2.5 text-[0.7rem] font-semibold transition ${
                    settings.cursorStyle === cursor.value
                      ? "border-brand bg-brand-soft text-brand"
                      : "border-line text-muted hover:text-ink"
                  }`}
                >
                  {cursor.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between rounded-xl border border-line p-3">
            <div className="flex items-center gap-2">
              {settings.soundEnabled ? (
                <Volume2 size={16} className="text-brand" />
              ) : (
                <VolumeX size={16} className="text-muted" />
              )}
              <div>
                <p className="text-xs font-bold text-ink">Sound effects</p>
                <p className="text-[0.68rem] text-muted">Key, error and finish tones</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.soundEnabled}
              onClick={() => {
                const next = !settings.soundEnabled;
                void save({ soundEnabled: next }, "Sound");
                playTone("key", next);
              }}
              className={`h-6 w-11 rounded-full transition ${
                settings.soundEnabled ? "bg-brand" : "bg-line"
              }`}
            >
              <span
                className={`block h-5 w-5 rounded-full bg-white transition ${
                  settings.soundEnabled ? "translate-x-5" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>

          <div className="mt-3 flex items-center justify-between rounded-xl border border-line p-3">
            <div className="flex items-center gap-2">
              <Keyboard size={16} className="text-brand" />
              <div>
                <p className="text-xs font-bold text-ink">Show virtual keyboard</p>
                <p className="text-[0.68rem] text-muted">Highlight the next key while typing</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.showKeyboard}
              onClick={() => void save({ showKeyboard: !settings.showKeyboard }, "Keyboard display")}
              className={`h-6 w-11 rounded-full transition ${
                settings.showKeyboard ? "bg-brand" : "bg-line"
              }`}
            >
              <span
                className={`block h-5 w-5 rounded-full bg-white transition ${
                  settings.showKeyboard ? "translate-x-5" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>

          <div className="mt-3 flex items-center justify-between rounded-xl border border-line p-3">
            <div className="flex items-center gap-2">
              <Sliders size={16} className="text-brand" />
              <div>
                <p className="text-xs font-bold text-ink">Strict mode</p>
                <p className="text-[0.68rem] text-muted">Disable Backspace during sessions</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.strictMode}
              onClick={() => void save({ strictMode: !settings.strictMode }, "Strict mode")}
              className={`h-6 w-11 rounded-full transition ${settings.strictMode ? "bg-brand" : "bg-line"}`}
            >
              <span
                className={`block h-5 w-5 rounded-full bg-white transition ${
                  settings.strictMode ? "translate-x-5" : "translate-x-0.5"
                }`}
              />
            </button>
          </div>
        </SectionCard>

        <SectionCard title="Typing preferences" description="Defaults for new tests and sessions">
          <div>
            <p className="label">Interface & content language</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "en" as const, label: "English" },
                { value: "hi" as const, label: "हिन्दी" },
              ].map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => void save({ language: option.value }, "Language")}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-xl border p-2.5 text-xs font-semibold transition ${
                    settings.language === option.value
                      ? "border-brand bg-brand-soft text-brand"
                      : "border-line text-muted hover:text-ink"
                  }`}
                >
                  <Languages size={14} /> {option.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <label className="label" htmlFor="default-duration">
              Default test duration
            </label>
            <select
              id="default-duration"
              value={settings.defaultDuration}
              onChange={(event) => void save({ defaultDuration: Number(event.target.value) }, "Default duration")}
              className="input"
            >
              {DURATIONS.map((duration) => (
                <option key={duration} value={duration}>
                  {duration / 60} minute{duration === 60 ? "" : "s"}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-3">
            <label className="label" htmlFor="default-category">
              Default test category
            </label>
            <select
              id="default-category"
              value={settings.defaultCategory}
              onChange={(event) => void save({ defaultCategory: event.target.value }, "Default category")}
              className="input"
            >
              {CATEGORIES.map((category) => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-3">
            <label className="label" htmlFor="keyboard-layout">
              Keyboard layout reference
            </label>
            <select
              id="keyboard-layout"
              value={settings.keyboardLayout}
              onChange={(event) =>
                void save({ keyboardLayout: event.target.value as "qwerty" | "inscript" }, "Keyboard layout")
              }
              className="input"
            >
              <option value="qwerty">English QWERTY</option>
              <option value="inscript">Hindi InScript</option>
            </select>
          </div>

          <div className="mt-4">
            <div className="flex items-center justify-between">
              <label className="label !mb-0" htmlFor="daily-goal">
                Daily typing goal
              </label>
              <span className="text-xs font-bold text-brand">{settings.dailyGoalMinutes} min</span>
            </div>
            <input
              id="daily-goal"
              type="range"
              min={5}
              max={120}
              step={5}
              value={settings.dailyGoalMinutes}
              onChange={(event) => void save({ dailyGoalMinutes: Number(event.target.value) }, "Daily goal")}
              className="mt-2 w-full accent-[var(--brand)]"
            />
            <div className="flex items-center gap-1.5 text-[0.68rem] text-muted">
              <Target size={12} /> Used for the dashboard goal ring and streak tracking.
            </div>
          </div>
        </SectionCard>
      </div>

      <SectionCard title="Mobile app" description="Install TypePro on Android, iOS or desktop">
        <MobileAppCard />
      </SectionCard>

      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard title="Storage" description="Where your progress lives">
          <div className="space-y-2 text-xs text-muted">
            <p>
              Status: <span className="font-semibold text-ink">{user ? "Signed in — cloud sync" : "Guest mode"}</span>
            </p>
            <p>
              Guest results stored locally:{" "}
              <span className="font-semibold text-ink">{guestResultCount}</span>
            </p>
            <p>
              Account results are stored in PostgreSQL with row-level ownership checks; passwords use salted scrypt
              hashes and sessions use HTTP-only cookies.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {user ? (
                <Link href="/profile" className="btn btn-soft !py-2 !text-xs">
                  <Cpu size={13} /> Profile &amp; import
                </Link>
              ) : (
                <>
                  <Link href="/login" className="btn btn-primary !py-2 !text-xs">
                    Sign in to sync
                  </Link>
                  <Link href="/register" className="btn btn-ghost !py-2 !text-xs">
                    Create account
                  </Link>
                </>
              )}
              {!user && guestResultCount > 0 ? (
                <button
                  type="button"
                  onClick={() => {
                    clearGuestData();
                    void refresh();
                    setNotice("Guest history cleared.");
                  }}
                  className="btn btn-ghost !py-2 !text-xs !text-danger"
                >
                  Clear guest history
                </button>
              ) : null}
            </div>
          </div>
        </SectionCard>

        <SectionCard title="About TypePro" description="Build information">
          <ul className="space-y-2 text-xs text-muted">
            <li>
              <span className="font-semibold text-ink">Engine:</span> Unicode grapheme-aware WPM and accuracy scoring,
              independent from the UI and unit tested.
            </li>
            <li>
              <span className="font-semibold text-ink">Languages:</span> English and Hindi (Devanagari Unicode) with
              InScript reference and a phonetic transliteration buffer.
            </li>
            <li>
              <span className="font-semibold text-ink">Desktop roadmap:</span> the web app avoids desktop-only APIs so
              it can be packaged with Tauri 2 for Windows 10/11 in the next phase.
            </li>
            <li>
              <span className="font-semibold text-ink">Version:</span> 1.1.0 (installable PWA)
            </li>
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
