"use client";

import { useMemo, useRef, useState } from "react";
import { CheckCircle2, Info, Keyboard, Languages, RefreshCw, Wand2 } from "lucide-react";
import { useProgress } from "@/components/providers";
import { TypingSurface } from "@/components/typing-surface";
import { VirtualKeyboard } from "@/components/virtual-keyboard";
import { Badge, PageHeader, SectionCard } from "@/components/ui";
import { HINDI_ROWS, FINGER_COLORS, FINGER_LABELS } from "@/lib/keyboard";
import { transliterate } from "@/lib/transliterate";
import { computeMetrics, toGraphemes } from "@/lib/typing-engine";
import { playTone } from "@/lib/sound";
import type { PassageDTO, ResultInput } from "@/lib/types";

export function HindiView({ passages }: { passages: PassageDTO[] }) {
  const [tab, setTab] = useState<"inscript" | "phonetic" | "reference">("inscript");
  const hindiPassages = useMemo(() => passages.filter((passage) => passage.language === "hi"), [passages]);
  const [index, setIndex] = useState(0);
  const passage = hindiPassages[index % Math.max(1, hindiPassages.length)];
  const [sessionKey, setSessionKey] = useState(0);

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Devanagari Unicode"
        title="Hindi typing"
        description="Train Hindi with two honest input workflows: a clickable InScript keyboard (or your own OS InScript layout) and a Roman-to-Devanagari phonetic buffer that only scores committed text."
      />

      <div className="flex flex-wrap items-center gap-2">
        {[
          { key: "inscript" as const, label: "InScript practice", icon: Keyboard },
          { key: "phonetic" as const, label: "Phonetic (Roman → हिन्दी)", icon: Wand2 },
          { key: "reference" as const, label: "InScript reference", icon: Languages },
        ].map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition ${
              tab === item.key ? "bg-brand text-white" : "border border-line bg-surface text-muted hover:text-ink"
            }`}
          >
            <item.icon size={14} /> {item.label}
          </button>
        ))}
      </div>

      {tab === "inscript" ? (
        <SectionCard
          title={passage?.title ?? "Hindi InScript practice"}
          description={
            passage
              ? `${passage.difficulty} · ${passage.wordCount} words · untimed practice`
              : "Passage library loading"
          }
          action={
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setIndex((current) => (current + 1) % Math.max(1, hindiPassages.length));
                  setSessionKey((current) => current + 1);
                }}
                className="btn btn-ghost !py-1.5 !text-xs"
              >
                <RefreshCw size={13} /> Next passage
              </button>
              <Badge tone="brand">InScript</Badge>
            </div>
          }
        >
          {passage ? (
            <>
              <TypingSurface
                key={`${passage.slug}-${sessionKey}`}
                target={passage.content}
                language="hi"
                durationSeconds={0}
                mode="hindi"
                refId={`inscript-${passage.slug}`}
                refTitle={`InScript · ${passage.title}`}
                allowVirtualInput
                restartLabel="Restart drill"
                instructions="Use the on-screen InScript keyboard if your system InScript layout is not enabled, or type with your OS IME. Devanagari matras are scored as single grapheme clusters."
              />
              <div className="mt-3 flex items-start gap-2 rounded-lg border border-line bg-panel/50 p-3">
                <Info size={15} className="mt-0.5 shrink-0 text-brand" />
                <p className="text-[0.7rem] leading-relaxed text-muted">
                  The TypePro InScript keyboard is a static one-to-one mapping of the standard Devanagari InScript
                  layout. Conjuncts are built with the halant key (्) exactly as on a real InScript keyboard. A full
                  system driver also applies reph and halant state; for exam-accurate practice, enable InScript in
                  your operating system and use the physical keyboard.
                </p>
              </div>
            </>
          ) : (
            <p className="text-sm text-muted">Hindi passages are seeded automatically on first load.</p>
          )}
        </SectionCard>
      ) : null}

      {tab === "phonetic" ? (
        <PhoneticPractice passage={passage ?? null} onNext={() => setIndex((current) => current + 1)} />
      ) : null}

      {tab === "reference" ? (
        <SectionCard
          title="Hindi InScript layout reference"
          description="Devanagari characters produced by each physical key. Fingers follow the same columns as English."
          action={<Badge tone="brand">Unicode</Badge>}
        >
          <div className="space-y-1 overflow-x-auto">
            {HINDI_ROWS.map((row, rowIndex) => (
              <div key={rowIndex} className="flex justify-center gap-1">
                {row.map((key) => (
                  <div
                    key={key.code}
                    className="grid h-12 w-[52px] shrink-0 place-items-center rounded-md border border-line bg-surface text-sm font-semibold text-ink"
                    style={{ borderBottomColor: FINGER_COLORS[key.finger], borderBottomWidth: 3 }}
                    title={`${key.shift} · ${FINGER_LABELS[key.finger]}`}
                  >
                    <span>{key.base}</span>
                    <span className="text-[0.6rem] font-normal text-muted">{key.shift}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <div className="card-flat p-3">
              <p className="text-xs font-bold text-ink">Finger positioning</p>
              <p className="mt-1 text-[0.7rem] leading-relaxed text-muted">
                Keep the left hand on <span className="font-mono text-ink">ा ै ् ि ु</span> and the right hand on{" "}
                <span className="font-mono text-ink">प र क त च</span>. The small bumps on F and J still anchor both
                hands; the same fingers own the same columns in Hindi.
              </p>
            </div>
            <div className="card-flat p-3">
              <p className="text-xs font-bold text-ink">Matras and conjuncts</p>
              <p className="mt-1 text-[0.7rem] leading-relaxed text-muted">
                Matras attach to the previous consonant and are treated as one grapheme by the scoring engine. Use
                the halant (्) between consonants for conjuncts such as क्ष and त्र. Anusvara (ं) and visarga (ः) are
                available on separate keys.
              </p>
            </div>
          </div>
        </SectionCard>
      ) : null}
    </div>
  );
}

function PhoneticPractice({ passage, onNext }: { passage: PassageDTO | null; onNext: () => void }) {
  const { settings, saveResult } = useProgress();
  const [roman, setRoman] = useState("");
  const [committed, setCommitted] = useState("");
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [saved, setSaved] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [result, setResult] = useState<ReturnType<typeof computeMetrics> | null>(null);
  const [sessionKey, setSessionKey] = useState(0);
  const finishedRef = useRef(false);
  const intervalRef = useRef<number | null>(null);

  const target = passage?.content ?? "";
  const preview = transliterate(roman);
  const typedScored = committed;

  const startTimer = () => {
    if (startedAt !== null || finishedRef.current) return;
    const start = Date.now();
    setStartedAt(start);
    if (intervalRef.current) window.clearInterval(intervalRef.current);
    intervalRef.current = window.setInterval(() => setElapsedMs(Date.now() - start), 100);
  };

  const stopTimer = () => {
    if (intervalRef.current) window.clearInterval(intervalRef.current);
    intervalRef.current = null;
  };

  const reset = () => {
    if (intervalRef.current) window.clearInterval(intervalRef.current);
    intervalRef.current = null;
    setRoman("");
    setCommitted("");
    setStartedAt(null);
    setElapsedMs(0);
    setSaved("idle");
    setResult(null);
    finishedRef.current = false;
    setSessionKey((current) => current + 1);
  };

  const finish = async (finalCommitted: string) => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    stopTimer();
    const started = startedAt ?? Date.now();
    const elapsed = Math.max(0, Date.now() - started);
    setElapsedMs(elapsed);
    const metrics = computeMetrics({
      target,
      typed: finalCommitted,
      elapsedMs: elapsed,
      keystrokeErrors: 0,
      backspaceCount: 0,
    });
    setResult(metrics);
    setSaved("saving");
    const payload: ResultInput = {
      mode: "hindi",
      refId: passage ? `phonetic-${passage.slug}` : "phonetic",
      refTitle: passage ? `Phonetic · ${passage.title}` : "Phonetic practice",
      language: "hi",
      durationSeconds: 0,
      elapsedSeconds: Math.round(elapsed / 1000),
      grossWpm: metrics.grossWpm,
      netWpm: metrics.netWpm,
      standardWpm: metrics.standardWpm,
      accuracy: metrics.accuracy,
      errors: metrics.incorrectChars,
      totalTyped: metrics.totalTyped,
      correctChars: metrics.correctChars,
      keystrokeErrors: 0,
      backspaceCount: 0,
      score: Math.round(metrics.netWpm * (metrics.accuracy / 100)),
      keyErrors: metrics.keyErrors.map((error) => ({ expected: error.expected, actual: error.actual })),
    };
    playTone("finish", settings.soundEnabled);
    try {
      await saveResult(payload);
      setSaved("saved");
    } catch {
      setSaved("error");
    }
  };

  const handleChange = (raw: string) => {
    if (finishedRef.current) return;
    if (raw.length > roman.length) {
      startTimer();
      let buffer = roman;
      let output = committed;
      const appended = raw.slice(roman.length);
      for (const char of appended) {
        if (char === " ") {
          output += `${transliterate(buffer)} `;
          buffer = "";
        } else if (/[a-zA-Z0-9]/i.test(char)) {
          buffer += char;
        } else if (char === ".") {
          output += `${transliterate(buffer)}।`;
          buffer = "";
        } else {
          output += transliterate(buffer) + char;
          buffer = "";
        }
      }
      setRoman(buffer);
      setCommitted(output);
      if (toGraphemes(output).length >= toGraphemes(target).length && target.length > 0) {
        void finish(output);
      }
    } else {
      if (roman.length > 0) {
        setRoman(roman.slice(0, Math.max(0, raw.length)));
      } else {
        setCommitted(Array.from(committed).slice(0, -1).join(""));
      }
    }
    if (settings.soundEnabled) playTone("key", true);
  };

  const metrics = result ?? computeMetrics({ target, typed: typedScored, elapsedMs });
  const progress = metrics.completion;

  return (
    <SectionCard
      title={passage ? `Phonetic practice · ${passage.title}` : "Phonetic practice"}
      description="Type roman letters — the buffer converts them to Unicode Devanagari when a word is committed with space."
      action={
        <div className="flex items-center gap-2">
          <Badge tone="brand">Phonetic</Badge>
          <button type="button" onClick={onNext} className="btn btn-ghost !py-1.5 !text-xs">
            <RefreshCw size={13} /> Next passage
          </button>
        </div>
      }
    >
      <div className="space-y-3" key={sessionKey}>
        <div className="card-flat max-h-[220px] overflow-y-auto p-4">
          <p className="passage passage-hi !text-lg">
            {toGraphemes(target).map((grapheme, index) => {
              const typedGraphemes = toGraphemes(typedScored);
              const typed = typedGraphemes[index];
              if (typed === undefined) {
                return (
                  <span key={index} className={index === typedGraphemes.length ? "char-current" : "char-pending"}>
                    {grapheme}
                  </span>
                );
              }
              return (
                <span key={index} className={typed === grapheme ? "char-correct" : "char-incorrect"}>
                  {grapheme}
                </span>
              );
            })}
          </p>
        </div>

        <div className="grid gap-2 sm:grid-cols-3">
          <div className="card-flat p-2.5">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Committed Hindi</p>
            <p className="mt-1 min-h-6 text-sm font-semibold text-ink">{preview ? `${preview}…` : typedScored || "—"}</p>
          </div>
          <div className="card-flat p-2.5">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Live WPM / accuracy</p>
            <p className="mt-1 text-sm font-semibold text-brand">
              {metrics.netWpm.toFixed(0)} WPM · {metrics.accuracy.toFixed(0)}%
            </p>
          </div>
          <div className="card-flat p-2.5">
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.1em] text-muted">Progress</p>
            <p className="mt-1 text-sm font-semibold text-ink">{progress.toFixed(0)}%</p>
          </div>
        </div>

        <div>
          <label className="label" htmlFor="phonetic-input">
            Type roman text (e.g. &quot;namaste bharat&quot;)
          </label>
          <input
            id="phonetic-input"
            value={roman}
            onChange={(event) => handleChange(event.target.value)}
            placeholder="namaste bharat, yah practice hai"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            disabled={result !== null}
            className="input font-mono"
          />
          <p className="mt-1 text-[0.68rem] text-muted">
            Only committed words are scored live. The word currently being composed is shown as a preview and is
            never counted, so incomplete composition cannot damage your accuracy. Finishing commits the pending word.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={() => void finish(committed + preview)} className="btn btn-primary !py-2 !text-xs">
            <CheckCircle2 size={13} /> Finish &amp; save
          </button>
          <button type="button" onClick={reset} className="btn btn-ghost !py-2 !text-xs">
            <RefreshCw size={13} /> Restart
          </button>
          <span className="text-[0.68rem] text-muted">
            {saved === "saved"
              ? "Result saved."
              : saved === "saving"
                ? "Saving…"
                : saved === "error"
                  ? "Save failed — try again."
                  : "Finish to save this practice result."}
          </span>
        </div>

        <VirtualKeyboard
          layout="hi"
          expected={toGraphemes(target)[toGraphemes(typedScored).length] ?? null}
          lastTyped={null}
          interactive={false}
        />
      </div>
    </SectionCard>
  );
}
