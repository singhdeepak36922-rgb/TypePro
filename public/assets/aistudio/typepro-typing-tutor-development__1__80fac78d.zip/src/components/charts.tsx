"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  PolarAngleAxis,
  PolarGrid,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { DailyPoint } from "@/lib/stats";

const AXIS = "#8e9dbd";
const GRID = "rgba(142,157,189,0.18)";
const BRAND = "#3b82f6";
const CYAN = "#22d3ee";
const SUCCESS = "#34d399";

const tooltipStyle = {
  background: "var(--surface)",
  border: "1px solid var(--line)",
  borderRadius: 12,
  fontSize: 12,
  color: "var(--ink)",
  boxShadow: "0 10px 30px -18px rgba(0,0,0,0.6)",
} as const;

export function ActivityChart({ data, height = 200 }: { data: DailyPoint[]; height?: number }) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 6, right: 6, left: -22, bottom: 0 }}>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 10, fill: AXIS }}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
          />
          <YAxis tick={{ fontSize: 10, fill: AXIS }} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(59,130,246,0.08)" }} />
          <Bar dataKey="minutes" radius={[4, 4, 0, 0]} fill={BRAND} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WpmChart({ data, height = 220 }: { data: DailyPoint[]; height?: number }) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 8, right: 10, left: -22, bottom: 0 }}>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 10, fill: AXIS }} tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 10, fill: AXIS }} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 11, color: AXIS }} />
          <Line
            type="monotone"
            dataKey="wpm"
            name="Net WPM"
            stroke={BRAND}
            strokeWidth={2.4}
            dot={{ r: 2.5, fill: BRAND }}
            activeDot={{ r: 4 }}
          />
          <Line
            type="monotone"
            dataKey="accuracy"
            name="Accuracy %"
            stroke={CYAN}
            strokeWidth={2}
            strokeDasharray="4 3"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AccuracyChart({ data, height = 220 }: { data: DailyPoint[]; height?: number }) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <AreaChart data={data} margin={{ top: 8, right: 10, left: -22, bottom: 0 }}>
          <defs>
            <linearGradient id="accuracyFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={SUCCESS} stopOpacity={0.45} />
              <stop offset="100%" stopColor={SUCCESS} stopOpacity={0.04} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 10, fill: AXIS }} tickLine={false} axisLine={false} />
          <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: AXIS }} tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Area
            type="monotone"
            dataKey="accuracy"
            name="Accuracy %"
            stroke={SUCCESS}
            strokeWidth={2.2}
            fill="url(#accuracyFill)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WeakKeyChart({
  data,
  height = 240,
}: {
  data: { key: string; accuracy: number; attempts: number }[];
  height?: number;
}) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 4, bottom: 0 }}>
          <CartesianGrid stroke={GRID} horizontal={false} />
          <XAxis
            type="number"
            domain={[0, 100]}
            tick={{ fontSize: 10, fill: AXIS }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            type="category"
            dataKey="key"
            width={46}
            tick={{ fontSize: 11, fill: AXIS }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip contentStyle={tooltipStyle} />
          <Bar dataKey="accuracy" radius={[0, 4, 4, 0]}>
            {data.map((entry) => (
              <Cell key={entry.key} fill={entry.accuracy < 85 ? "#fb7185" : entry.accuracy < 95 ? "#fbbf24" : SUCCESS} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SpeedRadar({
  data,
  height = 240,
}: {
  data: { metric: string; value: number }[];
  height?: number;
}) {
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer>
        <RadarChart data={data} outerRadius="72%">
          <PolarGrid stroke={GRID} />
          <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: AXIS }} />
          <Radar dataKey="value" stroke={BRAND} fill={CYAN} fillOpacity={0.28} />
          <Tooltip contentStyle={tooltipStyle} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
