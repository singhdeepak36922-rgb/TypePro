"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  BarChart3,
  Gamepad2,
  GraduationCap,
  Keyboard,
  Languages,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  Monitor,
  Moon,
  PenLine,
  Settings as SettingsIcon,
  Sun,
  Timer,
  Trophy,
  UserRound,
  X,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { InstallButton } from "@/components/pwa";
import { useProgress } from "@/components/providers";
import { ProgressBar } from "@/components/ui";

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/learn", label: "Learn Typing", icon: GraduationCap },
  { href: "/test", label: "Typing Test", icon: Timer },
  { href: "/practice", label: "Free Practice", icon: PenLine },
  { href: "/hindi", label: "Hindi Typing", icon: Languages },
  { href: "/games", label: "Typing Games", icon: Gamepad2 },
  { href: "/keyboard", label: "Virtual Keyboard", icon: Keyboard },
  { href: "/reports", label: "Performance Reports", icon: BarChart3 },
  { href: "/achievements", label: "Achievements", icon: Trophy },
  { href: "/settings", label: "Settings", icon: SettingsIcon },
  { href: "/profile", label: "Profile", icon: UserRound },
];

const TITLES = new Map(NAV.map((item) => [item.href, item.label]));

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const {
    user,
    settings,
    updateSettings,
    summary,
    newAchievements,
    dismissNewAchievements,
    signOut,
  } = useProgress();

  const activeTitle = (() => {
    const exact = TITLES.get(pathname);
    if (exact) return exact;
    if (pathname.startsWith("/learn/")) return "Lesson";
    return "TypePro";
  })();

  const cycleTheme = () => {
    const order = ["dark", "light", "system"] as const;
    const current = order.indexOf(settings.theme);
    void updateSettings({ theme: order[(current + 1) % order.length] });
  };

  const ThemeIcon = settings.theme === "dark" ? Moon : settings.theme === "light" ? Sun : Monitor;

  const handleSignOut = async () => {
    await signOut();
    router.push("/");
    router.refresh();
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-4 py-4">
        <Link href="/" aria-label="TypePro dashboard">
          <Logo />
        </Link>
        <button
          type="button"
          className="btn btn-ghost !p-2 lg:hidden"
          onClick={() => setMobileOpen(false)}
          aria-label="Close navigation"
        >
          <X size={17} />
        </button>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-2.5 pb-4">
        {NAV.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`group flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[0.84rem] font-semibold transition ${
                active
                  ? "bg-brand-soft text-brand"
                  : "text-muted hover:bg-panel hover:text-ink"
              }`}
            >
              <Icon size={17} strokeWidth={2.1} className={active ? "text-brand" : ""} />
              <span>{item.label}</span>
              {active ? <span className="ml-auto h-1.5 w-1.5 rounded-full bg-brand" /> : null}
            </Link>
          );
        })}
      </nav>

      <div className="mx-2.5 mb-3 rounded-xl border border-line bg-panel/60 p-3">
        <div className="flex items-center justify-between text-[0.7rem] font-semibold uppercase tracking-[0.1em] text-muted">
          <span>Daily goal</span>
          <span className="text-brand">{Math.round(summary.goalPercent)}%</span>
        </div>
        <div className="mt-2">
          <ProgressBar value={summary.goalPercent} />
        </div>
        <p className="mt-2 text-[0.7rem] text-muted">
          {summary.todayMinutes.toFixed(0)} / {settings.dailyGoalMinutes} min today
        </p>
      </div>

      <div className="border-t border-line p-3">
        {user ? (
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-brand to-cyan text-sm font-bold text-white">
              {user.name.slice(0, 1).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-bold text-ink">{user.name}</p>
              <p className="truncate text-[0.68rem] text-muted">Synced account</p>
            </div>
            <button
              type="button"
              onClick={() => {
                void handleSignOut();
              }}
              className="rounded-lg p-1.5 text-muted hover:bg-panel hover:text-danger"
              aria-label="Sign out"
              title="Sign out"
            >
              <LogOut size={15} />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-[0.68rem] font-semibold uppercase tracking-[0.12em] text-muted">
              Guest mode · saved locally
            </p>
            <Link href="/login" className="btn btn-primary w-full !py-2 !text-xs">
              <LogIn size={14} /> Sign in to sync
            </Link>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-app">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] border-r border-line bg-surface lg:block">
        {sidebar}
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-black/60"
            aria-label="Close navigation overlay"
            onClick={() => setMobileOpen(false)}
          />
          <div className="absolute inset-y-0 left-0 w-[270px] border-r border-line bg-surface">
            {sidebar}
          </div>
        </div>
      ) : null}

      <div className="lg:pl-[248px]">
        <header className="sticky top-0 z-20 border-b border-line bg-app/85 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
            <button
              type="button"
              className="btn btn-ghost !p-2 lg:hidden"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation"
            >
              <Menu size={18} />
            </button>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-ink">{activeTitle}</p>
              <p className="hidden text-[0.7rem] text-muted sm:block">
                Master your typing skills · {user ? "Cloud sync on" : "Guest mode"}
              </p>
            </div>
            <div className="hidden items-center gap-2 sm:flex">
              <span className="chip">
                <Trophy size={12} /> {summary.bestWpm.toFixed(0)} best WPM
              </span>
              <span className="chip">
                <Timer size={12} /> {summary.totalTests} tests
              </span>
            </div>
            <InstallButton />
            <button
              type="button"
              className="btn btn-ghost !p-2"
              onClick={cycleTheme}
              aria-label={`Theme: ${settings.theme}. Click to change.`}
              title={`Theme: ${settings.theme}`}
            >
              <ThemeIcon size={17} />
            </button>
            <Link href={user ? "/profile" : "/login"} className="btn btn-soft !py-2 !text-xs">
              <UserRound size={14} />
              <span className="hidden sm:inline">{user ? user.name.split(" ")[0] : "Sign in"}</span>
            </Link>
          </div>
        </header>

        <main className="app-safe mx-auto w-full max-w-[1280px] px-4 py-5 sm:px-6 sm:py-7">{children}</main>
        <footer className="mx-auto w-full max-w-[1280px] px-4 pb-8 pt-2 text-center text-[0.7rem] text-muted sm:px-6">
          TypePro · Master your typing skills · English + Hindi (Devanagari) · Data saved{" "}
          {user ? "to your account" : "in this browser"}
        </footer>
      </div>

      {newAchievements.length > 0 ? (
        <div className="fixed bottom-4 right-4 z-50 w-[min(92vw,340px)]">
          <div className="card fade-up border-brand/40 p-4">
            <div className="flex items-start gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-soft text-brand">
                <Trophy size={18} />
              </span>
              <div className="flex-1">
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-brand">
                  Achievement unlocked
                </p>
                {newAchievements.map((achievement) => (
                  <p key={achievement.key} className="mt-1 text-sm font-semibold text-ink">
                    {achievement.title}
                  </p>
                ))}
              </div>
              <button
                type="button"
                onClick={dismissNewAchievements}
                className="rounded p-1 text-muted hover:text-ink"
                aria-label="Dismiss achievement notification"
              >
                <X size={15} />
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
