import {
  boolean,
  integer,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * TypePro relational schema.
 * Users own all of their results, progress, settings and achievements.
 * Guests never touch these tables – their data lives in browser storage
 * until they create an account and import it.
 */

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    passwordHash: text("password_hash").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)],
);

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: text("id").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const userSettings = pgTable("user_settings", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").notNull().default("dark"),
  language: text("language").notNull().default("en"),
  soundEnabled: boolean("sound_enabled").notNull().default(true),
  cursorStyle: text("cursor_style").notNull().default("line"),
  keyboardLayout: text("keyboard_layout").notNull().default("qwerty"),
  defaultDuration: integer("default_duration").notNull().default(60),
  defaultCategory: text("default_category").notNull().default("beginner"),
  dailyGoalMinutes: integer("daily_goal_minutes").notNull().default(15),
  showKeyboard: boolean("show_keyboard").notNull().default(true),
  strictMode: boolean("strict_mode").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const courses = pgTable(
  "courses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    level: text("level").notNull(),
    language: text("language").notNull().default("en"),
    description: text("description").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("courses_slug_unique").on(table.slug)],
);

export const lessons = pgTable(
  "lessons",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    courseId: uuid("course_id")
      .notNull()
      .references(() => courses.id, { onDelete: "cascade" }),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    level: text("level").notNull(),
    language: text("language").notNull().default("en"),
    instructions: text("instructions").notNull(),
    content: text("content").notNull(),
    focus: text("focus").notNull().default("Home row"),
    estMinutes: integer("est_minutes").notNull().default(5),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (table) => [uniqueIndex("lessons_slug_unique").on(table.slug)],
);

export const passages = pgTable(
  "passages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    language: text("language").notNull().default("en"),
    category: text("category").notNull(),
    difficulty: text("difficulty").notNull().default("beginner"),
    content: text("content").notNull(),
    wordCount: integer("word_count").notNull().default(0),
  },
  (table) => [uniqueIndex("passages_slug_unique").on(table.slug)],
);

export const typingResults = pgTable("typing_results", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  mode: text("mode").notNull(),
  refId: text("ref_id"),
  refTitle: text("ref_title").notNull().default(""),
  language: text("language").notNull().default("en"),
  durationSeconds: integer("duration_seconds").notNull().default(0),
  elapsedSeconds: integer("elapsed_seconds").notNull().default(0),
  grossWpm: real("gross_wpm").notNull().default(0),
  netWpm: real("net_wpm").notNull().default(0),
  standardWpm: real("standard_wpm").notNull().default(0),
  accuracy: real("accuracy").notNull().default(0),
  errors: integer("errors").notNull().default(0),
  totalTyped: integer("total_typed").notNull().default(0),
  correctChars: integer("correct_chars").notNull().default(0),
  keystrokeErrors: integer("keystroke_errors").notNull().default(0),
  backspaceCount: integer("backspace_count").notNull().default(0),
  score: integer("score").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const lessonProgress = pgTable(
  "lesson_progress",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonSlug: text("lesson_slug").notNull(),
    attempts: integer("attempts").notNull().default(0),
    bestWpm: real("best_wpm").notNull().default(0),
    bestAccuracy: real("best_accuracy").notNull().default(0),
    completed: boolean("completed").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("lesson_progress_user_lesson_unique").on(table.userId, table.lessonSlug)],
);

export const achievements = pgTable(
  "achievements",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    key: text("key").notNull(),
    unlockedAt: timestamp("unlocked_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("achievements_user_key_unique").on(table.userId, table.key)],
);

export const keyStats = pgTable(
  "key_stats",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    key: text("key").notNull(),
    correct: integer("correct").notNull().default(0),
    incorrect: integer("incorrect").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("key_stats_user_key_unique").on(table.userId, table.key)],
);
