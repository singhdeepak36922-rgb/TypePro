import type { Summary } from "./stats";

export interface AchievementDef {
  key: string;
  title: string;
  description: string;
  icon: string;
  tier: "bronze" | "silver" | "gold" | "platinum";
  isUnlocked: (summary: Summary) => boolean;
  progress: (summary: Summary) => number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    key: "first-test",
    title: "First Typing Test",
    description: "Complete your very first typing test.",
    icon: "flag",
    tier: "bronze",
    isUnlocked: (s) => s.totalTests >= 1,
    progress: (s) => Math.min(100, s.totalTests * 100),
  },
  {
    key: "wpm-20",
    title: "20 WPM Club",
    description: "Reach 20 net WPM in a saved session.",
    icon: "gauge",
    tier: "bronze",
    isUnlocked: (s) => s.bestWpm >= 20,
    progress: (s) => Math.min(100, (s.bestWpm / 20) * 100),
  },
  {
    key: "wpm-30",
    title: "30 WPM Club",
    description: "Reach 30 net WPM.",
    icon: "zap",
    tier: "silver",
    isUnlocked: (s) => s.bestWpm >= 30,
    progress: (s) => Math.min(100, (s.bestWpm / 30) * 100),
  },
  {
    key: "wpm-40",
    title: "40 WPM Club",
    description: "Reach 40 net WPM.",
    icon: "rocket",
    tier: "silver",
    isUnlocked: (s) => s.bestWpm >= 40,
    progress: (s) => Math.min(100, (s.bestWpm / 40) * 100),
  },
  {
    key: "wpm-50",
    title: "50 WPM Club",
    description: "Reach 50 net WPM.",
    icon: "trophy",
    tier: "gold",
    isUnlocked: (s) => s.bestWpm >= 50,
    progress: (s) => Math.min(100, (s.bestWpm / 50) * 100),
  },
  {
    key: "accuracy-95",
    title: "Precision 95%",
    description: "Finish a session with at least 95% accuracy.",
    icon: "target",
    tier: "silver",
    isUnlocked: (s) => s.bestAccuracy >= 95,
    progress: (s) => Math.min(100, (s.bestAccuracy / 95) * 100),
  },
  {
    key: "accuracy-100",
    title: "Flawless",
    description: "Finish a session with 100% accuracy.",
    icon: "gem",
    tier: "platinum",
    isUnlocked: (s) => s.bestAccuracy >= 100,
    progress: (s) => Math.min(100, s.bestAccuracy),
  },
  {
    key: "streak-7",
    title: "7-Day Streak",
    description: "Practice on seven consecutive days.",
    icon: "flame",
    tier: "gold",
    isUnlocked: (s) => s.streak >= 7,
    progress: (s) => Math.min(100, (s.streak / 7) * 100),
  },
  {
    key: "streak-30",
    title: "30-Day Streak",
    description: "Practice on thirty consecutive days.",
    icon: "calendar",
    tier: "platinum",
    isUnlocked: (s) => s.streak >= 30,
    progress: (s) => Math.min(100, (s.streak / 30) * 100),
  },
  {
    key: "lesson-first",
    title: "First Lesson",
    description: "Complete your first structured lesson.",
    icon: "book",
    tier: "bronze",
    isUnlocked: (s) => s.lessonsCompleted >= 1,
    progress: (s) => Math.min(100, s.lessonsCompleted * 100),
  },
  {
    key: "tests-25",
    title: "Committed Learner",
    description: "Complete 25 typing tests.",
    icon: "layers",
    tier: "silver",
    isUnlocked: (s) => s.totalTests >= 25,
    progress: (s) => Math.min(100, (s.totalTests / 25) * 100),
  },
  {
    key: "hindi-first",
    title: "Devanagari Debut",
    description: "Save a Hindi typing session.",
    icon: "languages",
    tier: "bronze",
    isUnlocked: (s) => s.hindiSessions >= 1,
    progress: (s) => Math.min(100, s.hindiSessions * 100),
  },
];

export function evaluateAchievements(summary: Summary) {
  return ACHIEVEMENTS.map((achievement) => ({
    key: achievement.key,
    title: achievement.title,
    description: achievement.description,
    icon: achievement.icon,
    tier: achievement.tier,
    unlocked: achievement.isUnlocked(summary),
    progress: Math.round(achievement.progress(summary)),
  }));
}

export type AchievementState = ReturnType<typeof evaluateAchievements>[number];
