import { describe, expect, it } from "vitest";
import { PhoneticBuffer, transliterate } from "./transliterate";

describe("phonetic transliteration", () => {
  it("handles empty input", () => {
    expect(transliterate("")).toBe("");
  });

  it("converts consonants and inherent vowels", () => {
    expect(transliterate("bharat")).toBe("भरत");
    expect(transliterate("namaste")).toBe("नमस्ते");
  });

  it("builds conjuncts with the virama", () => {
    expect(transliterate("kya")).toBe("क्य");
    expect(transliterate("hindee")).toBe("हिन्दी");
  });

  it("uses matras and covers aspirated consonants", () => {
    expect(transliterate("kaa")).toBe("का");
    expect(transliterate("chh")).toBe("छ");
    expect(transliterate("ksh")).toBe("क्ष");
  });

  it("passes through spaces, punctuation and converts digits", () => {
    expect(transliterate("2026")).toBe("२०२६");
    expect(transliterate("a b")).toBe("अ ब");
  });

  it("preserves anusvara", () => {
    expect(transliterate("maiM")).toBe("मैं");
  });

  it("only commits complete words in the buffer", () => {
    const buffer = new PhoneticBuffer();
    buffer.type("n");
    buffer.type("a");
    expect(buffer.committedText).toBe("");
    expect(buffer.devanagariPreview).toBe("न");
    buffer.type("m");
    buffer.type(" ");
    expect(buffer.committedText).toBe("नम ");
    expect(buffer.devanagariPreview).toBe("");
  });

  it("backspace shrinks the roman buffer before committed text", () => {
    const buffer = new PhoneticBuffer();
    buffer.type("ka");
    buffer.type(" ");
    buffer.type("ra");
    buffer.backspace();
    expect(buffer.romanBuffer).toBe("r");
    buffer.backspace();
    buffer.backspace();
    expect(buffer.committedText).toBe("क");
  });
});
