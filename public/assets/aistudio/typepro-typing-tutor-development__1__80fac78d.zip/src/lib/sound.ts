"use client";

/** Tiny WebAudio click generator – no assets required. */
let context: AudioContext | null = null;

function getContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Ctor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!context) context = new Ctor();
  return context;
}

export function playTone(kind: "key" | "error" | "success" | "finish", enabled: boolean): void {
  if (!enabled) return;
  const ctx = getContext();
  if (!ctx) return;
  if (ctx.state === "suspended") void ctx.resume();
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);

  if (kind === "error") {
    osc.type = "sawtooth";
    osc.frequency.value = 150;
    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
    osc.start(now);
    osc.stop(now + 0.13);
    return;
  }

  const map = { key: 640, success: 780, finish: 880 } as const;
  osc.type = "sine";
  osc.frequency.setValueAtTime(map[kind], now);
  if (kind === "finish") osc.frequency.exponentialRampToValueAtTime(1180, now + 0.18);
  gain.gain.setValueAtTime(0.045, now);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + (kind === "finish" ? 0.3 : 0.08));
  osc.start(now);
  osc.stop(now + (kind === "finish" ? 0.32 : 0.1));
}
