import type { Difficulty, Language } from "./types";

export interface CourseSeed {
  slug: string;
  title: string;
  level: "beginner" | "intermediate" | "advanced";
  language: Language;
  description: string;
  sortOrder: number;
}

export interface LessonSeed {
  courseSlug: string;
  slug: string;
  title: string;
  level: "beginner" | "intermediate" | "advanced";
  language: Language;
  instructions: string;
  content: string;
  focus: string;
  estMinutes: number;
  sortOrder: number;
}

export interface PassageSeed {
  slug: string;
  title: string;
  language: Language;
  category: string;
  difficulty: Difficulty;
  content: string;
}

export const COURSES: CourseSeed[] = [
  {
    slug: "english-beginner",
    title: "Keyboard Foundations",
    level: "beginner",
    language: "en",
    description:
      "Start from zero: learn the keyboard, place your fingers correctly and build home-row muscle memory.",
    sortOrder: 1,
  },
  {
    slug: "english-intermediate",
    title: "Everyday Fluency",
    level: "intermediate",
    language: "en",
    description:
      "Move from letters to words, sentences and full paragraphs with steady rhythm and punctuation control.",
    sortOrder: 2,
  },
  {
    slug: "english-advanced",
    title: "Professional Speed",
    level: "advanced",
    language: "en",
    description:
      "Long passages, difficult vocabulary and exam-standard drills for serious speed and accuracy work.",
    sortOrder: 3,
  },
];

export const LESSONS: LessonSeed[] = [
  {
    courseSlug: "english-beginner",
    slug: "introduction-to-keyboard",
    title: "Introduction to the Keyboard",
    level: "beginner",
    language: "en",
    instructions:
      "Sit upright with both feet flat. Rest your wrists gently without touching the desk. Type each line slowly and let your eyes stay on the screen, not on your hands.",
    content:
      "asdf jkl; asdf jkl; ff jj dd kk ss ll aa ;; fdsa jkl; fdsa jkl;",
    focus: "Keyboard basics",
    estMinutes: 4,
    sortOrder: 1,
  },
  {
    courseSlug: "english-beginner",
    slug: "finger-positioning",
    title: "Finger Positioning",
    level: "beginner",
    language: "en",
    instructions:
      "Place your index fingers on F and J. The small bumps help you find them without looking. Every finger now owns a vertical column of keys.",
    content:
      "fff jjj fff jjj fjjf jffj ddd kkk ddd kkk dkdk kdkd fj fj dk dk fjd kfj",
    focus: "F and J anchors",
    estMinutes: 4,
    sortOrder: 2,
  },
  {
    courseSlug: "english-beginner",
    slug: "home-row-keys",
    title: "Home Row Keys",
    level: "beginner",
    language: "en",
    instructions:
      "The home row is asdf jkl;. Use the ring, middle, index and pinky fingers on both hands. Return to the home row after every key press.",
    content:
      "asdf jkl; ask fall lads glass flask hall dash salad falls lake;",
    focus: "Home row",
    estMinutes: 5,
    sortOrder: 3,
  },
  {
    courseSlug: "english-beginner",
    slug: "left-hand-exercises",
    title: "Left Hand Exercises",
    level: "beginner",
    language: "en",
    instructions:
      "Your left hand covers qwert, asdfg and zxcvb. Keep the left pinky relaxed while the other fingers work.",
    content:
      "add gas fast safe caves sea great draft waste serve staff brave",
    focus: "Left hand",
    estMinutes: 5,
    sortOrder: 4,
  },
  {
    courseSlug: "english-beginner",
    slug: "right-hand-exercises",
    title: "Right Hand Exercises",
    level: "beginner",
    language: "en",
    instructions:
      "Your right hand covers yuiop, hjkl and nm,./. Keep the elbow close to your body and avoid stretching the wrist.",
    content:
      "kill hill milk noon moon pool join loop lion mink pink jolly",
    focus: "Right hand",
    estMinutes: 5,
    sortOrder: 5,
  },
  {
    courseSlug: "english-beginner",
    slug: "upper-row-keys",
    title: "The Upper Row",
    level: "beginner",
    language: "en",
    instructions:
      "Reach upward without moving the whole hand. The index finger handles r and t, while the pinky covers q and p.",
    content:
      "we type quite well when quiet words appear. reply to every uptown query.",
    focus: "Upper row",
    estMinutes: 5,
    sortOrder: 6,
  },
  {
    courseSlug: "english-beginner",
    slug: "bottom-row-keys",
    title: "The Bottom Row",
    level: "beginner",
    language: "en",
    instructions:
      "Reach downward with a small controlled motion. Do not let your palms drop; keep the home row as your base.",
    content:
      "zoom into five cabins. max can box every zany video before noon.",
    focus: "Bottom row",
    estMinutes: 5,
    sortOrder: 7,
  },
  {
    courseSlug: "english-beginner",
    slug: "capital-letters-numbers",
    title: "Capitals, Numbers and Punctuation",
    level: "beginner",
    language: "en",
    instructions:
      "Use the opposite hand for Shift: right Shift for left-hand letters, left Shift for right-hand letters. Numbers sit on the top row.",
    content:
      "TypePro 2026 has 12 lessons, 6 tests and 5 games. Press Shift for Delhi, Mumbai and Pune.",
    focus: "Shift, numbers, punctuation",
    estMinutes: 6,
    sortOrder: 8,
  },
  {
    courseSlug: "english-beginner",
    slug: "beginner-speed-check",
    title: "Beginner Speed Check",
    level: "beginner",
    language: "en",
    instructions:
      "Combine everything you have learned. Prioritise accuracy: aim for at least 95% before pushing for speed.",
    content:
      "The kind reader keeps a steady hand. A calm mind types clean words, and clean words build lasting speed.",
    focus: "Review drill",
    estMinutes: 6,
    sortOrder: 9,
  },
  {
    courseSlug: "english-intermediate",
    slug: "common-words",
    title: "Common Word Patterns",
    level: "intermediate",
    language: "en",
    instructions:
      "The most frequent English words appear in this drill. Keep a light touch and use whole-word rhythm instead of letter-by-letter pauses.",
    content:
      "the of and to in that it for you was with this have from they will one all would there their what about which when make like time just know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us",
    focus: "High frequency words",
    estMinutes: 6,
    sortOrder: 1,
  },
  {
    courseSlug: "english-intermediate",
    slug: "word-combinations",
    title: "Word Combinations",
    level: "intermediate",
    language: "en",
    instructions:
      "Read ahead by two or three words. Your fingers should follow the phrase, not each separate letter.",
    content:
      "time management, data entry, daily practice, clear goals, steady progress, error control, home row, quick review, exam pattern, official language, working hours, quality output, keyboard layout, typing speed, accuracy report",
    focus: "Word pairs",
    estMinutes: 6,
    sortOrder: 2,
  },
  {
    courseSlug: "english-intermediate",
    slug: "sentence-typing",
    title: "Sentence Typing",
    level: "intermediate",
    language: "en",
    instructions:
      "Type complete sentences including capital letters and full stops. Use Shift with the opposite hand.",
    content:
      "Practice builds confidence. Accurate typing saves time. Every lesson adds a small skill. Keep your eyes on the screen. Rest your fingers on the home row. Speed follows control.",
    focus: "Sentences",
    estMinutes: 7,
    sortOrder: 3,
  },
  {
    courseSlug: "english-intermediate",
    slug: "paragraph-typing",
    title: "Paragraph Typing",
    level: "intermediate",
    language: "en",
    instructions:
      "Hold a conversation-friendly pace. If you make a mistake, correct it immediately with Backspace and continue.",
    content:
      "Good typists do not rush. They keep a light rhythm, read ahead and trust their fingers. A short daily session is far more effective than a long weekly one, because muscle memory is built through repetition over time.",
    focus: "Paragraphs",
    estMinutes: 8,
    sortOrder: 4,
  },
  {
    courseSlug: "english-intermediate",
    slug: "punctuation-practice",
    title: "Capitalisation and Punctuation",
    level: "intermediate",
    language: "en",
    instructions:
      "Watch the comma, apostrophe, semicolon and question mark. Shift plus the punctuation key produces the upper symbol.",
    content:
      "Accuracy is not a detail; it is the goal. \"Type slowly,\" the trainer said. \"Does the passage feel comfortable?\" We typed 45 words in one minute, saved the result and revised the tricky keys.",
    focus: "Punctuation",
    estMinutes: 7,
    sortOrder: 5,
  },
  {
    courseSlug: "english-intermediate",
    slug: "speed-building",
    title: "Speed Building Drill",
    level: "intermediate",
    language: "en",
    instructions:
      "Do three passes of this drill. On pass one work slowly for accuracy; on passes two and three increase speed without dropping below 95% accuracy.",
    content:
      "Fast typing is a habit built from clean typing. When you feel errors rising, slow down for a few lines and reset your rhythm. The goal is consistent movement, not a single burst of speed.",
    focus: "Speed",
    estMinutes: 8,
    sortOrder: 6,
  },
  {
    courseSlug: "english-advanced",
    slug: "long-passages",
    title: "Long Passage Endurance",
    level: "advanced",
    language: "en",
    instructions:
      "This is a longer passage. Keep your breathing relaxed and hold your accuracy above 96% while maintaining a steady pace.",
    content:
      "A competitive examination rewards candidates who manage both time and precision under pressure. Typing speed is only useful when the output is free of errors, because every correction costs momentum. Practise with a timer, review your mistakes, then repeat the same passage until the difficult letter combinations feel automatic.",
    focus: "Endurance",
    estMinutes: 10,
    sortOrder: 1,
  },
  {
    courseSlug: "english-advanced",
    slug: "professional-typing",
    title: "Professional Typing",
    level: "advanced",
    language: "en",
    instructions:
      "Business writing needs clean punctuation, consistent spacing and correct capitalisation. Type at a controlled professional pace.",
    content:
      "Dear Candidate, thank you for attending the skill assessment on 14 March. The evaluation covered data accuracy, English typing speed and attention to detail. Kindly submit the signed declaration form, along with a valid identity document, to the regional office before the end of this month.",
    focus: "Business writing",
    estMinutes: 9,
    sortOrder: 2,
  },
  {
    courseSlug: "english-advanced",
    slug: "difficult-words",
    title: "Difficult Words",
    level: "advanced",
    language: "en",
    instructions:
      "Unusual letter patterns force your fingers out of habit. Type each word in one flow rather than looking for individual keys.",
    content:
      "bureaucracy, conscientious, miscellaneous, questionnaire, phenomenon, entrepreneur, pharmaceutical, unprecedented, vulnerability, synchronisation, prerequisite, acknowledgment, thoroughly, hierarchy, juxtaposition",
    focus: "Complex spelling",
    estMinutes: 9,
    sortOrder: 3,
  },
  {
    courseSlug: "english-advanced",
    slug: "accuracy-training",
    title: "Accuracy Training",
    level: "advanced",
    language: "en",
    instructions:
      "Target 100% accuracy. If you finish below 98%, restart the drill instead of moving on.",
    content:
      "The test centre required every candidate to verify the registration number, confirm the allotted seat and read the instructions carefully before pressing the start button. No correction was permitted after the final submission, so precision mattered more than raw speed.",
    focus: "Accuracy",
    estMinutes: 8,
    sortOrder: 4,
  },
  {
    courseSlug: "english-advanced",
    slug: "exam-passage-drill",
    title: "Competitive Exam Passage",
    level: "advanced",
    language: "en",
    instructions:
      "This drill mirrors an SSC or banking skill test passage. Type continuously for the full duration and avoid stopping on errors.",
    content:
      "The Ministry of Finance has revised the guidelines for the unified pension scheme, stating that all eligible employees must submit their verification documents through the departmental portal. The circular also mentions that the deadline may be extended by fifteen days for candidates serving in remote regions. Departments are advised to publish the list of verified applicants on their official website.",
    focus: "Exam standard",
    estMinutes: 10,
    sortOrder: 5,
  },
];

export const PASSAGES: PassageSeed[] = [
  {
    slug: "en-beginner-home-row",
    title: "Home Row Warm Up",
    language: "en",
    category: "beginner",
    difficulty: "beginner",
    content:
      "The home row is the base of every typing lesson. Place your left fingers on a s d f and your right fingers on j k l. Keep your wrists relaxed and your eyes on the screen. Small daily practice builds strong muscle memory, so begin slowly and finish cleanly.",
  },
  {
    slug: "en-beginner-daily-routine",
    title: "A Simple Daily Routine",
    language: "en",
    category: "beginner",
    difficulty: "beginner",
    content:
      "Start your day with a glass of water and a short walk. Then sit at your desk, open your typing lesson, and practice for ten minutes. Write down the keys you miss most often and repeat them. A steady routine is better than a long session once a week.",
  },
  {
    slug: "en-intermediate-city-life",
    title: "Life in a Modern City",
    language: "en",
    category: "intermediate",
    difficulty: "intermediate",
    content:
      "City life moves quickly, and every morning thousands of people travel to work by bus, train and metro. Shops open early, offices fill up by nine, and the streets become busy again in the evening. Despite the noise and the crowd, people find quiet corners in libraries, parks and small cafes where they can read, study or simply sit for a while.",
  },
  {
    slug: "en-intermediate-technology",
    title: "Technology at Work",
    language: "en",
    category: "intermediate",
    difficulty: "intermediate",
    content:
      "Digital tools have changed the way teams work together. Documents are shared instantly, meetings happen online, and feedback arrives within minutes. The advantage is speed, but the challenge is focus. Good teams set clear rules: they write short messages, keep files organised, and leave space for the kind of concentrated work that produces quality results.",
  },
  {
    slug: "en-advanced-economy",
    title: "Reading the Economy",
    language: "en",
    category: "advanced",
    difficulty: "advanced",
    content:
      "Economic indicators rarely move in isolation. When inflation rises, central banks may increase interest rates, which can slow borrowing, cool demand and eventually ease price pressure. Analysts therefore examine several measures together: employment figures, industrial output, consumer confidence and trade balance. A single number, however dramatic, seldom tells the whole story.",
  },
  {
    slug: "en-general-discipline",
    title: "The Discipline of Practice",
    language: "en",
    category: "general-english",
    difficulty: "intermediate",
    content:
      "Skill is not a gift that arrives fully formed. It is built through deliberate repetition, honest review and patient correction. A learner who types for fifteen focused minutes each day will improve faster than one who waits for a free weekend. The secret is not intensity alone, but consistency: showing up when progress feels invisible and continuing until the difficult becomes ordinary.",
  },
  {
    slug: "en-competitive-ssc",
    title: "SSC Skill Test Passage",
    language: "en",
    category: "competitive",
    difficulty: "competitive",
    content:
      "The Staff Selection Commission conducts skill tests to assess the typing ability of candidates applying for clerical and data entry posts. Candidates are expected to type accurately from a printed passage within a fixed time limit. Only accurate words are counted, and a minimum speed of thirty-five words per minute is generally required. Applicants should practice on a standard keyboard and verify the official notification for the exact guidelines applicable to their post.",
  },
  {
    slug: "en-competitive-banking",
    title: "Banking Exam Passage",
    language: "en",
    category: "competitive",
    difficulty: "competitive",
    content:
      "The Reserve Bank of India has issued a circular regarding the submission of quarterly compliance reports by all scheduled commercial banks. The report must include details of customer complaints, the average time taken to resolve them, and the measures adopted to prevent unauthorised transactions. Banks are also required to publish a summary on their website and nominate a senior officer to coordinate with the regulator. Any delay in submission should be explained in writing.",
  },
  {
    slug: "en-competitive-railway",
    title: "Railway Recruitment Passage",
    language: "en",
    category: "competitive",
    difficulty: "competitive",
    content:
      "Railway recruitment boards have announced a computer based typing test for candidates shortlisted after the written examination. The test will be conducted at designated centres, and candidates must carry a printed admit card and a valid photo identity document. The duration of the test is ten minutes, during which candidates will be asked to reproduce the given passage. Marks will be awarded for accuracy, and the use of any unauthorised material will lead to disqualification.",
  },
  {
    slug: "hi-beginner-akshar",
    title: "हिंदी आरंभिक अभ्यास",
    language: "hi",
    category: "general-hindi",
    difficulty: "beginner",
    content:
      "हिंदी में टाइपिंग सीखना आसान है। पहले अपने हाथ सही जगह पर रखें। धीरे-धीरे अक्षर लिखें और गलतियों को सुधारें। रोज थोड़ा अभ्यास करने से गति अपने आप बढ़ती है। धैर्य रखें और साफ़ लिखाई पर ध्यान दें।",
  },
  {
    slug: "hi-intermediate-parivar",
    title: "परिवार और समाज",
    language: "hi",
    category: "general-hindi",
    difficulty: "intermediate",
    content:
      "परिवार हमारे जीवन का सबसे महत्वपूर्ण हिस्सा है। परिवार से हमें स्नेह, सहयोग और अनुशासन सीखने को मिलता है। समाज में रहने के लिए एकता आवश्यक है। जब हम दूसरों की सहायता करते हैं तो हमारा मन भी शांत रहता है। अच्छे संस्कार बच्चों को बड़ों के आदर और परिश्रम का महत्व सिखाते हैं।",
  },
  {
    slug: "hi-advanced-shiksha",
    title: "शिक्षा का महत्व",
    language: "hi",
    category: "general-hindi",
    difficulty: "advanced",
    content:
      "शिक्षा मनुष्य के व्यक्तित्व को निखारने का सबसे शक्तिशाली माध्यम है। यह केवल पुस्तकों का ज्ञान नहीं है, बल्कि सोचने, समझने और निर्णय लेने की क्षमता भी विकसित करती है। आज तकनीकी शिक्षा और कौशल विकास का विशेष महत्व है, क्योंकि बदलती दुनिया में नई चुनौतियों का सामना करना आवश्यक हो गया है। प्रतिस्पर्धा के युग में लगातार सीखने की आदत ही सफलता की कुंजी है।",
  },
  {
    slug: "hi-competitive-ssc",
    title: "एसएससी हिंदी परीक्षा अभ्यास",
    language: "hi",
    category: "competitive",
    difficulty: "competitive",
    content:
      "कर्मचारी चयन आयोग द्वारा आयोजित कौशल परीक्षा में अभ्यर्थियों को दिए गए अनुच्छेद को निर्धारित समय में शुद्ध रूप से टाइप करना होता है। परीक्षा पैटर्न के बारे में आधिकारिक अधिसूचना में दी गई जानकारी को विस्तार से पढ़ना चाहिए। आमतौर पर मंगल और इंस्क्रिप्ट दोनों व्यवस्थाओं में परीक्षा का विकल्प होता है। अभ्यास के समय घड़ी का उपयोग करें और छोटे-छोटे अनुच्छेदों पर ध्यान केंद्रित करें।",
  },
  {
    slug: "hi-competitive-railway",
    title: "रेलवे भर्ती हिंदी अभ्यास",
    language: "hi",
    category: "competitive",
    difficulty: "competitive",
    content:
      "भारतीय रेलवे ने नई भर्ती प्रक्रिया के अंतर्गत कंप्यूटर आधारित टाइपिंग परीक्षा का आयोजन किया है। चयनित अभ्यर्थियों को परीक्षा केंद्र पर प्रवेश पत्र तथा वैध पहचान पत्र लेकर जाना होगा। परीक्षा के दौरान किसी भी प्रकार की अनुचित सामग्री का उपयोग वर्जित है। परीक्षा की अवधि दस मिनट होती है और अंक शुद्धता के आधार पर दिए जाते हैं।",
  },
];
