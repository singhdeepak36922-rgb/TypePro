import type { KeyStat, StoredResult } from "./types";
import { round } from "./typing-engine";

export interface DailyPoint {
  date: string;
  label: string;
  minutes: number;
  tests: number;
  wpm: number;
  accuracy: number;
}

export interface Summary {
  totalResults: number;
  totalTests: number;
  totalPracticeSeconds: number;
  totalMinutes: number;
  avgWpm: number;
  avgNetWpm: number;
  bestWpm: number;
  avgAccuracy: number;
  bestAccuracy: number;
  todayMinutes: number;
  weekMinutes: number;
  goalPercent: number;
  streak: number;
  daily: DailyPoint[];
  weekly: DailyPoint[];
  monthly: DailyPoint[];
  recent: StoredResult[];
  lessonsCompleted: number;
  gamesPlayed: number;
  bestGameScores: Record<string, number>;
  weakKeys: { key: string; accuracy: number; attempts: number }[];
  hindiSessions: number;
  firstResultAt: string | null;
}

export function dayKey(date: Date): string {
  const y = date.getFullYear();
  const m = `${date.getMonth() + 1}`.padStart(2, "0");
  const d = `${date.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function buildDays(count: number): DailyPoint[] {
  const days: DailyPoint[] = [];
  const now = new Date();
  for (let i = count - 1; i >= 0; i -= 1) {
    const date = new Date(now);
    date.setDate(now.getDate() - i);
    days.push({
      date: dayKey(date),
      label: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      minutes: 0,
      tests: 0,
      wpm: 0,
      accuracy: 0,
    });
  }
  return days;
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

export function summarize(
  results: StoredResult[],
  options: { keyStats?: KeyStat[]; dailyGoalMinutes?: number } = {},
): Summary {
  const sorted = [...results].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
  );
  const daily = buildDays(30);
  const byDate = new Map(daily.map((point) => [point.date, point]));
  const wpmBuckets = new Map<string, number[]>();
  const accuracyBuckets = new Map<string, number[]>();

  let totalSeconds = 0;
  let totalTests = 0;
  let lessonsCompleted = 0;
  let gamesPlayed = 0;
  let hindiSessions = 0;
  const bestGameScores: Record<string, number> = {};

  for (const result of sorted) {
    totalSeconds += result.elapsedSeconds;
    if (result.mode === "test") totalTests += 1;
    if (result.mode === "lesson") lessonsCompleted += 1;
    if (result.language === "hi") hindiSessions += 1;
    if (result.mode === "game" && result.refId) {
      gamesPlayed += 1;
      bestGameScores[result.refId] = Math.max(bestGameScores[result.refId] ?? 0, result.score);
    }

    const created = new Date(result.createdAt);
    const key = dayKey(created);
    const point = byDate.get(key);
    if (point) {
      point.minutes = round(point.minutes + result.elapsedSeconds / 60);
      point.tests += 1;
    }
    const wpmList = wpmBuckets.get(key) ?? [];
    wpmList.push(result.netWpm);
    wpmBuckets.set(key, wpmList);
    const accList = accuracyBuckets.get(key) ?? [];
    accList.push(result.accuracy);
    accuracyBuckets.set(key, accList);
  }

  for (const point of daily) {
    point.wpm = average(wpmBuckets.get(point.date) ?? []);
    point.accuracy = average(accuracyBuckets.get(point.date) ?? []);
  }

  const today = dayKey(new Date());
  const todayMinutes = daily.find((point) => point.date === today)?.minutes ?? 0;
  const weekMinutes = round(daily.slice(-7).reduce((sum, point) => sum + point.minutes, 0));
  const goal = options.dailyGoalMinutes && options.dailyGoalMinutes > 0 ? options.dailyGoalMinutes : 15;

  // current streak: consecutive days with activity ending today or yesterday
  let streak = 0;
  for (let i = daily.length - 1; i >= 0; i -= 1) {
    const point = daily[i];
    if (point.minutes > 0) {
      streak += 1;
    } else if (i === daily.length - 1) {
      continue; // no activity yet today does not break the streak
    } else {
      break;
    }
  }

  const wpmValues = sorted.map((result) => result.netWpm).filter((value) => value > 0);
  const accuracyValues = sorted.map((result) => result.accuracy).filter((value) => value > 0);

  const weakKeys = (options.keyStats ?? [])
    .filter((stat) => stat.correct + stat.incorrect >= 3)
    .map((stat) => ({
      key: stat.key,
      attempts: stat.correct + stat.incorrect,
      accuracy: round((stat.correct / (stat.correct + stat.incorrect)) * 100),
    }))
    .sort((a, b) => a.accuracy - b.accuracy)
    .slice(0, 12);

  return {
    totalResults: sorted.length,
    totalTests,
    totalPracticeSeconds: totalSeconds,
    totalMinutes: round(totalSeconds / 60),
    avgWpm: average(wpmValues),
    avgNetWpm: average(sorted.map((result) => result.netWpm)),
    bestWpm: sorted.reduce((best, result) => Math.max(best, result.netWpm), 0),
    avgAccuracy: average(accuracyValues),
    bestAccuracy: sorted.reduce((best, result) => Math.max(best, result.accuracy), 0),
    todayMinutes,
    weekMinutes,
    goalPercent: Math.min(100, round((todayMinutes / goal) * 100)),
    streak,
    daily,
    weekly: daily.slice(-7),
    monthly: daily,
    recent: [...sorted].reverse().slice(0, 8),
    lessonsCompleted: new Set(sorted.filter((r) => r.mode === "lesson").map((r) => r.refId)).size,
    gamesPlayed,
    bestGameScores,
    weakKeys,
    hindiSessions,
    firstResultAt: sorted[0]?.createdAt ?? null,
  };
}

export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = Math.round(seconds % 60);
  if (minutes < 60) return rest > 0 ? `${minutes}m ${rest}s` : `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ${minutes % 60}m`;
}

export function formatRelative(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "—";
  const diff = Date.now() - then;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
