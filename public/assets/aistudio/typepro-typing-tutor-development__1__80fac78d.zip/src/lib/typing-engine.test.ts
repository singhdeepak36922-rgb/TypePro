import { describe, expect, it } from "vitest";
import {
  calculateAccuracy,
  calculateWpm,
  compareGraphemes,
  computeMetrics,
  graphemeLength,
  nextExpectedGrapheme,
  normalizePassage,
  toGraphemes,
} from "./typing-engine";

describe("grapheme segmentation", () => {
  it("splits plain text into characters", () => {
    expect(toGraphemes("abc")).toEqual(["a", "b", "c"]);
  });

  it("keeps Hindi matras attached to their consonant", () => {
    const graphemes = toGraphemes("हिन्दी");
    expect(graphemes[0]).toBe("हि");
    expect(graphemeLength("हिन्दी")).toBeLessThan(Array.from("हिन्दी").length);
    // Intl.Segmenter joins the conjunct न् + द + ी into a single cluster
    expect(graphemeLength("हिन्दी")).toBe(2);
  });

  it("handles empty input", () => {
    expect(toGraphemes("")).toEqual([]);
    expect(graphemeLength("")).toBe(0);
  });
});

describe("comparison", () => {
  it("counts correct and incorrect graphemes", () => {
    const result = compareGraphemes("hello world", "hello worle");
    expect(result.correctChars).toBe(10);
    expect(result.incorrectChars).toBe(1);
    expect(result.keyErrors[0].actual).toBe("e");
    expect(result.isComplete).toBe(true);
  });

  it("handles backspaced corrections (final text accuracy)", () => {
    const result = compareGraphemes("the quick", "the quick");
    expect(result.incorrectChars).toBe(0);
    expect(result.keyErrors).toHaveLength(0);
  });

  it("does not complete before the passage ends", () => {
    expect(compareGraphemes("hello", "hel").isComplete).toBe(false);
  });

  it("supports Hindi graphemes", () => {
    const result = compareGraphemes("क्या हाल है", "क्या हाल है");
    expect(result.incorrectChars).toBe(0);
    expect(result.isComplete).toBe(true);
  });
});

describe("WPM and accuracy math", () => {
  it("computes standard WPM for a full minute", () => {
    // 300 correct graphemes in 60s => 300 / 5 / 1 = 60 WPM
    expect(calculateWpm(300, 60000)).toBe(60);
  });

  it("returns 0 WPM for no characters", () => {
    expect(calculateWpm(0, 60000)).toBe(0);
  });

  it("never divides by zero", () => {
    const metrics = computeMetrics({ target: "abc", typed: "", elapsedMs: 0 });
    expect(metrics.grossWpm).toBe(0);
    expect(metrics.netWpm).toBe(0);
    expect(metrics.accuracy).toBe(0);
    expect(Number.isFinite(metrics.grossWpm)).toBe(true);
  });

  it("computes accuracy against typed characters", () => {
    expect(calculateAccuracy(9, 10)).toBe(90);
    expect(calculateAccuracy(0, 0)).toBe(0);
  });

  it("separates gross, standard and net WPM", () => {
    // 100 graphemes typed, 95 correct, 2 errors, 1 minute => gross 20, std 19, net 18
    const target = "a".repeat(95) + "b".repeat(5);
    const typed = "a".repeat(95) + "x".repeat(5);
    const metrics = computeMetrics({ target, typed, elapsedMs: 60000 });
    expect(metrics.grossWpm).toBe(20);
    expect(metrics.standardWpm).toBe(19);
    expect(metrics.netWpm).toBe(15);
    expect(metrics.accuracy).toBe(95);
    expect(metrics.incorrectChars).toBe(5);
  });

  it("tracks keystroke errors separately from final accuracy", () => {
    const metrics = computeMetrics({
      target: "hello",
      typed: "hello",
      elapsedMs: 30000,
      keystrokeErrors: 3,
      backspaceCount: 2,
    });
    expect(metrics.accuracy).toBe(100);
    expect(metrics.keystrokeErrors).toBe(3);
    expect(metrics.backspaceCount).toBe(2);
  });

  it("flags passage completion", () => {
    const metrics = computeMetrics({ target: "abc", typed: "abc", elapsedMs: 5000 });
    expect(metrics.isComplete).toBe(true);
    expect(metrics.completion).toBe(100);
  });

  it("reports the next expected grapheme", () => {
    expect(nextExpectedGrapheme("type", "ty")).toBe("p");
    expect(nextExpectedGrapheme("type", "type")).toBeNull();
  });

  it("normalizes passages", () => {
    expect(normalizePassage("  a   b \n c ")).toBe("a b c");
  });
});
