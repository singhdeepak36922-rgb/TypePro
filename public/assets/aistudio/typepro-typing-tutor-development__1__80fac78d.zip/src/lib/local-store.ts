"use client";

import type { KeyStat, ResultInput, StoredResult, UserSettings } from "./types";
import { DEFAULT_SETTINGS } from "./types";

const RESULTS_KEY = "typepro.guest.results.v1";
const SETTINGS_KEY = "typepro.guest.settings.v1";
const KEYSTATS_KEY = "typepro.guest.keystats.v1";

function canUseStorage(): boolean {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function readJson<T>(key: string, fallback: T): T {
  if (!canUseStorage()) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown): void {
  if (!canUseStorage()) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full / private mode – guest data simply will not persist
  }
}

export function createStoredResult(input: ResultInput): StoredResult {
  const id =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return {
    id,
    mode: input.mode,
    refId: input.refId ?? null,
    refTitle: input.refTitle ?? "",
    language: input.language,
    durationSeconds: input.durationSeconds,
    elapsedSeconds: input.elapsedSeconds,
    grossWpm: input.grossWpm,
    netWpm: input.netWpm,
    standardWpm: input.standardWpm,
    accuracy: input.accuracy,
    errors: input.errors,
    totalTyped: input.totalTyped,
    correctChars: input.correctChars,
    keystrokeErrors: input.keystrokeErrors,
    backspaceCount: input.backspaceCount,
    score: input.score ?? 0,
    createdAt: new Date().toISOString(),
  };
}

export function readGuestResults(): StoredResult[] {
  const results = readJson<StoredResult[]>(RESULTS_KEY, []);
  return Array.isArray(results) ? results : [];
}

export function addGuestResult(input: ResultInput): StoredResult {
  const result = createStoredResult(input);
  const results = [result, ...readGuestResults()].slice(0, 500);
  writeJson(RESULTS_KEY, results);
  return result;
}

export function replaceGuestResults(results: StoredResult[]): void {
  writeJson(RESULTS_KEY, results.slice(0, 500));
}

export function readGuestSettings(): UserSettings {
  return { ...DEFAULT_SETTINGS, ...readJson<Partial<UserSettings>>(SETTINGS_KEY, {}) };
}

export function writeGuestSettings(settings: UserSettings): void {
  writeJson(SETTINGS_KEY, settings);
}

export function readGuestKeyStats(): KeyStat[] {
  const stats = readJson<KeyStat[]>(KEYSTATS_KEY, []);
  return Array.isArray(stats) ? stats : [];
}

export function addGuestKeyErrors(errors: { expected: string; actual: string }[]): void {
  if (errors.length === 0) return;
  const stats = new Map(readGuestKeyStats().map((stat) => [stat.key, { ...stat }]));
  for (const error of errors) {
    const key = (error.expected || error.actual || "?").toLowerCase();
    const current = stats.get(key) ?? { key, correct: 0, incorrect: 0 };
    current.incorrect += 1;
    stats.set(key, current);
  }
  writeJson(KEYSTATS_KEY, Array.from(stats.values()).slice(0, 200));
}

export function clearGuestData(): void {
  if (!canUseStorage()) return;
  window.localStorage.removeItem(RESULTS_KEY);
  window.localStorage.removeItem(KEYSTATS_KEY);
}
