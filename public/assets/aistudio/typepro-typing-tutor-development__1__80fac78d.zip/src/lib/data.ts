import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  achievements as achievementsTable,
  courses as coursesTable,
  keyStats as keyStatsTable,
  lessonProgress as lessonProgressTable,
  lessons as lessonsTable,
  passages as passagesTable,
  typingResults,
  userSettings,
} from "@/db/schema";
import { COURSES, LESSONS, PASSAGES } from "./content";
import { summarize } from "./stats";
import { ACHIEVEMENTS } from "./achievements";
import { DEFAULT_SETTINGS, type Language, type LessonDTO, type PassageDTO, type ResultInput, type StoredResult, type UserSettings } from "./types";

let seedPromise: Promise<void> | null = null;

/** Idempotent content seeding. Safe to call on every request. */
export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = (async () => {
      const existing = await db.select({ count: sql<number>`count(*)::int` }).from(lessonsTable);
      if ((existing[0]?.count ?? 0) === 0) {
        for (const course of COURSES) {
          await db.insert(coursesTable).values(course).onConflictDoNothing();
        }
        const courseRows = await db.select().from(coursesTable);
        const bySlug = new Map(courseRows.map((row) => [row.slug, row.id]));
        for (const lesson of LESSONS) {
          const courseId = bySlug.get(lesson.courseSlug);
          if (!courseId) continue;
          await db
            .insert(lessonsTable)
            .values({
              courseId,
              slug: lesson.slug,
              title: lesson.title,
              level: lesson.level,
              language: lesson.language,
              instructions: lesson.instructions,
              content: lesson.content,
              focus: lesson.focus,
              estMinutes: lesson.estMinutes,
              sortOrder: lesson.sortOrder,
            })
            .onConflictDoNothing();
        }
      }

      const passageCount = await db.select({ count: sql<number>`count(*)::int` }).from(passagesTable);
      if ((passageCount[0]?.count ?? 0) === 0) {
        for (const passage of PASSAGES) {
          await db
            .insert(passagesTable)
            .values({
              ...passage,
              wordCount: passage.content.trim().split(/\s+/).length,
            })
            .onConflictDoNothing();
        }
      }
    })().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export async function getLessons(): Promise<LessonDTO[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      id: lessonsTable.id,
      slug: lessonsTable.slug,
      title: lessonsTable.title,
      level: lessonsTable.level,
      language: lessonsTable.language,
      instructions: lessonsTable.instructions,
      content: lessonsTable.content,
      focus: lessonsTable.focus,
      estMinutes: lessonsTable.estMinutes,
      sortOrder: lessonsTable.sortOrder,
      courseSlug: coursesTable.slug,
      courseTitle: coursesTable.title,
      courseOrder: coursesTable.sortOrder,
    })
    .from(lessonsTable)
    .innerJoin(coursesTable, eq(coursesTable.id, lessonsTable.courseId))
    .orderBy(asc(coursesTable.sortOrder), asc(lessonsTable.sortOrder));

  return rows.map((row) => ({
    id: row.id,
    slug: row.slug,
    title: row.title,
    level: row.level,
    language: row.language as Language,
    instructions: row.instructions,
    content: row.content,
    focus: row.focus,
    estMinutes: row.estMinutes,
    courseSlug: row.courseSlug,
    courseTitle: row.courseTitle,
  }));
}

export async function getLessonBySlug(slug: string): Promise<LessonDTO | null> {
  const all = await getLessons();
  return all.find((lesson) => lesson.slug === slug) ?? null;
}

export async function getPassages(): Promise<PassageDTO[]> {
  await ensureSeeded();
  const rows = await db.select().from(passagesTable).orderBy(asc(passagesTable.title));
  return rows.map((row) => ({
    id: row.id,
    slug: row.slug,
    title: row.title,
    language: row.language as Language,
    category: row.category,
    difficulty: row.difficulty,
    content: row.content,
    wordCount: row.wordCount,
  }));
}

export function toStoredResult(row: typeof typingResults.$inferSelect): StoredResult {
  return {
    id: row.id,
    mode: row.mode as StoredResult["mode"],
    refId: row.refId,
    refTitle: row.refTitle,
    language: row.language as Language,
    durationSeconds: row.durationSeconds,
    elapsedSeconds: row.elapsedSeconds,
    grossWpm: row.grossWpm,
    netWpm: row.netWpm,
    standardWpm: row.standardWpm,
    accuracy: row.accuracy,
    errors: row.errors,
    totalTyped: row.totalTyped,
    correctChars: row.correctChars,
    keystrokeErrors: row.keystrokeErrors,
    backspaceCount: row.backspaceCount,
    score: row.score,
    createdAt: row.createdAt.toISOString(),
  };
}

export async function getUserResults(userId: string, limit = 500): Promise<StoredResult[]> {
  const rows = await db
    .select()
    .from(typingResults)
    .where(eq(typingResults.userId, userId))
    .orderBy(desc(typingResults.createdAt))
    .limit(limit);
  return rows.map(toStoredResult);
}

export async function getUserKeyStats(userId: string) {
  const rows = await db.select().from(keyStatsTable).where(eq(keyStatsTable.userId, userId));
  return rows.map((row) => ({ key: row.key, correct: row.correct, incorrect: row.incorrect }));
}

export async function getOrCreateSettings(userId: string): Promise<UserSettings> {
  const rows = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  if (rows.length === 0) {
    await db.insert(userSettings).values({ userId }).onConflictDoNothing();
    return { ...DEFAULT_SETTINGS };
  }
  const row = rows[0];
  return {
    theme: row.theme as UserSettings["theme"],
    language: row.language as Language,
    soundEnabled: row.soundEnabled,
    cursorStyle: row.cursorStyle as UserSettings["cursorStyle"],
    keyboardLayout: row.keyboardLayout as UserSettings["keyboardLayout"],
    defaultDuration: row.defaultDuration,
    defaultCategory: row.defaultCategory,
    dailyGoalMinutes: row.dailyGoalMinutes,
    showKeyboard: row.showKeyboard,
    strictMode: row.strictMode,
  };
}

export async function saveSettings(userId: string, patch: Partial<UserSettings>): Promise<UserSettings> {
  await getOrCreateSettings(userId);
  await db
    .update(userSettings)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(userSettings.userId, userId));
  return getOrCreateSettings(userId);
}

export async function saveTypingResult(userId: string, input: ResultInput) {
  const [row] = await db
    .insert(typingResults)
    .values({
      userId,
      mode: input.mode,
      refId: input.refId ?? null,
      refTitle: input.refTitle ?? "",
      language: input.language,
      durationSeconds: input.durationSeconds,
      elapsedSeconds: input.elapsedSeconds,
      grossWpm: input.grossWpm,
      netWpm: input.netWpm,
      standardWpm: input.standardWpm,
      accuracy: input.accuracy,
      errors: input.errors,
      totalTyped: input.totalTyped,
      correctChars: input.correctChars,
      keystrokeErrors: input.keystrokeErrors,
      backspaceCount: input.backspaceCount,
      score: input.score ?? 0,
    })
    .returning();

  if (input.mode === "lesson" && input.refId) {
    await db
      .insert(lessonProgressTable)
      .values({
        userId,
        lessonSlug: input.refId,
        attempts: 1,
        bestWpm: input.netWpm,
        bestAccuracy: input.accuracy,
        completed: input.accuracy >= 90,
      })
      .onConflictDoUpdate({
        target: [lessonProgressTable.userId, lessonProgressTable.lessonSlug],
        set: {
          attempts: sql`${lessonProgressTable.attempts} + 1`,
          bestWpm: sql`greatest(${lessonProgressTable.bestWpm}, ${input.netWpm})`,
          bestAccuracy: sql`greatest(${lessonProgressTable.bestAccuracy}, ${input.accuracy})`,
          completed: sql`${lessonProgressTable.completed} or (${input.accuracy} >= 90)`,
          updatedAt: new Date(),
        },
      });
  }

  if (input.keyErrors && input.keyErrors.length > 0) {
    const grouped = new Map<string, number>();
    for (const error of input.keyErrors) {
      const key = (error.expected || error.actual || "?").toLowerCase();
      grouped.set(key, (grouped.get(key) ?? 0) + 1);
    }
    const entries = Array.from(grouped.entries()).slice(0, 40);
    if (entries.length > 0) {
      await db
        .insert(keyStatsTable)
        .values(entries.map(([key, incorrect]) => ({ userId, key, correct: 0, incorrect })))
        .onConflictDoUpdate({
          target: [keyStatsTable.userId, keyStatsTable.key],
          set: {
            incorrect: sql`${keyStatsTable.incorrect} + excluded.incorrect`,
            updatedAt: new Date(),
          },
        });
    }
  }

  return toStoredResult(row);
}

/** Unlocks any newly satisfied achievement rows and returns their keys. */
export async function syncAchievements(userId: string, results: StoredResult[], dailyGoalMinutes: number) {
  const summary = summarize(results, { dailyGoalMinutes });
  const earned = ACHIEVEMENTS.filter((achievement) => achievement.isUnlocked(summary)).map(
    (achievement) => achievement.key,
  );
  if (earned.length === 0) return [] as string[];

  const existing = await db
    .select({ key: achievementsTable.key })
    .from(achievementsTable)
    .where(eq(achievementsTable.userId, userId));
  const existingKeys = new Set(existing.map((row) => row.key));
  const newKeys = earned.filter((key) => !existingKeys.has(key));

  if (newKeys.length > 0) {
    await db
      .insert(achievementsTable)
      .values(newKeys.map((key) => ({ userId, key })))
      .onConflictDoNothing();
  }
  return newKeys;
}

export async function getUnlockedAchievementKeys(userId: string): Promise<string[]> {
  const rows = await db
    .select({ key: achievementsTable.key })
    .from(achievementsTable)
    .where(eq(achievementsTable.userId, userId));
  return rows.map((row) => row.key);
}

export async function getLessonProgressMap(userId: string) {
  const rows = await db
    .select()
    .from(lessonProgressTable)
    .where(eq(lessonProgressTable.userId, userId));
  return rows.map((row) => ({
    lessonSlug: row.lessonSlug,
    attempts: row.attempts,
    bestWpm: row.bestWpm,
    bestAccuracy: row.bestAccuracy,
    completed: row.completed,
    updatedAt: row.updatedAt.toISOString(),
  }));
}
