export type Language = "en" | "hi";
export type ThemeMode = "dark" | "light" | "system";
export type TypingMode = "test" | "practice" | "lesson" | "game" | "hindi" | "drill";
export type Difficulty = "beginner" | "intermediate" | "advanced" | "competitive";

export const DURATIONS = [60, 120, 180, 300, 600, 900] as const;

export const CATEGORIES = [
  { value: "beginner", label: "Beginner", description: "Short, simple sentences" },
  { value: "intermediate", label: "Intermediate", description: "Everyday vocabulary" },
  { value: "advanced", label: "Advanced", description: "Complex wording" },
  { value: "general-english", label: "General English", description: "Modern paragraphs" },
  { value: "general-hindi", label: "General Hindi", description: "Devanagari passages" },
  { value: "competitive", label: "Competitive Exam", description: "SSC / Railway / Banking" },
] as const;

export interface StoredResult {
  id: string;
  mode: TypingMode;
  refId: string | null;
  refTitle: string;
  language: Language;
  durationSeconds: number;
  elapsedSeconds: number;
  grossWpm: number;
  netWpm: number;
  standardWpm: number;
  accuracy: number;
  errors: number;
  totalTyped: number;
  correctChars: number;
  keystrokeErrors: number;
  backspaceCount: number;
  score: number;
  createdAt: string;
}

export interface ResultInput {
  mode: TypingMode;
  refId?: string | null;
  refTitle?: string;
  language: Language;
  durationSeconds: number;
  elapsedSeconds: number;
  grossWpm: number;
  netWpm: number;
  standardWpm: number;
  accuracy: number;
  errors: number;
  totalTyped: number;
  correctChars: number;
  keystrokeErrors: number;
  backspaceCount: number;
  score?: number;
  /** Expected->actual mismatches used for weak key analysis. */
  keyErrors?: { expected: string; actual: string }[];
}

export interface KeyStat {
  key: string;
  correct: number;
  incorrect: number;
}

export interface UserSettings {
  theme: ThemeMode;
  language: Language;
  soundEnabled: boolean;
  cursorStyle: "line" | "block" | "underline";
  keyboardLayout: "qwerty" | "inscript";
  defaultDuration: number;
  defaultCategory: string;
  dailyGoalMinutes: number;
  showKeyboard: boolean;
  strictMode: boolean;
}

export const DEFAULT_SETTINGS: UserSettings = {
  theme: "dark",
  language: "en",
  soundEnabled: true,
  cursorStyle: "line",
  keyboardLayout: "qwerty",
  defaultDuration: 60,
  defaultCategory: "beginner",
  dailyGoalMinutes: 15,
  showKeyboard: true,
  strictMode: false,
};

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  createdAt: string;
}

export interface LessonDTO {
  id: string;
  slug: string;
  title: string;
  level: string;
  language: Language;
  instructions: string;
  content: string;
  focus: string;
  estMinutes: number;
  courseSlug: string;
  courseTitle: string;
}

export interface PassageDTO {
  id: string;
  slug: string;
  title: string;
  language: Language;
  category: string;
  difficulty: string;
  content: string;
  wordCount: number;
}

export interface GameRecord {
  game: string;
  score: number;
  best: number;
}
