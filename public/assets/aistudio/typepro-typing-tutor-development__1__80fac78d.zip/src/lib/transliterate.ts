/**
 * Roman -> Devanagari phonetic transliteration.
 *
 * This is a real transliteration implementation (not a browser key event trick):
 * letters typed in the roman buffer are converted to Unicode Devanagari clusters
 * and only committed graphemes are scored. Incomplete composition text is never
 * counted toward accuracy or WPM.
 *
 * Supported: consonants (with aspirates), independent vowels, matras, virama
 * for conjuncts, anusvara/visarga, common conjuncts (ksh, tr, gya, shr) and
 * Devanagari digits. Unknown letters / spaces / punctuation pass through.
 */

const CONSONANTS: Record<string, string> = {
  ksh: "क्ष",
  gya: "ज्ञ",
  shr: "श्र",
  chh: "छ",
  kh: "ख",
  gh: "घ",
  ch: "च",
  jh: "झ",
  th: "थ",
  dh: "ध",
  ph: "फ",
  bh: "भ",
  sh: "श",
  ss: "ष",
  tr: "त्र",
  ng: "ङ",
  ny: "ञ",
  k: "क",
  g: "ग",
  j: "ज",
  T: "ट",
  Th: "ठ",
  D: "ड",
  Dh: "ढ",
  N: "ण",
  t: "त",
  d: "द",
  n: "न",
  p: "प",
  f: "फ",
  b: "ब",
  m: "म",
  y: "य",
  r: "र",
  l: "ल",
  v: "व",
  w: "व",
  s: "स",
  h: "ह",
  L: "ळ",
  q: "क़",
  x: "क्ष",
  z: "ज़",
};

const VOWELS: Record<string, string> = {
  a: "अ",
  aa: "आ",
  A: "आ",
  i: "इ",
  ee: "ई",
  I: "ई",
  ii: "ई",
  u: "उ",
  oo: "ऊ",
  U: "ऊ",
  uu: "ऊ",
  e: "ए",
  ai: "ऐ",
  o: "ओ",
  au: "औ",
  ri: "ऋ",
};

const MATRAS: Record<string, string> = {
  a: "",
  aa: "ा",
  A: "ा",
  i: "ि",
  ee: "ी",
  I: "ी",
  ii: "ी",
  u: "ु",
  oo: "ू",
  U: "ू",
  uu: "ू",
  e: "े",
  ai: "ै",
  o: "ो",
  au: "ौ",
  ri: "ृ",
};

const SIGNS: Record<string, string> = {
  M: "ं",
  H: "ः",
  n: "न",
  "~": "ँ",
  OM: "ॐ",
};

const DIGITS = ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"];

const TOKEN_ORDER = [
  "ksh",
  "gya",
  "shr",
  "chh",
  "kh",
  "gh",
  "ch",
  "jh",
  "th",
  "dh",
  "ph",
  "bh",
  "sh",
  "ss",
  "tr",
  "ng",
  "ny",
  "aa",
  "ee",
  "ii",
  "oo",
  "uu",
  "ai",
  "au",
  "ri",
  "Th",
  "Dh",
  "T",
  "D",
  "N",
  "L",
  "k",
  "g",
  "j",
  "t",
  "d",
  "n",
  "p",
  "f",
  "b",
  "m",
  "y",
  "r",
  "l",
  "v",
  "w",
  "s",
  "h",
  "q",
  "x",
  "z",
  "a",
  "A",
  "i",
  "I",
  "u",
  "U",
  "e",
  "o",
  "M",
  "H",
];

function isConsonantToken(token: string): boolean {
  return Object.prototype.hasOwnProperty.call(CONSONANTS, token);
}

function isVowelToken(token: string): boolean {
  return Object.prototype.hasOwnProperty.call(VOWELS, token);
}

function tokenize(roman: string): string[] {
  const tokens: string[] = [];
  let i = 0;
  while (i < roman.length) {
    let matched = "";
    for (const candidate of TOKEN_ORDER) {
      if (roman.startsWith(candidate, i)) {
        matched = candidate;
        break;
      }
    }
    if (matched) {
      tokens.push(matched);
      i += matched.length;
    } else {
      tokens.push(roman[i]);
      i += 1;
    }
  }
  return tokens;
}

/** Converts a complete roman string to Devanagari. */
export function transliterate(roman: string): string {
  if (!roman) return "";
  const tokens = tokenize(roman);
  let output = "";
  let pendingConsonant = false;

  for (const token of tokens) {
    if (token === "OM") {
      output += SIGNS.OM;
      pendingConsonant = false;
      continue;
    }
    if (isConsonantToken(token)) {
      if (pendingConsonant) output += "\u094d"; // virama forms a conjunct
      output += CONSONANTS[token];
      pendingConsonant = true;
      continue;
    }
    if (isVowelToken(token)) {
      if (pendingConsonant) {
        output += MATRAS[token] ?? "";
        if (token === "a") output += ""; // inherent vowel, nothing to add
        pendingConsonant = false;
      } else {
        output += VOWELS[token];
      }
      continue;
    }
    if (token === "M" || token === "H" || token === "~") {
      output += SIGNS[token];
      pendingConsonant = false;
      continue;
    }
    if (/^[0-9]$/.test(token)) {
      output += DIGITS[Number(token)];
      pendingConsonant = false;
      continue;
    }
    // Anything else (spaces, punctuation, unknown latin letters) passes through.
    output += token;
    pendingConsonant = false;
  }

  return output;
}

/**
 * Stateful phonetic buffer used by the Hindi phonetic practice mode.
 * Space commits the pending word; backspace removes the last roman char first.
 */
export class PhoneticBuffer {
  private roman = "";
  private committed = "";

  get romanBuffer(): string {
    return this.roman;
  }

  get committedText(): string {
    return this.committed;
  }

  get devanagariPreview(): string {
    return this.roman ? transliterate(this.roman) : "";
  }

  get fullText(): string {
    return this.committed + this.devanagariPreview;
  }

  type(char: string): void {
    if (char === " ") {
      this.committed += `${transliterate(this.roman)} `;
      this.roman = "";
      return;
    }
    if (char === ".") {
      this.committed += transliterate(this.roman);
      this.committed += "।";
      this.roman = "";
      return;
    }
    this.roman += char;
  }

  backspace(): void {
    if (this.roman.length > 0) {
      this.roman = this.roman.slice(0, -1);
      return;
    }
    this.committed = Array.from(this.committed).slice(0, -1).join("");
  }

  reset(): void {
    this.roman = "";
    this.committed = "";
  }
}
