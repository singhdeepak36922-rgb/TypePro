/**
 * TypePro typing engine.
 *
 * This module is intentionally free of React/DOM dependencies so it can be
 * unit tested and reused by a future Tauri desktop shell.
 *
 * Scoring rules (documented for users in the UI as well):
 * - All text is segmented into grapheme clusters (Unicode aware). A Hindi
 *   cluster such as "क्" + "ष" counts as one unit, not two UTF-16 characters.
 * - Standard WPM  = correct graphemes / 5 / elapsed minutes.
 * - Gross WPM     = total typed graphemes / 5 / elapsed minutes.
 * - Net WPM       = gross WPM - uncorrected errors per minute (never below 0).
 * - Accuracy      = correct graphemes at their final position / total typed
 *                   graphemes * 100. Because it is measured on the final text,
 *                   a mistake that is backspaced and corrected does not reduce
 *                   accuracy, but it is still counted in `keystrokeErrors`,
 *                   which keeps an honest record of raw typing quality.
 * - Backspace never adds characters; it removes the last typed grapheme and
 *   increments `backspaceCount`.
 * - Elapsed time is floored at 1 second so a very fast first character cannot
 *   produce Infinity.
 */

export interface KeyError {
  index: number;
  expected: string;
  actual: string;
}

export interface TypingMetrics {
  elapsedMs: number;
  elapsedMinutes: number;
  totalTyped: number;
  targetLength: number;
  correctChars: number;
  incorrectChars: number;
  accuracy: number;
  grossWpm: number;
  netWpm: number;
  standardWpm: number;
  keystrokeErrors: number;
  backspaceCount: number;
  completion: number;
  isComplete: boolean;
  keyErrors: KeyError[];
}

export interface MetricInput {
  target: string;
  typed: string;
  elapsedMs: number;
  keystrokeErrors?: number;
  backspaceCount?: number;
}

const COMBINING = /[\u0300-\u036f\u0483-\u0489\u0591-\u05bd\u0610-\u061a\u064b-\u065f\u0900-\u0903\u093a-\u094f\u0951-\u0957\u0962-\u0963\u1ab0-\u1aff\u1dc0-\u1dff\u20d0-\u20ff\ufe00-\ufe0f\ufe20-\ufe2f]/u;

/**
 * Splits text into grapheme clusters. Uses Intl.Segmenter when available and
 * falls back to a combining-mark aware splitter (works in every runtime).
 */
export function toGraphemes(text: string): string[] {
  if (!text) return [];
  const Segmenter = (
    typeof Intl !== "undefined" ? (Intl as unknown as { Segmenter?: unknown }).Segmenter : undefined
  ) as
    | (new (locale?: string, options?: { granularity: "grapheme" }) => {
        segment: (input: string) => Iterable<{ segment: string }>;
      })
    | undefined;

  if (typeof Segmenter === "function") {
    try {
      const segmenter = new Segmenter(undefined, { granularity: "grapheme" });
      return Array.from(segmenter.segment(text), (entry) => entry.segment);
    } catch {
      // fall through to the manual implementation
    }
  }

  const out: string[] = [];
  for (const char of Array.from(text)) {
    const isMark = COMBINING.test(char) || char === "\u200d" || char === "\u200c";
    if (isMark && out.length > 0) {
      out[out.length - 1] += char;
    } else {
      out.push(char);
    }
  }
  return out;
}

export function graphemeLength(text: string): number {
  return toGraphemes(text).length;
}

export function safeMinutes(elapsedMs: number): number {
  const ms = Number.isFinite(elapsedMs) ? Math.max(elapsedMs, 1000) : 1000;
  return ms / 60000;
}

export function calculateWpm(correctChars: number, elapsedMs: number): number {
  if (correctChars <= 0) return 0;
  return round(correctChars / 5 / safeMinutes(elapsedMs));
}

export function calculateAccuracy(correctChars: number, totalTyped: number): number {
  if (totalTyped <= 0) return 0;
  return round((correctChars / totalTyped) * 100);
}

export function round(value: number, digits = 1): number {
  if (!Number.isFinite(value)) return 0;
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

/** Final-text comparison of typed graphemes against the target passage. */
export function compareGraphemes(target: string, typed: string): {
  correctChars: number;
  incorrectChars: number;
  keyErrors: KeyError[];
  isComplete: boolean;
  completion: number;
  targetLength: number;
  typedLength: number;
} {
  const targetG = toGraphemes(target);
  const typedG = toGraphemes(typed);
  let correctChars = 0;
  const keyErrors: KeyError[] = [];

  for (let i = 0; i < typedG.length; i += 1) {
    const expected = targetG[i] ?? "";
    if (expected === typedG[i]) {
      correctChars += 1;
    } else {
      keyErrors.push({ index: i, expected, actual: typedG[i] });
    }
  }

  return {
    correctChars,
    incorrectChars: typedG.length - correctChars,
    keyErrors,
    isComplete: targetG.length > 0 && typedG.length >= targetG.length,
    completion: targetG.length === 0 ? 0 : Math.min(1, typedG.length / targetG.length),
    targetLength: targetG.length,
    typedLength: typedG.length,
  };
}

export function computeMetrics(input: MetricInput): TypingMetrics {
  const elapsedMs = Math.max(0, input.elapsedMs);
  const minutes = safeMinutes(elapsedMs);
  const comparison = compareGraphemes(input.target, input.typed);
  const totalTyped = comparison.typedLength;
  const correctChars = comparison.correctChars;
  const incorrectChars = comparison.incorrectChars;

  const grossWpm = round(totalTyped / 5 / minutes);
  const standardWpm = round(correctChars / 5 / minutes);
  const netWpm = round(Math.max(0, grossWpm - incorrectChars / minutes));

  return {
    elapsedMs,
    elapsedMinutes: minutes,
    totalTyped,
    targetLength: comparison.targetLength,
    correctChars,
    incorrectChars,
    accuracy: calculateAccuracy(correctChars, totalTyped),
    grossWpm,
    netWpm,
    standardWpm,
    keystrokeErrors: input.keystrokeErrors ?? 0,
    backspaceCount: input.backspaceCount ?? 0,
    completion: round(comparison.completion * 100),
    isComplete: comparison.isComplete,
    keyErrors: comparison.keyErrors,
  };
}

/**
 * Returns the next required grapheme (used by the virtual keyboard).
 */
export function nextExpectedGrapheme(target: string, typed: string): string | null {
  const targetG = toGraphemes(target);
  const typedG = toGraphemes(typed);
  return targetG[typedG.length] ?? null;
}

/** Normalizes target text so repeated whitespace does not inflate difficulty. */
export function normalizePassage(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}
