/**
 * Keyboard layouts and finger colouring data.
 * English QWERTY + Hindi InScript (Devanagari Unicode).
 */

export type Finger =
  | "left-pinky"
  | "left-ring"
  | "left-middle"
  | "left-index"
  | "right-index"
  | "right-middle"
  | "right-ring"
  | "right-pinky"
  | "thumb";

export interface KeyDef {
  /** Character produced without shift (lower case / InScript base). */
  base: string;
  /** Character produced with shift. */
  shift?: string;
  /** Physical keyboard code, e.g. KeyA. */
  code: string;
  finger: Finger;
  width?: number;
  label?: string;
}

export const FINGER_COLORS: Record<Finger, string> = {
  "left-pinky": "#f472b6",
  "left-ring": "#a78bfa",
  "left-middle": "#60a5fa",
  "left-index": "#22d3ee",
  "right-index": "#34d399",
  "right-middle": "#fbbf24",
  "right-ring": "#fb923c",
  "right-pinky": "#f87171",
  thumb: "#94a3b8",
};

export const FINGER_LABELS: Record<Finger, string> = {
  "left-pinky": "Left pinky",
  "left-ring": "Left ring",
  "left-middle": "Left middle",
  "left-index": "Left index",
  "right-index": "Right index",
  "right-middle": "Right middle",
  "right-ring": "Right ring",
  "right-pinky": "Right pinky",
  thumb: "Thumb",
};

const f = (finger: Finger) => finger;

export const EN_ROWS: KeyDef[][] = [
  [
    { base: "`", shift: "~", code: "Backquote", finger: f("left-pinky") },
    { base: "1", shift: "!", code: "Digit1", finger: f("left-pinky") },
    { base: "2", shift: "@", code: "Digit2", finger: f("left-ring") },
    { base: "3", shift: "#", code: "Digit3", finger: f("left-middle") },
    { base: "4", shift: "$", code: "Digit4", finger: f("left-index") },
    { base: "5", shift: "%", code: "Digit5", finger: f("left-index") },
    { base: "6", shift: "^", code: "Digit6", finger: f("right-index") },
    { base: "7", shift: "&", code: "Digit7", finger: f("right-index") },
    { base: "8", shift: "*", code: "Digit8", finger: f("right-middle") },
    { base: "9", shift: "(", code: "Digit9", finger: f("right-ring") },
    { base: "0", shift: ")", code: "Digit0", finger: f("right-pinky") },
    { base: "-", shift: "_", code: "Minus", finger: f("right-pinky") },
    { base: "=", shift: "+", code: "Equal", finger: f("right-pinky") },
    { base: "⌫", code: "Backspace", finger: f("right-pinky"), width: 2 },
  ],
  [
    { base: "Tab", code: "Tab", finger: f("left-pinky"), width: 1.5, label: "Tab" },
    { base: "q", shift: "Q", code: "KeyQ", finger: f("left-pinky") },
    { base: "w", shift: "W", code: "KeyW", finger: f("left-ring") },
    { base: "e", shift: "E", code: "KeyE", finger: f("left-middle") },
    { base: "r", shift: "R", code: "KeyR", finger: f("left-index") },
    { base: "t", shift: "T", code: "KeyT", finger: f("left-index") },
    { base: "y", shift: "Y", code: "KeyY", finger: f("right-index") },
    { base: "u", shift: "U", code: "KeyU", finger: f("right-index") },
    { base: "i", shift: "I", code: "KeyI", finger: f("right-middle") },
    { base: "o", shift: "O", code: "KeyO", finger: f("right-ring") },
    { base: "p", shift: "P", code: "KeyP", finger: f("right-pinky") },
    { base: "[", shift: "{", code: "BracketLeft", finger: f("right-pinky") },
    { base: "]", shift: "}", code: "BracketRight", finger: f("right-pinky") },
    { base: "\\", shift: "|", code: "Backslash", finger: f("right-pinky"), width: 1.5 },
  ],
  [
    { base: "Caps", code: "CapsLock", finger: f("left-pinky"), width: 1.8, label: "Caps" },
    { base: "a", shift: "A", code: "KeyA", finger: f("left-pinky") },
    { base: "s", shift: "S", code: "KeyS", finger: f("left-ring") },
    { base: "d", shift: "D", code: "KeyD", finger: f("left-middle") },
    { base: "f", shift: "F", code: "KeyF", finger: f("left-index") },
    { base: "g", shift: "G", code: "KeyG", finger: f("left-index") },
    { base: "h", shift: "H", code: "KeyH", finger: f("right-index") },
    { base: "j", shift: "J", code: "KeyJ", finger: f("right-index") },
    { base: "k", shift: "K", code: "KeyK", finger: f("right-middle") },
    { base: "l", shift: "L", code: "KeyL", finger: f("right-ring") },
    { base: ";", shift: ":", code: "Semicolon", finger: f("right-pinky") },
    { base: "'", shift: '"', code: "Quote", finger: f("right-pinky") },
    { base: "Enter", code: "Enter", finger: f("right-pinky"), width: 2.2, label: "Enter" },
  ],
  [
    { base: "Shift", code: "ShiftLeft", finger: f("left-pinky"), width: 2.4, label: "Shift" },
    { base: "z", shift: "Z", code: "KeyZ", finger: f("left-pinky") },
    { base: "x", shift: "X", code: "KeyX", finger: f("left-ring") },
    { base: "c", shift: "C", code: "KeyC", finger: f("left-middle") },
    { base: "v", shift: "V", code: "KeyV", finger: f("left-index") },
    { base: "b", shift: "B", code: "KeyB", finger: f("left-index") },
    { base: "n", shift: "N", code: "KeyN", finger: f("right-index") },
    { base: "m", shift: "M", code: "KeyM", finger: f("right-index") },
    { base: ",", shift: "<", code: "Comma", finger: f("right-middle") },
    { base: ".", shift: ">", code: "Period", finger: f("right-ring") },
    { base: "/", shift: "?", code: "Slash", finger: f("right-pinky") },
    { base: "Shift", code: "ShiftRight", finger: f("right-pinky"), width: 2.6, label: "Shift" },
  ],
  [
    { base: "Ctrl", code: "ControlLeft", finger: f("left-pinky"), width: 1.6, label: "Ctrl" },
    { base: "Alt", code: "AltLeft", finger: f("thumb"), width: 1.4, label: "Alt" },
    { base: " ", code: "Space", finger: f("thumb"), width: 6, label: "space" },
    { base: "Alt", code: "AltRight", finger: f("thumb"), width: 1.4, label: "Alt" },
    { base: "Ctrl", code: "ControlRight", finger: f("right-pinky"), width: 1.6, label: "Ctrl" },
  ],
];

/**
 * Hindi InScript mapping for the 26 letter keys + punctuation.
 * Static one-to-one mapping used for the on-screen InScript keyboard and the
 * InScript practice mode. A full InScript driver also handles halant/reph
 * state; we keep the mapping explicit and let the user build conjuncts with
 * the halant key (्) exactly as they would on a real InScript keyboard.
 */
export const HINDI_INSSCRIPT: Record<string, { shift: string; base: string; finger: Finger }> = {
  KeyQ: { base: "ौ", shift: "औ", finger: "left-pinky" },
  KeyW: { base: "ै", shift: "ऐ", finger: "left-ring" },
  KeyE: { base: "ा", shift: "आ", finger: "left-middle" },
  KeyR: { base: "ी", shift: "ई", finger: "left-index" },
  KeyT: { base: "ू", shift: "ऊ", finger: "left-index" },
  KeyY: { base: "ब", shift: "भ", finger: "right-index" },
  KeyU: { base: "ह", shift: "ङ", finger: "right-index" },
  KeyI: { base: "ग", shift: "घ", finger: "right-middle" },
  KeyO: { base: "द", shift: "ध", finger: "right-ring" },
  KeyP: { base: "ज", shift: "झ", finger: "right-pinky" },
  BracketLeft: { base: "ड", shift: "ढ", finger: "right-pinky" },
  BracketRight: { base: "़", shift: "ञ", finger: "right-pinky" },
  KeyA: { base: "ो", shift: "ओ", finger: "left-pinky" },
  KeyS: { base: "े", shift: "ए", finger: "left-ring" },
  KeyD: { base: "्", shift: "अ", finger: "left-middle" },
  KeyF: { base: "ि", shift: "इ", finger: "left-index" },
  KeyG: { base: "ु", shift: "उ", finger: "left-index" },
  KeyH: { base: "प", shift: "फ", finger: "right-index" },
  KeyJ: { base: "र", shift: "ऱ", finger: "right-index" },
  KeyK: { base: "क", shift: "ख", finger: "right-middle" },
  KeyL: { base: "त", shift: "थ", finger: "right-ring" },
  Semicolon: { base: "च", shift: "छ", finger: "right-pinky" },
  Quote: { base: "ट", shift: "ठ", finger: "right-pinky" },
  KeyZ: { base: "ॆ", shift: "ॐ", finger: "left-pinky" },
  KeyX: { base: "ं", shift: "ँ", finger: "left-ring" },
  KeyC: { base: "म", shift: "ण", finger: "left-middle" },
  KeyV: { base: "न", shift: "ऩ", finger: "left-index" },
  KeyB: { base: "व", shift: "ळ", finger: "left-index" },
  KeyN: { base: "ल", shift: "श", finger: "right-index" },
  KeyM: { base: "स", shift: "ष", finger: "right-index" },
  Comma: { base: ",", shift: "ष", finger: "right-middle" },
  Period: { base: ".", shift: "।", finger: "right-ring" },
  Slash: { base: "य", shift: "्य", finger: "right-pinky" },
  Space: { base: " ", shift: " ", finger: "thumb" },
  Backspace: { base: "⌫", shift: "⌫", finger: "right-pinky" },
};

export interface HindiKeyRow {
  code: string;
  base: string;
  shift: string;
  finger: Finger;
  width?: number;
}

export const HINDI_ROWS: HindiKeyRow[][] = [
  [
    { code: "Digit1", base: "१", shift: "!", finger: "left-pinky" },
    { code: "Digit2", base: "२", shift: "@", finger: "left-ring" },
    { code: "Digit3", base: "३", shift: "#", finger: "left-middle" },
    { code: "Digit4", base: "४", shift: "$", finger: "left-index" },
    { code: "Digit5", base: "५", shift: "%", finger: "left-index" },
    { code: "Digit6", base: "६", shift: "^", finger: "right-index" },
    { code: "Digit7", base: "७", shift: "&", finger: "right-index" },
    { code: "Digit8", base: "८", shift: "*", finger: "right-middle" },
    { code: "Digit9", base: "९", shift: "(", finger: "right-ring" },
    { code: "Digit0", base: "०", shift: ")", finger: "right-pinky" },
  ],
  [
    { code: "KeyQ", base: "ौ", shift: "औ", finger: "left-pinky" },
    { code: "KeyW", base: "ै", shift: "ऐ", finger: "left-ring" },
    { code: "KeyE", base: "ा", shift: "आ", finger: "left-middle" },
    { code: "KeyR", base: "ी", shift: "ई", finger: "left-index" },
    { code: "KeyT", base: "ू", shift: "ऊ", finger: "left-index" },
    { code: "KeyY", base: "ब", shift: "भ", finger: "right-index" },
    { code: "KeyU", base: "ह", shift: "ङ", finger: "right-index" },
    { code: "KeyI", base: "ग", shift: "घ", finger: "right-middle" },
    { code: "KeyO", base: "द", shift: "ध", finger: "right-ring" },
    { code: "KeyP", base: "ज", shift: "झ", finger: "right-pinky" },
    { code: "BracketLeft", base: "ड", shift: "ढ", finger: "right-pinky" },
    { code: "BracketRight", base: "़", shift: "ञ", finger: "right-pinky" },
  ],
  [
    { code: "KeyA", base: "ो", shift: "ओ", finger: "left-pinky" },
    { code: "KeyS", base: "े", shift: "ए", finger: "left-ring" },
    { code: "KeyD", base: "्", shift: "अ", finger: "left-middle" },
    { code: "KeyF", base: "ि", shift: "इ", finger: "left-index" },
    { code: "KeyG", base: "ु", shift: "उ", finger: "left-index" },
    { code: "KeyH", base: "प", shift: "फ", finger: "right-index" },
    { code: "KeyJ", base: "र", shift: "ऱ", finger: "right-index" },
    { code: "KeyK", base: "क", shift: "ख", finger: "right-middle" },
    { code: "KeyL", base: "त", shift: "थ", finger: "right-ring" },
    { code: "Semicolon", base: "च", shift: "छ", finger: "right-pinky" },
    { code: "Quote", base: "ट", shift: "ठ", finger: "right-pinky" },
  ],
  [
    { code: "KeyZ", base: "ॆ", shift: "ॐ", finger: "left-pinky" },
    { code: "KeyX", base: "ं", shift: "ँ", finger: "left-ring" },
    { code: "KeyC", base: "म", shift: "ण", finger: "left-middle" },
    { code: "KeyV", base: "न", shift: "ऩ", finger: "left-index" },
    { code: "KeyB", base: "व", shift: "ळ", finger: "left-index" },
    { code: "KeyN", base: "ल", shift: "श", finger: "right-index" },
    { code: "KeyM", base: "स", shift: "ष", finger: "right-index" },
    { code: "Comma", base: ",", shift: "ष", finger: "right-middle" },
    { code: "Period", base: ".", shift: "।", finger: "right-ring" },
    { code: "Slash", base: "य", shift: "्य", finger: "right-pinky" },
  ],
  [
    { code: "Space", base: " ", shift: " ", finger: "thumb", width: 8 },
    { code: "Backspace", base: "⌫", shift: "⌫", finger: "right-pinky", width: 2 },
  ],
];

export function findEnglishKey(char: string): KeyDef | null {
  for (const row of EN_ROWS) {
    for (const key of row) {
      if (key.base === char || key.shift === char) return key;
    }
  }
  return null;
}

export function findHindiKey(char: string): HindiKeyRow | null {
  for (const row of HINDI_ROWS) {
    for (const key of row) {
      if (key.base === char || key.shift === char) return key;
    }
  }
  return null;
}

export const HOME_ROW = ["a", "s", "d", "f", "j", "k", "l", ";"];
