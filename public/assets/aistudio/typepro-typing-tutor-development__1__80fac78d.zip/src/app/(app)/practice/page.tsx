import { getPassages } from "@/lib/data";
import { FreePractice } from "@/components/free-practice";

export const dynamic = "force-dynamic";

export default async function PracticePage() {
  const passages = await getPassages();
  return <FreePractice passages={passages} />;
}
