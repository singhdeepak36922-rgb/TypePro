import { getPassages } from "@/lib/data";
import { GamesHub } from "@/components/games-hub";

export const dynamic = "force-dynamic";

export default async function GamesPage() {
  const passages = await getPassages();
  return <GamesHub passages={passages} />;
}
