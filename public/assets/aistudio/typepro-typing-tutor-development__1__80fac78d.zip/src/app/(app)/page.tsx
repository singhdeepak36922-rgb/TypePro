import { getLessons } from "@/lib/data";
import { DashboardView } from "@/components/dashboard-view";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const lessons = await getLessons();
  return <DashboardView lessons={lessons} />;
}
