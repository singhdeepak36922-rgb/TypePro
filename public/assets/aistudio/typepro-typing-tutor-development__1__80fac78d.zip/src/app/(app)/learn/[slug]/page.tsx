import { notFound } from "next/navigation";
import { getLessonBySlug, getLessons } from "@/lib/data";
import { LessonRunner } from "@/components/lesson-runner";

export const dynamic = "force-dynamic";

export default async function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [lesson, lessons] = await Promise.all([getLessonBySlug(slug), getLessons()]);
  if (!lesson) notFound();

  const index = lessons.findIndex((item) => item.slug === lesson.slug);
  const next = lessons[index + 1] ?? null;
  const previous = lessons[index - 1] ?? null;

  return <LessonRunner lesson={lesson} nextLesson={next} previousLesson={previous} total={lessons.length} position={index + 1} />;
}
