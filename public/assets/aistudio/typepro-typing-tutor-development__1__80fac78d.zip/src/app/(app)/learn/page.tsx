import { getLessons } from "@/lib/data";
import { LearnView } from "@/components/learn-view";

export const dynamic = "force-dynamic";

export default async function LearnPage() {
  const lessons = await getLessons();
  return <LearnView lessons={lessons} />;
}
