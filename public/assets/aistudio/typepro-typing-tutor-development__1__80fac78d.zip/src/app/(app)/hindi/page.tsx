import { getPassages } from "@/lib/data";
import { HindiView } from "@/components/hindi-view";

export const dynamic = "force-dynamic";

export default async function HindiPage() {
  const passages = await getPassages();
  return <HindiView passages={passages} />;
}
