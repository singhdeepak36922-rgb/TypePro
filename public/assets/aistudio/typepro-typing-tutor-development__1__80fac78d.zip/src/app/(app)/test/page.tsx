import { getPassages } from "@/lib/data";
import { TestRunner } from "@/components/test-runner";

export const dynamic = "force-dynamic";

export default async function TestPage() {
  const passages = await getPassages();
  return <TestRunner passages={passages} />;
}
