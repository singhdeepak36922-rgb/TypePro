import { KeyboardStudio } from "@/components/keyboard-studio";

export default function KeyboardPage() {
  return <KeyboardStudio />;
}
