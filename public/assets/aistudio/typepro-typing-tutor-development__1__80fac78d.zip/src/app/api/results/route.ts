import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import {
  getOrCreateSettings,
  getUserKeyStats,
  getUserResults,
  saveTypingResult,
  syncAchievements,
} from "@/lib/data";
import { summarize } from "@/lib/stats";
import type { ResultInput, TypingMode } from "@/lib/types";

const MODES: TypingMode[] = ["test", "practice", "lesson", "game", "hindi", "drill"];

function num(value: unknown, fallback = 0): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function sanitize(body: Record<string, unknown>): ResultInput | null {
  const mode = body.mode as TypingMode;
  if (!MODES.includes(mode)) return null;
  const language = body.language === "hi" ? "hi" : "en";
  return {
    mode,
    refId: typeof body.refId === "string" ? body.refId.slice(0, 120) : null,
    refTitle: typeof body.refTitle === "string" ? body.refTitle.slice(0, 160) : "",
    language,
    durationSeconds: Math.max(0, Math.min(3600, Math.round(num(body.durationSeconds)))),
    elapsedSeconds: Math.max(0, Math.min(3600, Math.round(num(body.elapsedSeconds)))),
    grossWpm: Math.max(0, Math.min(500, num(body.grossWpm))),
    netWpm: Math.max(0, Math.min(500, num(body.netWpm))),
    standardWpm: Math.max(0, Math.min(500, num(body.standardWpm))),
    accuracy: Math.max(0, Math.min(100, num(body.accuracy))),
    errors: Math.max(0, Math.round(num(body.errors))),
    totalTyped: Math.max(0, Math.round(num(body.totalTyped))),
    correctChars: Math.max(0, Math.round(num(body.correctChars))),
    keystrokeErrors: Math.max(0, Math.round(num(body.keystrokeErrors))),
    backspaceCount: Math.max(0, Math.round(num(body.backspaceCount))),
    score: Math.max(0, Math.round(num(body.score))),
    keyErrors: Array.isArray(body.keyErrors)
      ? (body.keyErrors as { expected?: string; actual?: string }[])
          .slice(0, 200)
          .map((item) => ({ expected: String(item.expected ?? ""), actual: String(item.actual ?? "") }))
      : [],
  };
}

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    const [results, keyStats, settings] = await Promise.all([
      getUserResults(user.id),
      getUserKeyStats(user.id),
      getOrCreateSettings(user.id),
    ]);
    const summary = summarize(results, {
      keyStats,
      dailyGoalMinutes: settings.dailyGoalMinutes,
    });
    return NextResponse.json({ results, keyStats, summary });
  } catch (error) {
    console.error("results fetch failed", error);
    return NextResponse.json({ error: "Unable to load your results." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const raw = (await request.json()) as Record<string, unknown>;
    const input = sanitize(raw);
    if (!input) return NextResponse.json({ error: "Invalid result payload." }, { status: 400 });

    const result = await saveTypingResult(user.id, input);
    const [results, keyStats, settings] = await Promise.all([
      getUserResults(user.id),
      getUserKeyStats(user.id),
      getOrCreateSettings(user.id),
    ]);
    const unlocked = await syncAchievements(user.id, results, settings.dailyGoalMinutes);
    const summary = summarize(results, { keyStats, dailyGoalMinutes: settings.dailyGoalMinutes });

    return NextResponse.json({ result, unlocked, results, keyStats, summary });
  } catch (error) {
    console.error("result save failed", error);
    return NextResponse.json({ error: "Unable to save that result." }, { status: 500 });
  }
}

/** Guest import: accepts an array of locally stored results. */
export async function PUT(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    const body = (await request.json()) as { results?: Record<string, unknown>[] };
    const incoming = Array.isArray(body.results) ? body.results.slice(0, 500) : [];
    let imported = 0;
    for (const item of incoming) {
      const input = sanitize(item);
      if (!input) continue;
      const result = await saveTypingResult(user.id, input);
      if (result.id) imported += 1;
    }
    const results = await getUserResults(user.id);
    const settings = await getOrCreateSettings(user.id);
    const unlocked = await syncAchievements(user.id, results, settings.dailyGoalMinutes);
    return NextResponse.json({
      imported,
      unlocked,
      results,
      summary: summarize(results, { dailyGoalMinutes: settings.dailyGoalMinutes }),
    });
  } catch (error) {
    console.error("guest import failed", error);
    return NextResponse.json({ error: "Unable to import your guest history." }, { status: 500 });
  }
}
