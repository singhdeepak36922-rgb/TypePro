import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword, verifyPassword } from "@/lib/auth";

export async function PATCH(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    const body = (await request.json()) as {
      name?: string;
      currentPassword?: string;
      newPassword?: string;
    };

    if (body.name !== undefined) {
      const name = body.name.trim();
      if (name.length < 2) {
        return NextResponse.json({ error: "Name must be at least 2 characters." }, { status: 400 });
      }
      await db.update(users).set({ name }).where(eq(users.id, user.id));
    }

    if (body.newPassword) {
      if (body.newPassword.length < 8) {
        return NextResponse.json({ error: "New password must be at least 8 characters." }, { status: 400 });
      }
      const rows = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
      const record = rows[0];
      if (!record || !body.currentPassword || !(await verifyPassword(body.currentPassword, record.passwordHash))) {
        return NextResponse.json({ error: "Current password is incorrect." }, { status: 400 });
      }
      await db
        .update(users)
        .set({ passwordHash: await hashPassword(body.newPassword) })
        .where(eq(users.id, user.id));
    }

    const refreshed = await db
      .select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt })
      .from(users)
      .where(eq(users.id, user.id))
      .limit(1);

    return NextResponse.json({ user: refreshed[0] });
  } catch (error) {
    console.error("profile update failed", error);
    return NextResponse.json({ error: "Unable to update your profile." }, { status: 500 });
  }
}
