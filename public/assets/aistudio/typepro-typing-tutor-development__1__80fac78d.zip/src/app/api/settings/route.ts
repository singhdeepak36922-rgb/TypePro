import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getOrCreateSettings, saveSettings } from "@/lib/data";
import type { UserSettings } from "@/lib/types";

function sanitize(body: Record<string, unknown>): Partial<UserSettings> {
  const patch: Partial<UserSettings> = {};
  if (body.theme === "dark" || body.theme === "light" || body.theme === "system") patch.theme = body.theme;
  if (body.language === "en" || body.language === "hi") patch.language = body.language;
  if (typeof body.soundEnabled === "boolean") patch.soundEnabled = body.soundEnabled;
  if (body.cursorStyle === "line" || body.cursorStyle === "block" || body.cursorStyle === "underline") {
    patch.cursorStyle = body.cursorStyle;
  }
  if (body.keyboardLayout === "qwerty" || body.keyboardLayout === "inscript") {
    patch.keyboardLayout = body.keyboardLayout;
  }
  if (typeof body.defaultDuration === "number" && body.defaultDuration >= 30 && body.defaultDuration <= 1800) {
    patch.defaultDuration = Math.round(body.defaultDuration);
  }
  if (typeof body.defaultCategory === "string") patch.defaultCategory = body.defaultCategory.slice(0, 40);
  if (typeof body.dailyGoalMinutes === "number" && body.dailyGoalMinutes >= 1 && body.dailyGoalMinutes <= 480) {
    patch.dailyGoalMinutes = Math.round(body.dailyGoalMinutes);
  }
  if (typeof body.showKeyboard === "boolean") patch.showKeyboard = body.showKeyboard;
  if (typeof body.strictMode === "boolean") patch.strictMode = body.strictMode;
  return patch;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  return NextResponse.json({ settings: await getOrCreateSettings(user.id) });
}

export async function PATCH(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    const body = (await request.json()) as Record<string, unknown>;
    const settings = await saveSettings(user.id, sanitize(body));
    return NextResponse.json({ settings });
  } catch (error) {
    console.error("settings update failed", error);
    return NextResponse.json({ error: "Unable to save settings." }, { status: 500 });
  }
}
