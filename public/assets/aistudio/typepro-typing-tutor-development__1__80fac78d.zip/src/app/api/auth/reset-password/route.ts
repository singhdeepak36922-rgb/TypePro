import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens, sessions, users } from "@/db/schema";
import { hashPassword, validateEmail } from "@/lib/auth";

/** Step 1: request a reset token. */
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { email?: string };
    const email = (body.email ?? "").trim().toLowerCase();
    if (!validateEmail(email)) {
      return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
    }
    const rows = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    // Always answer the same way so accounts cannot be enumerated.
    if (rows.length === 0) {
      return NextResponse.json({
        message: "If that email is registered, a reset token has been created.",
      });
    }
    const token = randomBytes(16).toString("hex");
    await db.insert(passwordResetTokens).values({
      id: token,
      userId: rows[0].id,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    });
    // No mail provider is configured in this environment, so the token is
    // returned directly and shown once in the UI.
    return NextResponse.json({
      message: "Reset token created. It expires in 60 minutes.",
      token,
    });
  } catch (error) {
    console.error("reset request failed", error);
    return NextResponse.json({ error: "Unable to start a password reset." }, { status: 500 });
  }
}

/** Step 2: consume the token and set a new password. */
export async function PUT(request: Request) {
  try {
    const body = (await request.json()) as { token?: string; password?: string };
    const token = (body.token ?? "").trim();
    const password = body.password ?? "";
    if (!token) {
      return NextResponse.json({ error: "Reset token is required." }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    }

    const rows = await db
      .select()
      .from(passwordResetTokens)
      .where(
        and(
          eq(passwordResetTokens.id, token),
          isNull(passwordResetTokens.usedAt),
          gt(passwordResetTokens.expiresAt, new Date()),
        ),
      )
      .limit(1);
    const record = rows[0];
    if (!record) {
      return NextResponse.json({ error: "This reset token is invalid or has expired." }, { status: 400 });
    }

    await db.update(users).set({ passwordHash: await hashPassword(password) }).where(eq(users.id, record.userId));
    await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, token));
    await db.delete(sessions).where(eq(sessions.userId, record.userId));

    return NextResponse.json({ message: "Password updated. You can sign in now." });
  } catch (error) {
    console.error("reset password failed", error);
    return NextResponse.json({ error: "Unable to reset your password." }, { status: 500 });
  }
}
