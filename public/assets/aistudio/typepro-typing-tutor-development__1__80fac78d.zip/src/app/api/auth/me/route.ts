import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getOrCreateSettings } from "@/lib/data";
import { DEFAULT_SETTINGS } from "@/lib/types";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ user: null, settings: DEFAULT_SETTINGS });
    }
    const settings = await getOrCreateSettings(user.id);
    return NextResponse.json({ user, settings });
  } catch (error) {
    console.error("session lookup failed", error);
    return NextResponse.json({ user: null, settings: DEFAULT_SETTINGS });
  }
}
