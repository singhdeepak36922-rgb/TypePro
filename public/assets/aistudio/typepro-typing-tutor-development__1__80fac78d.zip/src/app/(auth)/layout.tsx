import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowLeft, Keyboard, Languages, ShieldCheck, Trophy } from "lucide-react";
import { Logo } from "@/components/logo";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-app">
      <div className="mx-auto grid min-h-screen w-full max-w-6xl gap-8 px-5 py-8 lg:grid-cols-2 lg:items-center lg:gap-14">
        <div className="hidden lg:block">
          <Logo size={44} />
          <h1 className="mt-6 text-3xl font-extrabold tracking-tight text-ink">
            Master your typing skills.
          </h1>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">
            TypePro measures real typing performance with Unicode-aware WPM and accuracy scoring, structured
            English and Hindi lessons, timed assessments and honest analytics.
          </p>
          <ul className="mt-6 space-y-3 text-sm">
            {[
              { icon: Keyboard, text: "Grapheme-aware engine with keystroke-error tracking" },
              { icon: Languages, text: "English and Hindi · InScript + phonetic input" },
              { icon: Trophy, text: "Achievements and streaks from your real sessions" },
              { icon: ShieldCheck, text: "Salted scrypt passwords and HTTP-only sessions" },
            ].map((item) => (
              <li key={item.text} className="flex items-start gap-2.5 text-muted">
                <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand-soft text-brand">
                  <item.icon size={14} />
                </span>
                {item.text}
              </li>
            ))}
          </ul>
          <p className="mt-8 text-[0.7rem] uppercase tracking-[0.16em] text-muted">
            TypePro · Typing Lab · v1.0
          </p>
        </div>
        <div>
          <div className="mb-5 flex items-center justify-between lg:hidden">
            <Logo />
            <Link href="/" className="btn btn-ghost !py-1.5 !text-xs">
              <ArrowLeft size={13} /> Home
            </Link>
          </div>
          {children}
          <p className="mt-4 text-center text-[0.7rem] text-muted">
            Guest mode is always available —{" "}
            <Link href="/test" className="font-semibold text-brand">
              take a typing test without an account
            </Link>
            .
          </p>
        </div>
      </div>
    </div>
  );
}
