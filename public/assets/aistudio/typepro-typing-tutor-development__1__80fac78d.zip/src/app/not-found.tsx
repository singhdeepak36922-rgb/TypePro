import Link from "next/link";
import { Logo } from "@/components/logo";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center bg-app px-5">
      <div className="card max-w-md p-6 text-center">
        <div className="flex justify-center">
          <Logo />
        </div>
        <h1 className="mt-4 text-2xl font-bold text-ink">Page not found</h1>
        <p className="mt-1 text-sm text-muted">
          That route does not exist in TypePro. Head back to your dashboard to continue practising.
        </p>
        <Link href="/" className="btn btn-primary mt-4">
          Back to dashboard
        </Link>
      </div>
    </div>
  );
}
