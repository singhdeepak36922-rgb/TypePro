import Link from "next/link";
import { WifiOff } from "lucide-react";
import { Logo } from "@/components/logo";

export const metadata = { title: "Offline · TypePro" };

export default function OfflinePage() {
  return (
    <div className="grid min-h-screen place-items-center bg-app px-5 py-10">
      <div className="card max-w-md p-6 text-center">
        <div className="flex justify-center">
          <Logo />
        </div>
        <span className="mx-auto mt-4 grid h-12 w-12 place-items-center rounded-xl bg-brand-soft text-brand">
          <WifiOff size={22} />
        </span>
        <h1 className="mt-3 text-xl font-bold text-ink">You are offline</h1>
        <p className="mt-1.5 text-sm text-muted">
          TypePro is installed as an app, so previously opened pages still work and any session you complete now
          is saved locally in the app and synced to your account when the connection returns.
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <Link href="/" className="btn btn-primary">
            Open dashboard
          </Link>
          <Link href="/test" className="btn btn-ghost">
            Typing test
          </Link>
        </div>
      </div>
    </div>
  );
}
