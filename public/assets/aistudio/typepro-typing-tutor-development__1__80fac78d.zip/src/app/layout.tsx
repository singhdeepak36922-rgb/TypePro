import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ProgressProvider } from "@/components/providers";
import { ServiceWorkerRegister } from "@/components/pwa";

export const metadata: Metadata = {
  title: "TypePro — Master Your Typing Skills",
  description:
    "TypePro is a full typing tutor and assessment platform for English and Hindi, with structured lessons, timed tests, games and performance analytics.",
  applicationName: "TypePro",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "TypePro",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#050b1a" },
    { media: "(prefers-color-scheme: light)", color: "#f3f6fd" },
  ],
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

const themeScript = `(function(){try{var raw=localStorage.getItem('typepro.guest.settings.v1');var theme='dark';if(raw){var parsed=JSON.parse(raw);if(parsed&&parsed.theme)theme=parsed.theme;}var dark=theme==='dark'||(theme==='system'&&window.matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.classList.toggle('dark',dark);document.documentElement.dataset.theme=dark?'dark':'light';document.documentElement.style.colorScheme=dark?'dark':'light';}catch(e){document.documentElement.classList.add('dark');}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <ProgressProvider>{children}</ProgressProvider>
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
